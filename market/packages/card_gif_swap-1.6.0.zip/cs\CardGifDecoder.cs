// 卡牌 GIF 替换插件：最小 GIF89a 解码器（LZW + 帧合成）。
// 生成工程时这个文件会被拷到 cs/Plugins/card_gif_swap/ 下，和模组一起编译。
// 不依赖 Godot 的 GIF 支持：解出 RGBA 帧后由 CardGifSwap 建 ImageTexture / SpriteFrames。

using System;
using System.Collections.Generic;
using Godot;

internal static class CardGifDecoder
{
    internal sealed record GifFrame(byte[] Rgba, float Delay);

    internal static (int Width, int Height, List<GifFrame> Frames)? Load(string path)
    {
        byte[] data = path.Contains("://")
            ? FileAccess.GetFileAsBytes(path)
            : (System.IO.File.Exists(path) ? System.IO.File.ReadAllBytes(path) : FileAccess.GetFileAsBytes(path));
        if (data is null || data.Length < 13) return null;
        if (data[0] != (byte)'G' || data[1] != (byte)'I' || data[2] != (byte)'F') return null;

        int width = ReadU16(data, 6);
        int height = ReadU16(data, 8);
        if (width <= 0 || height <= 0 || width > 4096 || height > 4096) return null;

        byte packed = data[10];
        bool hasGct = (packed & 0x80) != 0;
        int gctSize = 1 << ((packed & 0x07) + 1);
        int pos = 13;
        byte[]? gct = hasGct ? ReadPalette(data, ref pos, gctSize) : null;

        var canvas = new byte[width * height * 4];
        var frames = new List<GifFrame>();
        bool hasCanvas = false;
        byte[]? beforeLast = null;
        int lastLeft = 0, lastTop = 0, lastW = 0, lastH = 0;
        int lastDisposal = 0;
        int delayCs = 10;
        int disposal = 0;
        int transparent = -1;

        while (pos < data.Length)
        {
            byte block = data[pos++];
            if (block == 0x3B) break; // trailer
            if (block == 0x21)
            {
                if (pos >= data.Length) break;
                byte label = data[pos++];
                if (label == 0xF9)
                {
                    if (pos >= data.Length) break;
                    int size = data[pos++];
                    if (size >= 4 && pos + size <= data.Length)
                    {
                        byte p = data[pos];
                        disposal = (p >> 2) & 0x07;
                        bool useTransparent = (p & 0x01) != 0;
                        delayCs = data[pos + 1] | (data[pos + 2] << 8);
                        transparent = useTransparent ? data[pos + 3] : -1;
                    }
                    pos += size;
                }
                SkipSubBlocks(data, ref pos);
                continue;
            }
            if (block != 0x2C) break; // not an image descriptor
            if (pos + 9 > data.Length) break;

            int left = ReadU16(data, pos); pos += 2;
            int top = ReadU16(data, pos); pos += 2;
            int iw = ReadU16(data, pos); pos += 2;
            int ih = ReadU16(data, pos); pos += 2;
            byte ipacked = data[pos++];
            bool hasLct = (ipacked & 0x80) != 0;
            bool interlaced = (ipacked & 0x40) != 0;
            int lctSize = 1 << ((ipacked & 0x07) + 1);
            byte[]? palette = hasLct ? ReadPalette(data, ref pos, lctSize) : gct;
            if (palette is null || iw <= 0 || ih <= 0 || pos >= data.Length) return null;

            int minCode = data[pos++];
            byte[]? indices = DecodeLzw(data, ref pos, minCode, iw * ih);
            if (indices is null) return null;

            // 上一帧的 disposal 在当前帧绘制之前处理
            if (hasCanvas)
            {
                if (lastDisposal == 2)
                    ClearRect(canvas, width, height, lastLeft, lastTop, lastW, lastH);
                else if (lastDisposal == 3 && beforeLast is not null)
                    Array.Copy(beforeLast, canvas, canvas.Length);
            }

            byte[] before = (byte[])canvas.Clone();
            for (int row = 0; row < ih; row++)
            {
                int y = top + (interlaced ? InterlaceRow(row, ih) : row);
                if (y < 0 || y >= height) continue;
                for (int x = 0; x < iw; x++)
                {
                    int px = left + x;
                    if (px < 0 || px >= width) continue;
                    int idx = indices[row * iw + x];
                    if (idx == transparent) continue;
                    int pi = idx * 3;
                    if (pi + 2 >= palette.Length) continue;
                    int o = (y * width + px) * 4;
                    canvas[o] = palette[pi];
                    canvas[o + 1] = palette[pi + 1];
                    canvas[o + 2] = palette[pi + 2];
                    canvas[o + 3] = 255;
                }
            }

            frames.Add(new GifFrame((byte[])canvas.Clone(), Math.Max(0.02f, delayCs / 100f)));
            hasCanvas = true;
            beforeLast = before;
            lastLeft = left;
            lastTop = top;
            lastW = iw;
            lastH = ih;
            lastDisposal = disposal;

            disposal = 0;
            transparent = -1;
            delayCs = 10;
        }

        return frames.Count == 0 ? null : (width, height, frames);
    }

    private static byte[]? ReadPalette(byte[] data, ref int pos, int count)
    {
        if (pos + count * 3 > data.Length) return null;
        var p = new byte[count * 3];
        Array.Copy(data, pos, p, 0, p.Length);
        pos += p.Length;
        return p;
    }

    private static void SkipSubBlocks(byte[] data, ref int pos)
    {
        while (pos < data.Length)
        {
            int n = data[pos++];
            if (n == 0) return;
            pos += n;
        }
    }

    private static byte[]? DecodeLzw(byte[] data, ref int pos, int minCode, int pixelCount)
    {
        if (minCode < 2 || minCode > 8) return null;
        var packed = new List<byte>(pixelCount);
        while (pos < data.Length)
        {
            int n = data[pos++];
            if (n == 0) break;
            if (pos + n > data.Length) return null;
            for (int i = 0; i < n; i++) packed.Add(data[pos + i]);
            pos += n;
        }
        if (packed.Count == 0) return null;

        int clear = 1 << minCode;
        int end = clear + 1;
        int codeSize = minCode + 1;
        int next = end + 1;
        var dict = new Dictionary<int, byte[]>();
        for (int i = 0; i < clear; i++) dict[i] = new[] { (byte)i };
        int old = -1;
        byte first = 0;
        int bitPos = 0;
        byte[]? oldEntry = null;
        var output = new byte[pixelCount];
        int outPos = 0;

        while (outPos < pixelCount)
        {
            int code = ReadCode(packed, ref bitPos, codeSize);
            if (code < 0) break;
            if (code == clear)
            {
                codeSize = minCode + 1;
                next = end + 1;
                dict.Clear();
                for (int i = 0; i < clear; i++) dict[i] = new[] { (byte)i };
                old = -1;
                oldEntry = null;
                continue;
            }
            if (code == end) break;

            byte[] entry;
            if (dict.TryGetValue(code, out var found))
                entry = found;
            else if (code == next && oldEntry is not null)
            {
                entry = new byte[oldEntry.Length + 1];
                Array.Copy(oldEntry, entry, oldEntry.Length);
                entry[^1] = first;
            }
            else break;

            foreach (byte b in entry)
            {
                if (outPos < output.Length) output[outPos++] = b;
            }
            first = entry[0];
            if (old >= 0 && oldEntry is not null && next < 4096)
            {
                var add = new byte[oldEntry.Length + 1];
                Array.Copy(oldEntry, add, oldEntry.Length);
                add[^1] = first;
                dict[next++] = add;
                if (next == (1 << codeSize) && codeSize < 12) codeSize++;
            }
            old = code;
            oldEntry = entry;
        }
        return outPos == pixelCount ? output : null;
    }

    private static int ReadCode(List<byte> data, ref int bitPos, int codeSize)
    {
        if (bitPos + codeSize > data.Count * 8) return -1;
        int code = 0;
        for (int i = 0; i < codeSize; i++)
        {
            int bit = (data[(bitPos + i) >> 3] >> ((bitPos + i) & 7)) & 1;
            code |= bit << i;
        }
        bitPos += codeSize;
        return code;
    }

    private static int InterlaceRow(int row, int height)
    {
        // GIF 4-pass interlace 的逆映射：输入是存储顺序，返回实际行号
        int p1 = (height + 7) / 8;
        int p2 = (height + 3) / 8;
        int p3 = (height + 1) / 4;
        if (row < p1) return row * 8;
        row -= p1;
        if (row < p2) return 4 + row * 8;
        row -= p2;
        if (row < p3) return 2 + row * 4;
        row -= p3;
        return 1 + row * 2;
    }

    private static void ClearRect(byte[] canvas, int width, int height, int left, int top, int w, int h)
    {
        for (int y = top; y < top + h && y < height; y++)
        {
            if (y < 0) continue;
            for (int x = left; x < left + w && x < width; x++)
            {
                if (x < 0) continue;
                int o = (y * width + x) * 4;
                canvas[o] = 0;
                canvas[o + 1] = 0;
                canvas[o + 2] = 0;
                canvas[o + 3] = 0;
            }
        }
    }

    private static int ReadU16(byte[] data, int pos) =>
        pos + 1 < data.Length ? data[pos] | (data[pos + 1] << 8) : 0;
}
