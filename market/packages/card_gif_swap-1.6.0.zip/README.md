# 打出指定卡牌播放指定gif（1.6）

> 需要生成器 **V0.3.115+**。模板里的 `{字段:str}` 由生成端做 C# 字符串转义；
> 旧版生成器不认识它，会把占位符原样填进去（插件会在日志里明确报「生成器版本过低」）。

打出指定卡牌 / 某类卡时，把角色当前逐帧动画换成你指定的 GIF。

## 安装

1. 把整个文件夹放进生成器的 `plugins\`。
2. 把 GIF 放到：

   ```text
   %APPDATA%\SlayTheSpire2\card_gif_swap\
   ```

   市场包**不含**安装脚本，手动复制即可；插件目录的 `assets\card.gif` 只是示例。
3. 打开生成器 →「插件」页 →「重新加载插件」。

## 配置

「卡牌」页 → 底部「插件扩展页」→「卡牌 GIF 替换」：

- **GIF 规则列表**：点「+ 添加一行」，可以加任意多条；
- 每行：
  - **触发卡牌**：`Any` / `Type:Attack` / `Type:Skill` / `Type:Power` / `Class:你的卡类名`；
    可以写多个，用逗号分隔：`Class:SparkleCard44,Class:SparkleCard45`；
  - **GIF 文件名**：`card.gif`（相对 `%APPDATA%\SlayTheSpire2\card_gif_swap\`）或绝对路径
    （`E:\gif\a.gif`、`E:/gif/a.gif` 都行；v1.6 会做转义）；
  - **播放方式**：`一次性`（播完回待机）或 `本场战斗永久`；
  - **同步待机参数**：沿用当前待机 GIF 的缩放 / 位置。

规则从上到下匹配，**第一条命中的生效**；把 `Class:` 规则放在 `Type:` 规则前面，就能让某张卡优先于某类卡。

配置完点「生成到当前工程」，再正常生成 / 构建模组。

> ⚠ 从资源管理器「复制文件地址」时，别把路径外面的引号一起粘进去 ——
> 引号会被当成文件名的一部分（旧版还会直接把配置写成语法错）。

## 行为

- `CardModel.OnPlayWrapper` Prefix 检测打出的牌；
- 命中后给该角色视觉根节点挂 `CardGifOverride`；
- GIF 运行时解码成 `SpriteFrames`（插件自带 GIF89a 解码器）；
- 一次性：`AnimationFinished` 后通过 `FrameAnimPlayer.Play("idle_loop")` 回待机；
- 永久：组件每帧把覆盖动画按回去；死亡时停止覆盖，让死亡动画正常播；
- 每个 `NCreature` 独立，新战斗 / 新场景重新开始。

## 限制

- 只对**已启用逐帧动画**的角色生效（要有 `FrameAnimPlayer` / `__FrameAnimSprite`）；
- 只解常见 GIF89a（调色板、透明色、disposal、interlace）；
- 日志前缀 `[card_gif_swap]`，会打印加载了几帧、匹配了哪条规则、找过哪些路径。
