# 按方案打出牌堆中的牌（playpileplan）

在卡牌页 / 锻造图的【效果】里加一个效果：**按「第几号方案」从手牌 / 抽牌堆 / 弃牌堆 / 消耗牌堆里，筛出指定类型、自定义关键词、卡名包含的牌，随机或手动选 N 张免费打出。**

## 为什么做成「方案页 + 数值填方案号」

V0.3.67 里插件效果在卡牌效果列表和锻造图【效果】节点上都**只渲染「数值」一个框**（`EffectFieldPolicy` 对插件种类全部返回 false，只剩 `UsesTimes`），塞不下牌堆/类型/关键词这些筛选项。所以把筛选放到插件自己的表格页里，效果只记「第几号方案」。

## 安装

```
<编辑器程序目录>\plugins\打出牌堆方案\
├─ plugin.json
└─ cs\PlayPilePlan.cs
```

装好后在「插件」页点「重新加载插件」，顶部会多一个页签 **「打出牌堆方案」**。

## 用法

1. 打开页签「打出牌堆方案」，点「+ 添加一行」配方案：

   | 栏位 | 说明 |
   |---|---|
   | 牌堆 | 抽牌堆 / 手牌 / 弃牌堆 / 消耗牌堆 |
   | 牌类型 | 任意 / 攻击 / 技能 / 能力 / 状态 / 诅咒 / 任务 |
   | 选法 | 随机（自动挑）/ 自己选（弹本体的选牌框） |
   | 自定义关键词 | 留空不筛；可写多个词，用空格 / 逗号 / 顿号分隔；「先行」或 `EATFIRST` 都认 |
   | 关键词匹配 | 或（命中任意一个）/ 且（每个都要有）/ 非（一个都不能有） |
   | 卡名包含 | 留空不筛；按卡名子串筛 |
   | 张数 | 这一次打几张；牌不够就有几张打几张 |
   | 全部符合的牌 | 勾上 = 筛选后有几张打几张（「张数」填 0 也一样） |

2. 在卡牌效果列表或锻造图【效果】节点里选 **「插件：按方案从牌堆打出（数值 = 方案号）」**，数值填方案号（1 = 第 1 行）。
3. 生成工程（或「生成到当前工程」）时，方案会渲染成 `cs/Plugins/playpileplan/PlayPilePlanConfigInit.cs`：

```csharp
internal static class PluginPlayPilePlanConfigInit
{
    [System.Runtime.CompilerServices.ModuleInitializer]
    internal static void Init()
    {
        PluginPlayPilePlan.Set(1, "抽牌堆", "攻击", "随机", "", "", "2", "0");
    }
}
```

## 生成出来的效果长什么样

```
await PluginPlayPilePlan.Play({choice}, {player}, (int)({amount}));
```

- `{choice}`：该执行点的 context（卡牌链 = `choiceContext`，锻造链 = 该执行点 context）
- `{player}`：卡牌链 = `base.Owner`，锻造链 = `__fgPlayer`
- `{amount}`：数值框（卡牌上写「数值 = X」时是那个 `x`）

`Play` 里是：取牌堆 → 按类型 / 关键词 / 卡名过滤 → 随机或 `CardSelectCmd.FromSimpleGrid` 选人 → `CardCmd.AutoPlay`（免费、自动选目标）。

勾「全部符合的牌」（或张数填 0）时就是**筛选后有几张打几张**；「自己选」时最多也只能选到这么多张。

## 关键词怎么判定

角色生成器加的自定义关键词在运行期只体现为卡牌的悬停说明：`HoverTip` 的 `Id` 里带 `card_keywords.<KEY>.title`，`Title` 是本地化显示名。所以 `PlayPilePlan.HasKeyword` 同时比对 `IHoverTip.Id` 与 `HoverTip.Title` 是否包含填的关键词（`先行` 或 `EATFIRST` 都行）。

本体关键词（消耗 / 虚无 / 固有 …）不在 `HoverTips` 里，请用「牌类型」或其它内置条件筛。

### 多个关键词 + 且 / 或 / 非

「自定义关键词」栏可以写多个词（空格、Tab、逗号、顿号、分号、竖线都能分隔），再用「关键词匹配」选逻辑：

| 选项 | 含义 | 例（关键词写 `先行 迅捷`） |
|---|---|---|
| 或（默认） | 命中任意一个就通过 | 带「先行」或带「迅捷」的牌 |
| 且 | 每个关键词都要有 | 同时带「先行」和「迅捷」的牌 |
| 非 | 一个都不能有 | 既不带「先行」也不带「迅捷」的牌 |

对应代码：

```csharp
private static bool MatchesKeywords(CardModel card, Plan plan)
{
    string[] tokens = plan.Keyword.Split(KeywordSeparators, StringSplitOptions.RemoveEmptyEntries);
    int hits = tokens.Count(t => HasKeyword(card, t));
    switch (plan.KeywordMode)
    {
        case "且": return hits == tokens.Length;
        case "非": return hits == 0;
        default:   return hits > 0;
    }
}
```

## 限制

- 方案按存档存值（`plugins/playpileplan/rows.json`），换存档要重配。
- 「自己选」复用的是本体的弃牌选择提示文案。
- 打出的牌按 `CardCmd.AutoPlay` 走，不消耗能量。
- 只在卡牌链 / 锻造图链有意义（效果模板里用了 `{choice}`/`{player}`，遗物/状态链也能编，但语义按各自的 context 来）。

## 验证记录

- `cs/PlayPilePlan.cs` 用临时工程（net9.0，引用 `...\ExampleMod\libs\sts2.dll`）编译：**0 警告 0 错误**（修过一次 `IHoverTip` 没有 `Title` 的 CS1061，改成 `tip is HoverTip ht`）。
- `plugin.json` 用 `ConvertFrom-Json` 校验：1 个效果 / 2 个页面 / 6 个方案子栏位 / 1 个 csFile；list 块宏 `{Plans}…{/Plans}` 配对。
- 用假程序目录让 `PluginRegistry.Load` 实际加载：`PluginSpec` id=playpileplan，Effects=1，Pages=2，无 ⚠。
- **未实机**：没启动编辑器、没生成过工程，也没在游戏里验证打出效果。
