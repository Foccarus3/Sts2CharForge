#nullable enable

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MegaCrit.Sts2.Core.CardSelection;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.Entities.Players;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.HoverTips;
using MegaCrit.Sts2.Core.Models;

/// <summary>
/// 「按方案从牌堆打出」的运行时支持。
/// 方案（牌堆/牌类型/选法/关键词/卡名/张数）由插件页「打出牌堆方案」的列表生成到
/// PlayPilePlanConfigInit.cs，生成物在启动时逐行调用 <see cref="Set"/>。
/// 效果里只填方案号，所以卡牌页和锻造图都能用。
/// </summary>
public static class PluginPlayPilePlan
{
    private sealed class Plan
    {
        public string Pile = "抽牌堆";
        public string Type = "任意";
        public string Mode = "随机";
        public string Keyword = string.Empty;
        public string KeywordMode = "或";
        public string NameContains = string.Empty;
        public int Count = 1;
        public bool All;
    }

    private static readonly Dictionary<int, Plan> Plans = new Dictionary<int, Plan>();

    /// <summary>由生成的配置初始化文件按行调用；index 从 1 开始。</summary>
    public static void Set(int index, string? pile, string? type, string? mode, string? keyword, string? keywordMode, string? nameContains, string? count, string? all)
    {
        int parsed = int.TryParse(count, out int value) ? value : 1;
        bool takeAll = all?.Trim() == "1"
            || string.Equals(all?.Trim(), "true", StringComparison.OrdinalIgnoreCase);
        string kwMode = keywordMode?.Trim() ?? string.Empty;
        Plans[index] = new Plan
        {
            Pile = string.IsNullOrWhiteSpace(pile) ? "抽牌堆" : pile!.Trim(),
            Type = string.IsNullOrWhiteSpace(type) ? "任意" : type!.Trim(),
            Mode = mode?.Trim() == "自己选" ? "自己选" : "随机",
            Keyword = (keyword ?? string.Empty).Trim(),
            KeywordMode = kwMode == "且" || kwMode == "非" ? kwMode : "或",
            NameContains = (nameContains ?? string.Empty).Trim(),
            Count = Math.Max(0, parsed),
            All = takeAll
        };
    }

    public static async Task Play(PlayerChoiceContext? choiceContext, Player? player, int index)
    {
        if (player?.PlayerCombatState is null)
        {
            return;
        }

        Plans.TryGetValue(index, out Plan? plan);
        plan ??= new Plan();

        List<CardModel> pool = SourceCards(player, plan.Pile)
            .Where(card => Matches(card, plan))
            .ToList();
        // 「全部」= 筛选后有几张打几张；否则按张数取（0 张什么都不做）。
        int limit = plan.All ? int.MaxValue : plan.Count;
        if (pool.Count == 0 || limit <= 0)
        {
            return;
        }

        PlayerChoiceContext context = choiceContext ?? new BlockingPlayerChoiceContext();
        int count = Math.Min(limit, pool.Count);

        if (plan.Mode == "自己选")
        {
            CardSelectorPrefs prefs = new CardSelectorPrefs(CardSelectorPrefs.DiscardSelectionPrompt, 0, count);
            IEnumerable<CardModel> selected = await CardSelectCmd.FromSimpleGrid(context, pool, player, prefs);
            foreach (CardModel card in selected.ToList())
            {
                await PlayOne(context, card);
            }

            return;
        }

        for (int i = 0; i < count && pool.Count > 0; i++)
        {
            int pick = player.RunState.Rng.CombatCardSelection.NextInt(pool.Count);
            CardModel card = pool[pick];
            pool.RemoveAt(pick);
            await PlayOne(context, card);
        }
    }

    private static List<CardModel> SourceCards(Player player, string pile)
    {
        PlayerCombatState? state = player.PlayerCombatState;
        if (state is null)
        {
            return new List<CardModel>();
        }

        return pile switch
        {
            "手牌" => state.Hand.Cards.ToList(),
            "弃牌堆" => state.DiscardPile.Cards.ToList(),
            "消耗牌堆" => state.ExhaustPile.Cards.ToList(),
            _ => state.DrawPile.Cards.ToList()
        };
    }

    private static bool Matches(CardModel card, Plan plan)
    {
        if (!MatchesType(card.Type, plan.Type))
        {
            return false;
        }

        if (plan.NameContains.Length > 0
            && !card.Title.Contains(plan.NameContains, StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        if (plan.Keyword.Length > 0 && !MatchesKeywords(card, plan))
        {
            return false;
        }

        return true;
    }

    private static readonly char[] KeywordSeparators =
    {
        ' ', '\t', ',', '，', '、', ';', '；', '|'
    };

    /// <summary>
    /// 关键词匹配：关键词栏可以写多个（空格 / 逗号 / 顿号分隔）。
    /// 或 = 命中任意一个；且 = 每个都要有；非 = 一个都不能有。
    /// </summary>
    private static bool MatchesKeywords(CardModel card, Plan plan)
    {
        string[] tokens = plan.Keyword.Split(KeywordSeparators, StringSplitOptions.RemoveEmptyEntries);
        if (tokens.Length == 0)
        {
            return true;
        }

        int hits = 0;
        foreach (string token in tokens)
        {
            if (HasKeyword(card, token))
            {
                hits++;
            }
        }

        switch (plan.KeywordMode)
        {
            case "且":
                return hits == tokens.Length;
            case "非":
                return hits == 0;
            default:
                return hits > 0;
        }
    }

    private static bool MatchesType(CardType type, string wanted)
    {
        return wanted switch
        {
            "攻击" => type == CardType.Attack,
            "技能" => type == CardType.Skill,
            "能力" => type == CardType.Power,
            "状态" => type == CardType.Status,
            "诅咒" => type == CardType.Curse,
            "任务" => type == CardType.Quest,
            _ => type != CardType.None
        };
    }

    /// <summary>
    /// 自定义关键词只出现在卡牌的悬停说明里（card_keywords 表），没有运行期集合可查，
    /// 所以按「说明 Id / 说明标题包含关键词」判断：填「先行」或 EATFIRST 都认。
    /// </summary>
    private static bool HasKeyword(CardModel card, string keyword)
    {
        foreach (IHoverTip tip in card.HoverTips ?? Enumerable.Empty<IHoverTip>())
        {
            string id = tip.Id ?? string.Empty;
            if (id.Contains(keyword, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            if (tip is HoverTip direct
                && !string.IsNullOrEmpty(direct.Title)
                && direct.Title.Contains(keyword, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
        }

        return false;
    }

    private static async Task PlayOne(PlayerChoiceContext choiceContext, CardModel card)
    {
        if (card.HasBeenRemovedFromState || card.Pile is null || card.Owner is null)
        {
            return;
        }

        await CardCmd.AutoPlay(choiceContext, card, null);
    }
}
