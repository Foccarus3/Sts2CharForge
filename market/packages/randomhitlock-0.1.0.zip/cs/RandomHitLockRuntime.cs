// 插件「随机命中锁」自带的运行时，随模组一起编译（由生成器的插件机制并入工程）。
// 作用：把「随机命中」这一次（或这几次）伤害实际打到的那几只生物记下来，
// 供紧接着的「施加状态」效果对同一批目标结算，而不是重新随机一次。
//
// 记录有两种口径：
//   覆盖式（默认）：每次随机伤害先把记录清空，再写这一批命中 —— 「上一条伤害打谁，状态就打谁」。
//   累加式（Append）：不清空，把这一批命中追加在旧命中后面 —— 「几条随机伤害合起来打谁，状态就打谁」。
// 结算也有两种口径：
//   每只一次（ApplyLocked）：同一只被打 N 下只算一次。
//   每命中一次（ApplyLockedPerHit）：打 N 下算 N 次（配合累加式可叠层）。

#nullable enable

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Commands.Builders;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.Entities.Creatures;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.Models;

namespace Plugins.RandomHitLock;

/// <summary>
/// 「随机命中锁」运行时。
/// 一条随机伤害执行完，就把 <see cref="AttackCommand.Results"/> 里的 Receiver 按命中次序记到
/// 当前载体（这张牌 / 这个状态 / 这件遗物）名下；后续「施加状态」读这份记录，
/// 于是两次结算的随机目标被钉成同一批。记录默认是「覆盖式」的，另有累加式的入口。
/// </summary>
public static class RandomHitLockRuntime
{
    /// <summary>某一批随机伤害留下的命中记录。</summary>
    private sealed class LockRecord
    {
        /// <summary>
        /// 命中序列：按伤害结算的先后顺序记。同一只被打两下就会出现两次 ——
        /// 「每命中一次」的口径靠它，「每只一次」的口径在结算时去重。
        /// </summary>
        public readonly List<Creature> Hits = new List<Creature>();

        /// <summary>这份记录是谁写下的：卡牌链是这张牌，锻造图是这张牌 / 这个状态。</summary>
        public object? Source;
    }

    /// <summary>记录挂在载体实例上（弱引用表），换牌、换状态不会串，也不进存档。</summary>
    private static readonly ConditionalWeakTable<object, LockRecord> Locks =
        new ConditionalWeakTable<object, LockRecord>();

    private static LockRecord? TryGetRecord(object? key)
    {
        if (key == null)
        {
            return null;
        }

        return Locks.TryGetValue(key, out LockRecord? record) ? record : null;
    }

    private static LockRecord? GetOrCreateRecord(object? key)
    {
        if (key == null)
        {
            // 载体为空（理论上卡牌链不会）：不记录，伤害照打，状态侧会因为拿不到记录而跳过。
            return null;
        }

        return Locks.GetValue(key, _ => new LockRecord());
    }

    /// <summary>去重保序：同一只只留第一次出现的那个位置。</summary>
    private static List<Creature> Dedupe(IEnumerable<Creature> hits)
    {
        var unique = new List<Creature>();
        foreach (Creature creature in hits)
        {
            if (creature != null && !unique.Contains(creature))
            {
                unique.Add(creature);
            }
        }

        return unique;
    }

    /// <summary>
    /// 伤害 + 记录的共用实现。
    /// </summary>
    /// <param name="hits">打几段（每段重新随机；可重复命中同一只）。全体模式忽略。</param>
    /// <param name="allTargets">true = 对所有敌人各打一段（不再是随机）。</param>
    /// <param name="append">true = 不清空旧记录，把这次命中追加进去。</param>
    private static async Task DealAsync(
        PlayerChoiceContext? choiceContext,
        CardModel? card,
        CardPlay? cardPlay,
        decimal amount,
        object? key,
        int hits,
        bool allTargets,
        bool append)
    {
        LockRecord? record = GetOrCreateRecord(key);
        if (record != null)
        {
            if (!append)
            {
                record.Hits.Clear();
            }

            record.Source = card;
        }

        if (card == null || amount <= 0m)
        {
            return;
        }

        var combat = card.Owner?.Creature?.CombatState;
        if (combat == null || !combat.HittableEnemies.Any(creature => creature != null && creature.IsAlive))
        {
            return;
        }

        // 随机目标走本体自己的随机流（RunState.Rng.CombatTargets），联机两端调用序列一致时结果一致。
        AttackCommand? command;
        if (allTargets)
        {
            command = await DamageCmd.Attack(amount)
                .FromCard(card, cardPlay)
                .TargetingAllOpponents(combat)
                .Execute(choiceContext);
        }
        else
        {
            command = await DamageCmd.Attack(amount)
                .FromCard(card, cardPlay)
                .WithHitCount(Math.Max(1, hits))
                .TargetingRandomOpponents(combat, allowDuplicates: true)
                .Execute(choiceContext);
        }

        if (command == null || record == null)
        {
            return;
        }

        // Results 是「每一步伤害的结果列表」，按执行顺序摊平就是命中序列。
        foreach (var result in command.Results.SelectMany(hitList => hitList))
        {
            Creature receiver = result.Receiver;
            if (receiver != null)
            {
                record.Hits.Add(receiver);
            }
        }
    }

    // ── 伤害侧 ──────────────────────────────────────────────────────────────

    /// <summary>
    /// 卡牌链（含卡牌锻造图）：随机挑一个敌人打一下，并记录这次实际命中的目标（覆盖式）。
    /// 场上没有可打目标时只清空记录、不结算任何东西。
    /// </summary>
    /// <param name="choiceContext">出牌的 PlayerChoiceContext。</param>
    /// <param name="card">这张牌（伤害来源与结算归属都挂在它身上）。</param>
    /// <param name="cardPlay">本次出牌（动画 / 归因用）。</param>
    /// <param name="amount">每段伤害的数值。</param>
    /// <param name="key">记录载体，卡牌链传 {state}（就是这张牌）。</param>
    public static Task DamageRandomOnCard(
        PlayerChoiceContext? choiceContext,
        CardModel? card,
        CardPlay? cardPlay,
        decimal amount,
        object? key)
    {
        return DealAsync(choiceContext, card, cardPlay, amount, key, hits: 1, allTargets: false, append: false);
    }

    /// <summary>
    /// 随机打 <paramref name="hits"/> 段（每段重新随机，可重复命中同一只），覆盖式记录命中的那一批。
    /// 打 3 段通常就是「随机打到 3 只，少数情况打到同一只」。
    /// </summary>
    /// <param name="hits">段数（≥1）。</param>
    public static Task DamageRandomManyOnCard(
        PlayerChoiceContext? choiceContext,
        CardModel? card,
        CardPlay? cardPlay,
        decimal amount,
        object? key,
        int hits)
    {
        return DealAsync(choiceContext, card, cardPlay, amount, key, hits, allTargets: false, append: false);
    }

    /// <summary>对所有敌人各打一段（覆盖式记录全体）。</summary>
    public static Task DamageRandomAllOnCard(
        PlayerChoiceContext? choiceContext,
        CardModel? card,
        CardPlay? cardPlay,
        decimal amount,
        object? key)
    {
        return DealAsync(choiceContext, card, cardPlay, amount, key, hits: 1, allTargets: true, append: false);
    }

    /// <summary>
    /// 随机打 <paramref name="hits"/> 段，并把命中**追加**到已有记录（累加式，不清空）。
    /// 连着写几条这种效果，记录里就是这几条合起来打到的全部目标。
    /// </summary>
    public static Task DamageRandomAppendOnCard(
        PlayerChoiceContext? choiceContext,
        CardModel? card,
        CardPlay? cardPlay,
        decimal amount,
        object? key,
        int hits)
    {
        return DealAsync(choiceContext, card, cardPlay, amount, key, hits, allTargets: false, append: true);
    }

    /// <summary>对所有敌人各打一段，并把命中追加到已有记录（累加式）。</summary>
    public static Task DamageRandomAppendAllOnCard(
        PlayerChoiceContext? choiceContext,
        CardModel? card,
        CardPlay? cardPlay,
        decimal amount,
        object? key)
    {
        return DealAsync(choiceContext, card, cardPlay, amount, key, hits: 1, allTargets: true, append: true);
    }

    // ── 状态侧 ──────────────────────────────────────────────────────────────

    private static async Task ApplyCoreAsync<T>(
        PlayerChoiceContext? choiceContext,
        object? key,
        object? source,
        decimal amount,
        Creature? applier,
        bool perHit)
        where T : PowerModel
    {
        if (choiceContext == null || amount == 0m)
        {
            return;
        }

        LockRecord? record = TryGetRecord(key);
        if (record == null || record.Hits.Count == 0 || !ReferenceEquals(record.Source, source))
        {
            return;
        }

        CardModel? cardSource = source as CardModel;
        IEnumerable<Creature> targets = perHit
            ? (IEnumerable<Creature>)record.Hits.ToArray()
            : Dedupe(record.Hits.ToArray());

        foreach (Creature target in targets)
        {
            if (target == null || !target.IsAlive || !target.CanReceivePowers)
            {
                continue;
            }

            await PowerCmd.Apply<T>(choiceContext, target, amount, applier, cardSource);
        }
    }

    /// <summary>
    /// 对上一条本插件随机伤害实际命中的目标施加（正数）或扣减（负数）所选状态，**每只一次**。
    /// 记录不是同一张牌 / 同一个载体留下的，或目标已经死了，就跳过；一只都不剩时整条不结算。
    /// </summary>
    /// <typeparam name="T">所选的状态。</typeparam>
    /// <param name="choiceContext">当前 choiceContext（药水 / 遗物钩子里可能为 null，此时不结算）。</param>
    /// <param name="key">记录载体，与伤害效果传同一个 {state}。</param>
    /// <param name="source">写下记录的载体（卡牌链传 {cardSelf}），用来挡住跨牌 / 跨链的陈旧记录。</param>
    /// <param name="amount">层数；负数 = 扣减。</param>
    /// <param name="applier">施加者（通常是 {self}），影响力量 / 易伤等按施加者计算的修正。</param>
    public static Task ApplyLocked<T>(
        PlayerChoiceContext? choiceContext,
        object? key,
        object? source,
        decimal amount,
        Creature? applier)
        where T : PowerModel
    {
        return ApplyCoreAsync<T>(choiceContext, key, source, amount, applier, perHit: false);
    }

    /// <summary>
    /// 同上，但按**命中次数**结算：同一只被打 3 下就施加 3 次（3 层）。
    /// 配合「累加式」伤害，就是「几条随机伤害打到的目标，各按被打中的次数算」。
    /// </summary>
    public static Task ApplyLockedPerHit<T>(
        PlayerChoiceContext? choiceContext,
        object? key,
        object? source,
        decimal amount,
        Creature? applier)
        where T : PowerModel
    {
        return ApplyCoreAsync<T>(choiceContext, key, source, amount, applier, perHit: true);
    }

    /// <summary>主动清空记录（例如一条分支不想沿用上一次的命中目标）。</summary>
    /// <param name="key">记录载体，与伤害效果传同一个 {state}。</param>
    public static void ClearLock(object? key)
    {
        LockRecord? record = TryGetRecord(key);
        if (record == null)
        {
            return;
        }

        record.Hits.Clear();
        record.Source = null;
    }
}
