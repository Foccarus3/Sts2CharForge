﻿// 「卡牌交换面板」游戏内逻辑（V1.2 战斗版，修复真实 dll 的 API 差异）。
// 左侧 dock 按钮 + 战斗内浏览面板：从【手牌】付出两张【指定卡】（送入消耗堆，本场移除），
// 把一张【储藏卡】直接生成到【手牌】（走本体战斗生成牌的正规路径，含动画与战斗历史）。
// 非战斗状态（地图/商店/篝火等）禁用；每条配方每场战斗限换一次。
//
// V1.2 修复（对照游戏实际 sts2.dll 的公开成员，不再依赖 UOP 源码里 internal 的 RunManager.State）：
//   1. 拿当前战斗：NCombatRoom.Instance.CreatureNodes → NCreature.Entity(Creature)
//      → Creature.CombatState(ICombatState) → as CombatState（显式转换，战斗中必为具体类）；
//   2. 拿本地玩家：LocalContext.GetMe(ICombatState)（不再走 RunState）；
//   3. NCombatRoom 在 MegaCrit.Sts2.Core.Nodes.Rooms 命名空间（补 using）。
// V1.3 修复（实测 bug：面板打开后交换区不显示储藏卡）：
//   根因——编辑器生成的卡类在 namespace <存档名> 下（如 Albaz.VirtuousCard5），
//   原代码 Assembly.GetType("VirtuousCard5") 只按全名查 global 类 → 查不到 →
//   GetCanonical 返回 null → AddRecipeCell 静默跳过 → 交换区一格都不显示。
//   修复——新增 ResolveType：先按全名查，查不到再按简单类名遍历程序集兜底
//   （同名优先 CardModel 子类）；ReloadRecipes / GetCanonical 全走它；
//   ModelDb 查不到、NCard.Create 失败分别记日志；格子全失败时面板给出提示。
// V1.4（按实测反馈升级）：
//   1. 卡面位置修复——card.tscn 里卡内容以节点原点为中心（-150,-211 ~ 150,211），
//      即 NCard 原点=卡正中心；原 Position=(5,0) 把卡中心钉在格子左上角、卡身大半
//      跑出格子被 ScrollContainer 裁剪（表现为“看不到卡面”）。现改为格内中心，
//      并按本体 NCardGrid 的做法调 UpdateVisuals(Deck, Normal)；
//   2. 代价卡去处可配——「交换配方」页签新增 CostMode（消耗堆/弃牌堆），
//      读取 ExchangeRecipes.CostMode（旧生成文件没有该字段 → 默认消耗，保持旧行为）；
//   3. 交换不限次数——删除“每条配方每场战斗限换一次”，手牌凑得出即可反复交换。
// V1.5（DIY 升级）：每张代价卡【单独】设置去处——配方行从 3 元素扩成 5 元素
//   { 储藏卡, 代价卡1, 代价卡1去处(消耗/丢弃), 代价卡2, 代价卡2去处 }；
//   编辑器「交换配方」页签每行多两个下拉（默认消耗）；旧 3 元素生成文件仍可读
//   （两张都按消耗处理，与旧行为一致）；面板说明文字同步标注每张卡的去处。
// V1.5.1 修复（实测 bug：选了「丢弃」的卡看起来没进弃牌堆）：
//   根因——原实现直接 CardPileCmd.Add(card, Discard)，卡的数据虽进了弃牌堆，
//   但漏了本体弃牌路径的三件事：战斗历史记录、AfterCardDiscarded 钩子、
//   弃牌堆 InvokeContentsChanged（UI 计数/卡面不刷新）。
//   修复——丢弃分支改走本体正规命令 CardCmd.Discard（ThrowingPlayerChoiceContext
//   是本体给「无出牌上下文」场景准备的 context，事件/PowerCmd.Apply 同款用法）；
//   消耗分支维持 CardPileCmd.Add(card, Exhaust)（用户实测正常）。
// V1.6（DIY 升级）：代价卡扩到【最多 4 张】，留空的位置不参与交换——
//   配方行从 5 元素扩成 9 元素 { 储藏卡, 卡1, 卡1去处, 卡2, 卡2去处, 卡3, 卡3去处, 卡4, 卡4去处 }；
//   手牌查找改为「逐张占位」：支持同一类卡设多张（手牌里得有多张实例）；
//   多张丢弃用集合重载一次 CardCmd.Discard（本体 Sly 时序要求）；
//   旧 5 元素 / 3 元素生成文件仍兼容（分别按 V1.5 / V1.4 语义读）。
// V1.7（DIY 升级）：代价条件从「只指定卡」扩到「指定卡 + 关键词」二选一或叠加——
//   每个代价位多一个【关键词】栏（留空不启用）：
//   · 只填卡 → 指定卡（旧行为）；只填关键词 → 手牌里任意带该词条的卡；都填 → 且：这张卡还得带该词条；
//   · 关键词三种写法：本体词条中文名/英文枚举名（消耗/虚无/固有/不可打出/保留/灵巧/永恒）、
//     编辑器关键词编号（KEYWORD_5）、词条显示名（如「烙印」）；
//   · 匹配机制：本体走 CardModel.Keywords（CardKeyword 枚举），自定义走 HoverTips
//     （Id 含 card_keywords.KEYWORD_N.title；HoverTip.Title 是显示名）；
//   · 配方行扩成 13 元素 { 储藏卡, (卡N, 关键词N, 去处N)×4 }；旧 9/5/3 元素文件仍兼容。
// V1.8（实测反馈升级）：关键词从【手输文本框】改成【下拉选择】——
//   编辑器 refKind 实测只支持 card/power/relic/potion/pet/group（无 keyword），
//   故关键词栏用 pick 下拉硬编码当前存档的词条表：7 个本体词条官方译名
//   （消耗/虚无/固有/不能被打出/保留/奇巧/永恒）+ 存档自定义关键词
//   （融合素材/教导/相剑/死欲乡/烙印/铁兽战线/护宝炮妖/卫星闪灵/兽带战神/
//   调整/深渊之兽/融合怪兽/同调怪兽）+「（不启用）」哨兵；哨兵读取时归一为空。
//   游戏端本体词条别名表补官方译名（奇巧/不能被打出，旧别名仍兼容）。
//   注意：存档新增自定义关键词后，需把词条名手动加进 plugin.json 的 pick options。
// V1.9（实测反馈）：【关键词屏蔽指定卡】——某代价位选了关键词（非「（不启用）」），
//   该位的指定卡自动被屏蔽（解析时清空卡类）：只按词条收卡，不再叠加成“且”；
//   面板文字同步只显示「任意「词条」卡」。编辑器里两个都选了也以关键词为准。
// 启动安全承诺：所有公开入口都 try-catch，任何异常只写日志、绝不让游戏崩溃；
// 池化 NCard 只做显示、严格「Free→出树」归还，绝不 QueueFree，避免池悬空。
// 出问题查游戏日志里 "CardExchangePanel:" 开头的行。
#nullable disable

using System;
using System.Collections.Generic;
using Godot;
using MegaCrit.Sts2.Core.Combat;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Context;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.Entities.Creatures;
using MegaCrit.Sts2.Core.Entities.Players;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.Logging;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Nodes;
using MegaCrit.Sts2.Core.Nodes.Cards;
using MegaCrit.Sts2.Core.Nodes.Combat;
using MegaCrit.Sts2.Core.Nodes.CommonUi;
using MegaCrit.Sts2.Core.Nodes.Pooling;
using MegaCrit.Sts2.Core.Nodes.Rooms;

public static class CardExchangePanel
{
    // ==== 配方 ====
    private sealed class Recipe
    {
        public string VaultClass = "";
        // V1.6：代价卡最多 4 张，逐张配去处；留空的位置不参与交换
        public readonly string[] CostClasses = new string[4];
        // V1.7：每个代价位可选配关键词；卡类与关键词都空 = 该位不启用
        public readonly string[] CostKeywords = new string[4];
        public readonly bool[] CostDiscards = new bool[4];   // true = 丢弃（弃牌堆），false = 消耗（消耗堆）
    }

    private static readonly List<Recipe> _recipes = new List<Recipe>();

    // 类型解析缓存（类名 → Type；卡类带命名空间，见 ResolveType）
    private static readonly Dictionary<string, Type> _typeCache = new Dictionary<string, Type>();

    // ==== 左侧 dock ====
    private static Control _dock;
    private static Button _dockButton;
    private static Label _dockHint;

    // ==== 浏览面板 ====
    private static Control _browse;
    private static GridContainer _browseGrid;

    // ==== 池化卡牌登记（归还用） ====
    private static readonly List<NCard> _pooledCards = new List<NCard>();
    private static bool _exchanging;

    // ------------------------------------------------------------------
    // 入口：NGlobalUi._Ready 的 Harmony Postfix 调到这里（每次进 Run 触发一次）
    // ------------------------------------------------------------------
    public static void TryInstall(NGlobalUi globalUi)
    {
        try
        {
            if (globalUi == null) return;

            // 幂等：先拆旧 dock
            RemoveDock();

            // 每次进 Run（新开局 / 读档）都重新读一次配方
            ReloadRecipes();
            BuildDock(globalUi);
        }
        catch (Exception e)
        {
            Log.Error("CardExchangePanel: 安装失败 - " + e.GetType().Name + ": " + e.Message);
        }
    }

    private static void RemoveDock()
    {
        try
        {
            if (_dock != null && GodotObject.IsInstanceValid(_dock))
            {
                _dock.TreeExiting -= OnDockExiting;
                _dock.QueueFree();
            }
        }
        catch { }
        _dock = null;
        _dockButton = null;
        _dockHint = null;
        CloseBrowse();
    }

    // ------------------------------------------------------------------
    // 战斗上下文（全部走真实 dll 的 public 成员）
    // ------------------------------------------------------------------
    private static bool TryGetCombatContext(out Player player, out CombatState combat)
    {
        player = null;
        combat = null;
        try
        {
            NCombatRoom room = NCombatRoom.Instance;
            if (room == null) return false;
            CombatManager cm = CombatManager.Instance;
            if (cm == null || !cm.IsInProgress) return false;
            foreach (NCreature node in room.CreatureNodes)
            {
                if (node == null || !GodotObject.IsInstanceValid(node)) continue;
                Creature entity = node.Entity;
                if (entity == null) continue;
                ICombatState cs = entity.CombatState;
                if (cs == null) continue;
                CombatState concrete = cs as CombatState;
                if (concrete == null) continue;
                Player p = LocalContext.GetMe(cs);
                if (p == null) continue;
                player = p;
                combat = concrete;
                return true;
            }
            return false;
        }
        catch
        {
            return false;
        }
    }

    private static Player GetLocalPlayer()
    {
        Player p;
        CombatState c;
        return TryGetCombatContext(out p, out c) ? p : null;
    }

    // ------------------------------------------------------------------
    // 左侧 dock：按钮 + 配方数提示
    // ------------------------------------------------------------------
    private static void BuildDock(NGlobalUi globalUi)
    {
        _dock = new Control();
        _dock.Name = "__CardExchangeDock";
        _dock.AnchorLeft = 0f; _dock.AnchorTop = 0f; _dock.AnchorRight = 0f; _dock.AnchorBottom = 0f;
        _dock.OffsetLeft = 12f; _dock.OffsetTop = 320f; _dock.OffsetRight = 108f; _dock.OffsetBottom = 364f;
        _dock.MouseFilter = Control.MouseFilterEnum.Ignore;

        _dockButton = new Button();
        _dockButton.Text = "卡牌交换";
        _dockButton.AnchorLeft = 0f; _dockButton.AnchorTop = 0f; _dockButton.AnchorRight = 1f; _dockButton.AnchorBottom = 1f;
        _dockButton.OffsetLeft = 0f; _dockButton.OffsetTop = 0f; _dockButton.OffsetRight = 0f; _dockButton.OffsetBottom = 0f;
        _dockButton.Pressed += OnDockPressed;
        _dock.AddChild(_dockButton);

        _dockHint = new Label();
        _dockHint.Text = _recipes.Count > 0 ? ("可换 " + _recipes.Count + " 种") : "未配置配方";
        _dockHint.HorizontalAlignment = Godot.HorizontalAlignment.Center;
        _dockHint.AddThemeFontSizeOverride("font_size", 13);
        _dockHint.AnchorLeft = 0f; _dockHint.AnchorTop = 1f; _dockHint.AnchorRight = 1f; _dockHint.AnchorBottom = 1f;
        _dockHint.OffsetLeft = 0f; _dockHint.OffsetTop = 30f; _dockHint.OffsetRight = 0f; _dockHint.OffsetBottom = 52f;
        _dock.AddChild(_dockHint);

        globalUi.AddChild(_dock);
        _dock.TreeExiting += OnDockExiting;
    }

    private static void UpdateDockHint()
    {
        try
        {
            if (_dockHint == null || !GodotObject.IsInstanceValid(_dockHint)) return;
            _dockHint.Text = _recipes.Count > 0 ? ("可换 " + _recipes.Count + " 种") : "未配置配方";
        }
        catch { }
    }

    // ------------------------------------------------------------------
    // 打开 / 关闭浏览面板
    // ------------------------------------------------------------------
    private static void OnDockPressed()
    {
        try
        {
            Player player;
            CombatState combat;
            if (!TryGetCombatContext(out player, out combat))
            {
                ShowIdleHint();
                return;
            }
            OpenBrowse();
        }
        catch (Exception e)
        {
            Log.Error("CardExchangePanel: 打开面板失败 - " + e.GetType().Name + ": " + e.Message);
        }
    }

    private static async void ShowIdleHint()
    {
        try
        {
            if (_dockButton == null || !GodotObject.IsInstanceValid(_dockButton)) return;
            _dockButton.Text = "战斗外不可用…";
            await System.Threading.Tasks.Task.Delay(1500);
            if (_dockButton != null && GodotObject.IsInstanceValid(_dockButton))
            {
                _dockButton.Text = "卡牌交换";
            }
        }
        catch { }
    }

    private static void OpenBrowse()
    {
        if (_browse != null && GodotObject.IsInstanceValid(_browse))
        {
            CloseBrowse();
            return;
        }
        NRun root = NRun.Instance;
        if (root == null) return;

        Player checkPlayer;
        CombatState checkCombat;
        if (!TryGetCombatContext(out checkPlayer, out checkCombat)) return;

        _browse = new Control();
        _browse.Name = "__CardExchangeBrowse";
        _browse.AnchorLeft = 0f; _browse.AnchorTop = 0f; _browse.AnchorRight = 1f; _browse.AnchorBottom = 1f;
        _browse.OffsetLeft = 0f; _browse.OffsetTop = 0f; _browse.OffsetRight = 0f; _browse.OffsetBottom = 0f;

        ColorRect bg = new ColorRect();
        bg.Color = new Color(0f, 0f, 0f, 0.72f);
        bg.AnchorLeft = 0f; bg.AnchorTop = 0f; bg.AnchorRight = 1f; bg.AnchorBottom = 1f;
        bg.OffsetLeft = 0f; bg.OffsetTop = 0f; bg.OffsetRight = 0f; bg.OffsetBottom = 0f;
        bg.MouseFilter = Control.MouseFilterEnum.Stop;
        _browse.AddChild(bg);

        Label title = new Label();
        title.Text = "卡牌交换 —— 点击储藏卡：付出手牌里两张指定卡，储藏卡直接进手牌";
        title.HorizontalAlignment = Godot.HorizontalAlignment.Center;
        title.AddThemeFontSizeOverride("font_size", 22);
        title.AnchorLeft = 0f; title.AnchorTop = 0f; title.AnchorRight = 1f; title.AnchorBottom = 0f;
        title.OffsetLeft = 0f; title.OffsetTop = 18f; title.OffsetRight = 0f; title.OffsetBottom = 52f;
        _browse.AddChild(title);

        Button closeBtn = new Button();
        closeBtn.Text = "关闭 ✕";
        closeBtn.AnchorLeft = 1f; closeBtn.AnchorTop = 0f; closeBtn.AnchorRight = 1f; closeBtn.AnchorBottom = 0f;
        closeBtn.OffsetLeft = -124f; closeBtn.OffsetTop = 16f; closeBtn.OffsetRight = -16f; closeBtn.OffsetBottom = 52f;
        closeBtn.Pressed += OnClosePressed;
        _browse.AddChild(closeBtn);

        ScrollContainer scroll = new ScrollContainer();
        scroll.AnchorLeft = 0.06f; scroll.AnchorTop = 0.09f; scroll.AnchorRight = 0.94f; scroll.AnchorBottom = 0.93f;
        scroll.OffsetLeft = 0f; scroll.OffsetTop = 0f; scroll.OffsetRight = 0f; scroll.OffsetBottom = 0f;
        _browseGrid = new GridContainer();
        _browseGrid.Columns = 5;
        _browseGrid.SizeFlagsHorizontal = Control.SizeFlags.Fill;
        _browseGrid.SizeFlagsVertical = Control.SizeFlags.Fill;
        scroll.AddChild(_browseGrid);
        _browse.AddChild(scroll);

        root.AddChild(_browse);
        RebuildBrowseContent();
    }

    private static void OnClosePressed()
    {
        CloseBrowse();
    }

    private static void CloseBrowse()
    {
        // 先按池规矩归还卡牌节点，再销毁面板（防止 QueueFree 连坐池节点）
        CleanupPooledCards();
        try
        {
            if (_browse != null && GodotObject.IsInstanceValid(_browse)) _browse.QueueFree();
        }
        catch { }
        _browse = null;
        _browseGrid = null;
        UpdateDockHint();
    }

    private static void OnDockExiting()
    {
        try { CleanupPooledCards(); } catch { }
    }

    // ------------------------------------------------------------------
    // 浏览面板内容
    // ------------------------------------------------------------------
    private static void RebuildBrowseContent()
    {
        try
        {
            if (_browseGrid == null || !GodotObject.IsInstanceValid(_browseGrid)) return;

            // 归还旧卡牌节点（Free → 出树）
            CleanupPooledCards();

            // 清掉普通格子节点（此时格子里已不含池节点）
            foreach (Node child in _browseGrid.GetChildren())
            {
                try { child.QueueFree(); } catch { }
            }

            if (_recipes.Count == 0)
            {
                Label empty = new Label();
                empty.Text = "未配置配方：去 Sts2CharForge 顶部「交换配方」页签添加，并点「生成到当前工程」。";
                empty.HorizontalAlignment = Godot.HorizontalAlignment.Center;
                empty.AddThemeFontSizeOverride("font_size", 18);
                _browseGrid.AddChild(empty);
                return;
            }

            Player player = GetLocalPlayer();
            int shown = 0;
            for (int i = 0; i < _recipes.Count; i++)
            {
                Recipe r = _recipes[i];
                if (AddRecipeCell(r, player)) shown++;
            }
            if (shown == 0)
            {
                Label none = new Label();
                none.Text = "配方里的储藏卡都未能显示（解析失败）——请看游戏日志 \"CardExchangePanel:\" 开头的行。";
                none.HorizontalAlignment = Godot.HorizontalAlignment.Center;
                none.AddThemeFontSizeOverride("font_size", 16);
                _browseGrid.AddChild(none);
            }
        }
        catch (Exception e)
        {
            Log.Error("CardExchangePanel: 刷新面板失败 - " + e.GetType().Name + ": " + e.Message);
        }
    }

    private static bool AddRecipeCell(Recipe r, Player player)
    {
        CardModel vault = GetCanonical(r.VaultClass);
        if (vault == null) return false;

        Control cell = new Control();
        cell.CustomMinimumSize = new Vector2(160f, 300f);

        // NCard 只做显示（池节点，不挂任何事件）。
        // 注意：card.tscn 的卡内容以节点原点为中心（偏移 -150,-211 ~ 150,211），
        // 所以 Position 是【卡中心】要落在的位置，不是卡左上角！
        NCard ncard = NCard.Create(vault);
        if (ncard == null)
        {
            Log.Error("CardExchangePanel: NCard.Create 渲染储藏卡 " + r.VaultClass + " 失败（格子已跳过）。");
            try { cell.QueueFree(); } catch { }
            return false;
        }
        ncard.Scale = new Vector2(0.5f, 0.5f);    // 卡 300x422 → 150x211
        ncard.Position = new Vector2(80f, 120f);  // 卡中心：格宽 160 居中、偏上（底部留给说明文字）
        try { ncard.UpdateVisuals(PileType.Deck, CardPreviewMode.Normal); }
        catch (Exception e) { Log.Error("CardExchangePanel: UpdateVisuals 失败 - " + e.GetType().Name + ": " + e.Message); }
        _pooledCards.Add(ncard);
        cell.AddChild(ncard);

        // 代价：手牌里要凑得出所有【已设置】的代价卡（2~4 张均可，留空的不参与；同类多张需有多个实例）
        bool can = CanAfford(player, r);
        if (!can) ncard.Modulate = new Color(0.55f, 0.55f, 0.55f, 0.85f);

        Label label = new Label();
        List<string> parts = new List<string>();
        for (int i = 0; i < r.CostClasses.Length; i++)
        {
            string cls = r.CostClasses[i];
            string kw = r.CostKeywords[i];
            if (string.IsNullOrEmpty(cls) && string.IsNullOrEmpty(kw)) continue;
            // V1.9：选了关键词 → 指定卡被屏蔽（解析层已归一，这里只会出现其一）
            string cond = !string.IsNullOrEmpty(kw) ? ("任意「" + kw + "」卡") : TitleOf(cls);
            parts.Add(cond + ModeTag(r.CostDiscards[i]));
        }
        string need = parts.Count > 0 ? ("需要：" + string.Join(" + ", parts)) : "未设代价卡（免费交换）";
        if (!can) need += "\n（手牌里凑不出）";
        label.Text = need;
        label.HorizontalAlignment = Godot.HorizontalAlignment.Center;
        label.AddThemeFontSizeOverride("font_size", 12);
        label.AutowrapMode = TextServer.AutowrapMode.Arbitrary;   // 4 张卡名较长，自动换行
        label.AnchorLeft = 0f; label.AnchorTop = 1f; label.AnchorRight = 1f; label.AnchorBottom = 1f;
        label.OffsetLeft = 4f; label.OffsetTop = -64f; label.OffsetRight = 4f; label.OffsetBottom = -4f;
        cell.AddChild(label);

        if (can)
        {
            // 透明点击层（普通节点，随格子销毁）——点击检测不落在池节点上
            Control hit = new Control();
            hit.Name = "__Hit";
            hit.AnchorLeft = 0f; hit.AnchorTop = 0f; hit.AnchorRight = 1f; hit.AnchorBottom = 1f;
            hit.OffsetLeft = 0f; hit.OffsetTop = 0f; hit.OffsetRight = 0f; hit.OffsetBottom = 0f;
            hit.MouseFilter = Control.MouseFilterEnum.Stop;
            Recipe captured = r;
            hit.GuiInput += (InputEvent ev) => OnHitGuiInput(ev, captured);
            cell.AddChild(hit);
        }

        _browseGrid.AddChild(cell);
        return true;
    }

    private static void OnHitGuiInput(InputEvent @event, Recipe r)
    {
        try
        {
            if (!(@event is InputEventMouseButton mb) || !mb.Pressed || mb.ButtonIndex != MouseButton.Left) return;
            _ = DoExchange(r);
        }
        catch (Exception e)
        {
            Log.Error("CardExchangePanel: 点击处理失败 - " + e.GetType().Name + ": " + e.Message);
        }
    }

    // ------------------------------------------------------------------
    // 交换（战斗内，不限次数）：手牌付出【已设置】的代价卡（最多4张）→ 每张各自按配置进消耗堆/弃牌堆；储藏卡 → 生成进手牌
    // ------------------------------------------------------------------
    private static async System.Threading.Tasks.Task DoExchange(Recipe r)
    {
        if (_exchanging) return;
        _exchanging = true;
        try
        {
            Player player;
            CombatState combat;
            if (!TryGetCombatContext(out player, out combat))
            {
                Log.Info("CardExchangePanel: 当前不在进行中的战斗里，无法交换。");
                return;
            }

            // 代价卡从【手牌】里找（按设置顺序逐张占位；留空的不参与；同类设多张时各占一个实例）
            List<CardModel> picked;
            List<bool> discards;
            if (!TryFindCosts(player, r, out picked, out discards))
            {
                Log.Info("CardExchangePanel: 手牌里凑不出全部代价卡，无法交换。");
                return;
            }

            // 付出代价：每张卡的去处【单独】由配方行里的下拉决定——
            //   丢弃 → CardCmd.Discard（本体正规弃牌：含战斗历史、AfterCardDiscarded 钩子、
            //           弃牌堆 UI 刷新，弃牌触发类效果也能正确联动；本场可再抽到）；
            //   消耗 → CardPileCmd.Add(card, Exhaust)（本场移除、战后回卡组；实测正常）；
            //   （两者都会自动从手牌移除 + 搬运动画）
            //   多张丢弃攒起来用集合重载一次送走（本体注释：多张弃牌别循环调用，Sly 时序才正确）。
            List<CardModel> discardBatch = new List<CardModel>();
            for (int i = 0; i < picked.Count; i++)
            {
                if (discards[i]) discardBatch.Add(picked[i]);
                else await CardPileCmd.Add(picked[i], PileType.Exhaust);
            }
            if (discardBatch.Count > 0)
            {
                // ThrowingPlayerChoiceContext：本体给「无出牌上下文」场景用的 context；
                // 开头自带 IsOverOrEnding 守卫：战斗结束瞬间调用会被安全跳过。
                await CardCmd.Discard(new ThrowingPlayerChoiceContext(), discardBatch);
            }

            // 获得：储藏卡按本体「战斗内生成牌」的正规路径直接进手牌（含战斗历史与钩子；手牌满自动落弃牌堆）
            CardModel vault = GetCanonical(r.VaultClass);
            if (vault == null) return;
            CardModel newCard = combat.CreateCard(vault, player);
            await CardPileCmd.AddGeneratedCardToCombat(newCard, PileType.Hand, player);

            List<string> destParts = new List<string>();
            for (int i = 0; i < picked.Count; i++)
            {
                destParts.Add("代价" + (i + 1) + "进" + PileName(discards[i]));
            }
            Log.Info("CardExchangePanel: 交换成功，" + r.VaultClass + " 已生成到手牌（" + (destParts.Count > 0 ? string.Join("，", destParts) : "无代价") + "）。");
            RebuildBrowseContent();
        }
        catch (Exception e)
        {
            Log.Error("CardExchangePanel: 交换失败 - " + e.GetType().Name + ": " + e.Message);
        }
        finally
        {
            _exchanging = false;
        }
    }

    // ------------------------------------------------------------------
    // 池节点归还（Free → 出树，绝不 QueueFree）
    // ------------------------------------------------------------------
    private static void CleanupPooledCards()
    {
        for (int i = 0; i < _pooledCards.Count; i++)
        {
            NCard card = _pooledCards[i];
            try
            {
                if (card != null && GodotObject.IsInstanceValid(card))
                {
                    NodePool.Free(card);
                    Node parent = card.GetParent();
                    if (parent != null) parent.RemoveChild(card);
                }
            }
            catch (Exception e)
            {
                Log.Error("CardExchangePanel: 归还卡牌节点失败 - " + e.GetType().Name + ": " + e.Message);
            }
        }
        _pooledCards.Clear();
    }

    // ------------------------------------------------------------------
    // 配方读取（反射，类不存在 = 空配方，不编译失败）
    // ------------------------------------------------------------------
    private static void ReloadRecipes()
    {
        _recipes.Clear();
        try
        {
            Type t = ResolveType("ExchangeRecipes");
            if (t == null) return;
            System.Reflection.FieldInfo f = t.GetField("Entries");
            string[][] entries = f?.GetValue(null) as string[][];
            if (entries == null) return;
            foreach (string[] row in entries)
            {
                if (row == null || row.Length < 3) continue;
                Recipe r = new Recipe();
                r.VaultClass = row[0] ?? "";
                if (row.Length >= 13)
                {
                    // V1.7 格式：{ 储藏卡, (卡1, 关键词1, 去处1) … (卡4, 关键词4, 去处4) }；卡类与关键词都空 = 该位不启用
                    for (int i = 0; i < 4; i++)
                    {
                        r.CostClasses[i] = row[1 + i * 3] ?? "";
                        // V1.8：关键词栏是 pick 下拉，「（不启用）」哨兵归一为空
                        string kwRaw = row[2 + i * 3] ?? "";
                        r.CostKeywords[i] = (kwRaw == "（不启用）" || kwRaw == "（无）") ? "" : kwRaw;
                        // V1.9：选了关键词 → 屏蔽该位的指定卡（关键词优先，二选一；不再叠加成“且”）
                        if (!string.IsNullOrEmpty(r.CostKeywords[i])) r.CostClasses[i] = "";
                        r.CostDiscards[i] = IsDiscard(row[3 + i * 3]);
                    }
                }
                else if (row.Length >= 9)
                {
                    // V1.6 格式：{ 储藏卡, 卡1, 卡1去处, 卡2, 卡2去处, 卡3, 卡3去处, 卡4, 卡4去处 }（卡3/卡4留空不启用）
                    for (int i = 0; i < 4; i++)
                    {
                        r.CostClasses[i] = row[1 + i * 2] ?? "";
                        r.CostDiscards[i] = IsDiscard(row[2 + i * 2]);
                    }
                }
                else if (row.Length >= 5)
                {
                    // V1.5 格式：{ 储藏卡, 代价卡1, 卡1去处, 代价卡2, 卡2去处 }
                    r.CostClasses[0] = row[1] ?? "";
                    r.CostDiscards[0] = IsDiscard(row[2]);
                    r.CostClasses[1] = row[3] ?? "";
                    r.CostDiscards[1] = IsDiscard(row[4]);
                }
                else
                {
                    // 旧 3 元素格式：{ 储藏卡, 代价卡1, 代价卡2 }——两张都按消耗（旧行为）
                    r.CostClasses[0] = row[1] ?? "";
                    r.CostClasses[1] = row[2] ?? "";
                }
                if (!string.IsNullOrEmpty(r.VaultClass)) _recipes.Add(r);
            }
        }
        catch (Exception e)
        {
            Log.Error("CardExchangePanel: 读取配方失败 - " + e.GetType().Name + ": " + e.Message);
        }
    }

    // ------------------------------------------------------------------
    // 关键词匹配：本体 CardKeyword 枚举 + 编辑器/自定义词条（HoverTips）
    // ------------------------------------------------------------------
    private static bool CardMatchesKeyword(CardModel c, string kw)
    {
        try
        {
            if (c == null || string.IsNullOrEmpty(kw)) return false;
            // 1) 本体结构化关键词：填中文别名或英文枚举名
            if (TryParseBuiltinKeyword(kw, out CardKeyword bk) && c.Keywords.Contains(bk)) return true;
            // 2) 编辑器自定义关键词：KEYWORD_N 编号或词条显示名
            return MatchesCustomKeyword(c, kw);
        }
        catch (Exception e)
        {
            Log.Error("CardExchangePanel: 关键词匹配失败 - " + e.GetType().Name + ": " + e.Message);
            return false;
        }
    }

    private static bool TryParseBuiltinKeyword(string s, out CardKeyword k)
    {
        string t = (s ?? "").Trim();
        switch (t.ToLowerInvariant())
        {
            case "exhaust": case "消耗": k = CardKeyword.Exhaust; return true;
            case "ethereal": case "虚无": k = CardKeyword.Ethereal; return true;
            case "innate": case "固有": case "固始": k = CardKeyword.Innate; return true;
            case "unplayable": case "不能被打出": case "不可打出": case "无法打出": k = CardKeyword.Unplayable; return true;
            case "retain": case "保留": k = CardKeyword.Retain; return true;
            case "sly": case "奇巧": case "灵巧": case "狡黠": k = CardKeyword.Sly; return true;
            case "eternal": case "永恒": k = CardKeyword.Eternal; return true;
        }
        k = CardKeyword.None;
        return false;
    }

    private static bool MatchesCustomKeyword(CardModel c, string kw)
    {
        try
        {
            foreach (MegaCrit.Sts2.Core.HoverTips.IHoverTip tip in c.HoverTips)
            {
                if (tip == null) continue;
                // 编号写法（如 KEYWORD_5）：精确匹配 LocString 键，不会误伤 KEYWORD_50
                if (!string.IsNullOrEmpty(tip.Id) && tip.Id.IndexOf(kw + ".title", StringComparison.OrdinalIgnoreCase) >= 0) return true;
                // 显示名写法（如「烙印」）：HoverTip 拆箱后比 Title
                if (tip is MegaCrit.Sts2.Core.HoverTips.HoverTip ht && !string.IsNullOrEmpty(ht.Title) && ht.Title.IndexOf(kw, StringComparison.OrdinalIgnoreCase) >= 0) return true;
            }
        }
        catch (Exception e)
        {
            Log.Error("CardExchangePanel: 匹配自定义关键词失败 - " + e.GetType().Name + ": " + e.Message);
        }
        return false;
    }

    // ------------------------------------------------------------------
    // 类型解析
    // ------------------------------------------------------------------
    // 类名 → Type：先按全名查（global 顶级类，如 ExchangeRecipes）；查不到再按简单类名
    // 遍历程序集匹配（编辑器生成的卡类在 namespace <存档名> 下，如 Albaz.VirtuousCard5），
    // 同名时优先继承 CardModel 的类型。
    private static Type ResolveType(string name)
    {
        if (string.IsNullOrEmpty(name)) return null;
        try
        {
            Type hit;
            if (_typeCache.TryGetValue(name, out hit)) return hit;

            System.Reflection.Assembly asm = typeof(CardExchangePanel).Assembly;
            hit = asm.GetType(name, false);
            if (hit == null)
            {
                Type[] all;
                try { all = asm.GetTypes(); }
                catch (System.Reflection.ReflectionTypeLoadException ex) { all = ex.Types; }
                foreach (Type ct in all)
                {
                    if (ct == null || ct.Name != name) continue;
                    if (typeof(CardModel).IsAssignableFrom(ct)) { hit = ct; break; }
                    if (hit == null) hit = ct;
                }
            }
            _typeCache[name] = hit;
            return hit;
        }
        catch
        {
            return null;
        }
    }

    private static CardModel GetCanonical(string cardClass)
    {
        try
        {
            if (string.IsNullOrEmpty(cardClass)) return null;
            Type t = ResolveType(cardClass);
            if (t == null)
            {
                Log.Error("CardExchangePanel: 找不到卡类 " + cardClass + "（配方里选的卡在当前 mod 里不存在？）");
                return null;
            }
            CardModel model = ModelDb.GetById<CardModel>(ModelDb.GetId(t));
            if (model == null)
            {
                Log.Error("CardExchangePanel: 卡类 " + cardClass + " 已找到，但 ModelDb 里查不到实例（未注册/未加载？）。");
                return null;
            }
            return model;
        }
        catch (Exception e)
        {
            Log.Error("CardExchangePanel: 解析卡 " + cardClass + " 失败 - " + e.GetType().Name + ": " + e.Message);
            return null;
        }
    }

    private static string TitleOf(string cardClass)
    {
        CardModel m = GetCanonical(cardClass);
        if (m != null)
        {
            try
            {
                string title = m.Title;
                if (!string.IsNullOrEmpty(title)) return title;
            }
            catch { }
        }
        return cardClass;
    }

    // 去处判定（兼容编辑器 pick 的长短文案）：含“丢弃” = 弃牌堆，否则消耗堆
    private static bool IsDiscard(string mode)
    {
        return !string.IsNullOrEmpty(mode) && mode.Contains("丢弃");
    }

    // 面板说明文字里的去处标注
    private static string ModeTag(bool discard)
    {
        return discard ? "（丢弃）" : "（消耗）";
    }

    private static string PileName(bool discard)
    {
        return discard ? "弃牌堆" : "消耗堆";
    }

    private static CardModel FindCost(Player player, Recipe r, int slot, List<CardModel> exclude)
    {
        try
        {
            if (player == null) return null;
            string cls = r.CostClasses[slot];
            string kw = r.CostKeywords[slot];
            if (string.IsNullOrEmpty(cls) && string.IsNullOrEmpty(kw)) return null;   // 该位未启用
            CardPile hand = PileType.Hand.GetPile(player);
            if (hand == null) return null;
            foreach (CardModel c in hand.Cards)
            {
                if (c == null) continue;
                if (exclude != null && exclude.Contains(c)) continue;
                if (!string.IsNullOrEmpty(cls) && c.GetType().Name != cls) continue;      // 指定卡条件
                if (!string.IsNullOrEmpty(kw) && !CardMatchesKeyword(c, kw)) continue;    // 关键词条件
                return c;
            }
        }
        catch (Exception e)
        {
            Log.Error("CardExchangePanel: 查询手牌失败 - " + e.GetType().Name + ": " + e.Message);
        }
        return null;
    }

    // 按配方顺序从手牌里找出【全部已设置】的代价卡（卡类或关键词至少一个非空即启用）；
    // 逐张占位，同类/同关键词设多张时各占一个实例。
    // 返回 false = 手牌凑不出；picked 为空 = 配方未设任何代价（免费交换，仍算凑得出）。
    private static bool TryFindCosts(Player player, Recipe r, out List<CardModel> picked, out List<bool> discards)
    {
        picked = new List<CardModel>();
        discards = new List<bool>();
        for (int i = 0; i < r.CostClasses.Length; i++)
        {
            if (string.IsNullOrEmpty(r.CostClasses[i]) && string.IsNullOrEmpty(r.CostKeywords[i])) continue;
            CardModel found = FindCost(player, r, i, picked);
            if (found == null) return false;
            picked.Add(found);
            discards.Add(r.CostDiscards[i]);
        }
        return true;
    }

    // 面板置灰判定（只要能不能凑出全部代价卡，不关心具体实例）
    private static bool CanAfford(Player player, Recipe r)
    {
        List<CardModel> p;
        List<bool> d;
        return TryFindCosts(player, r, out p, out d);
    }
}
