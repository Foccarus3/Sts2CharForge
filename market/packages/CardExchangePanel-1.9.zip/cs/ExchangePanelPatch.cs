﻿// 「卡牌交换面板」安装补丁（V1.0）。
// Run 的全局 UI（NGlobalUi，地图/各类房间都盖在它上面）就绪时，把左侧「卡牌交换」按钮挂上去。
// 只做 Postfix 追加，不改本体任何返回值；全部逻辑都在 CardExchangePanel.TryInstall 里 try-catch 兜底。

using MegaCrit.Sts2.Core.Nodes.CommonUi;

[HarmonyLib.HarmonyPatch(typeof(NGlobalUi), "_Ready")]
public static class CardExchangePanelInstallPatch
{
    static void Postfix(NGlobalUi __instance)
    {
        CardExchangePanel.TryInstall(__instance);
    }
}
