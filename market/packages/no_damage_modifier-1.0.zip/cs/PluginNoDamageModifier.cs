// 插件「全局禁止加伤/减伤」自带的 C# —— 随模组一起编译。
// Sts2CharForge 生成工程时会把本文件拷到 cs\Plugins\no_damage_modifier\ 下，和模组编在同一个 dll 里。
//
// ─────────────────────────────────────────────────────────────────────────────
// 为什么这么点补丁就够
//
// 本体（sts2.dll）的伤害与格挡都只在同一个地方汇总修正：
//   · Hook.ModifyDamage(IRunState, ICombatState, Creature target, Creature dealer, decimal damage,
//                       ValueProp props, CardModel cardSource, CardPlay cardPlay,
//                       ModifyDamageHookType, CardPreviewMode, ref IEnumerable<AbstractModel> modifiers)
//       → 把「力量 / 虚弱 / 易伤 / 缓慢 / 各种增伤减伤 / 遗物 / 附魔」全部算进返回值；
//         编辑器自己的「斩杀预判」也是直接调它，注释写的是「这一击的真实伤害（含力量 / 易伤等修正）」。
//   · Hook.ModifyBlock(ICombatState, Creature target, decimal block, ValueProp props,
//                      CardModel cardSource, CardPlay cardPlay, ref IEnumerable<AbstractModel> modifiers)
//       → 敏捷 / 脆弱 / 遗物与附魔的格挡加值。
//   · Hook.ModifyAttackHitCount(ICombatState, AttackCommand, int originalHitCount)
//       → 连击次数修正（多打一下也是加伤）。
//
// 以上调用链已在 sts2.dll 上用 IL 扫描核实（不是推测）：
//   Hook.ModifyDamage → Hook.ModifyDamageInternal
//        → AbstractModel.ModifyDamageAdditive / ModifyDamageMultiplicative / ModifyDamageCap
//   实际结算那一击的 Damage 命令（async 状态机 <Damage>）与卡牌 OnPlay 都调 Hook.ModifyDamage；
//   GainBlock 的 async 状态机与 OnPlay 调 Hook.ModifyBlock（内部再调 ModifyBlockAdditive / Multiplicative）；
//   攻击 Execute 的状态机调 Hook.ModifyAttackHitCount。
//   也就是说：伤害的加法修正、乘法修正、硬上限（无实体 / HardToKill）全在 ModifyDamage 这一条里。
//
// 生效期间：在这三个静态钩子上挂 Harmony 前缀，直接返回**传进来的基础数值**并跳过原方法体，
// 修正来源（状态 / 遗物 / 附魔 / 卡牌 / 敌人招式）一律不参与 —— 这就是「无法通过任何方式加伤减伤」。
//
// 但 Harmony 的语义是：前缀 return false 只跳过**原方法**，别的 mod 挂在同一个方法上的**后缀照样会执行**
// （它们拿到我们的 __result 继续改）。所以三条通道各再挂一条**最低优先级（Priority.Last）**的后缀做兜底，
// 在所有人之后再跑一次，把返回值压回基础值；前缀则用 Priority.First，先于别人的前缀执行，
// 保证短路掉原方法、别人连改入参的机会都没有。
// 实测：在 Hook.ModifyDamage 上另挂一个「+5」的普通优先级后缀，开闸后最终结果仍是基础值。
//
// 为什么不挂状态（PowerModel）：
//   · 状态类会进 ModelDb 注册，不同模组撞同名会启动即冲突；
//   · 状态只影响「持有者」的修正，管不到敌方 / 队友的全部修正通道；
//   · 本效果是「全局规则」，纯静态开关最干净（也不用本地化图标，不会在状态栏多一堆图标）。
//
// 生命周期：开关绑定在**那一刻的战斗状态实例**上（ICombatState 按引用比较），
// 战斗一换实例就自动失效，不会带到下一场；兜底清零挂在 BeforeCombatStart 的**前缀**
// （先于遗物 / 药水那些订阅执行，避免把「战斗开始时施加本效果」的开关清掉）与 AfterCombatEnd 的**后缀**。
// ─────────────────────────────────────────────────────────────────────────────

#nullable enable

using System;
using System.Collections.Generic;
using MegaCrit.Sts2.Core.Combat;
using MegaCrit.Sts2.Core.Entities.Creatures;
using MegaCrit.Sts2.Core.Entities.Players;
using MegaCrit.Sts2.Core.Hooks;
using MegaCrit.Sts2.Core.Logging;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Modding;

namespace Plugins.NoDamageModifier;

/// <summary>
/// 全局开关：现在的这场战斗里，「加伤 / 减伤」是否被禁止。
/// 只认施加时那一刻的 ICombatState 实例 —— 换战斗实例即失效，天然不会跨战斗残留。
/// </summary>
public static class NoDamageModifierGate
{
    private static ICombatState? _combat;
    private static Creature? _caster;
    private static int _turnsLeft;
    private static bool _untilCombatEnd;

    /// <summary>这个战斗状态下是否生效（补丁每次计算伤害 / 格挡都会问一次）。</summary>
    public static bool IsActive(ICombatState? combatState)
    {
        if (combatState is null)
        {
            return false;
        }

        if (!ReferenceEquals(combatState, _combat))
        {
            return false;
        }

        return _untilCombatEnd || _turnsLeft > 0;
    }

    /// <summary>「N 回合」版：1 = 本回合（到自己的下个回合开始）。重复施加取较长的那次，不叠加。</summary>
    internal static void EnableTurns(ICombatState? combatState, Creature? caster, decimal turns)
    {
        if (combatState is null)
        {
            return;
        }

        int n = (int)decimal.Ceiling(turns);
        if (n < 1)
        {
            n = 1;
        }

        _combat = combatState;
        _caster = caster;
        if (n > _turnsLeft)
        {
            _turnsLeft = n;
        }

        Log.Info($"[no_damage_modifier] 已开启：{n} 个回合内所有角色无法加伤/减伤");
    }

    /// <summary>「本场战斗」版：到这场战斗结束。</summary>
    internal static void EnableCombat(ICombatState? combatState, Creature? caster)
    {
        if (combatState is null)
        {
            return;
        }

        _combat = combatState;
        _caster = caster;
        _untilCombatEnd = true;
        Log.Info("[no_damage_modifier] 已开启：本场战斗内所有角色无法加伤/减伤");
    }

    /// <summary>玩家回合开始：谁的回合开始就扣谁的那一份；施加者不是玩家时按任意玩家的回合开始扣。</summary>
    internal static void OnPlayerTurnStart(ICombatState? combatState, Player? player)
    {
        if (combatState is null || !ReferenceEquals(combatState, _combat) || _turnsLeft <= 0)
        {
            return;
        }

        Player? owner = _caster?.Player;
        if (owner is not null && player is not null && player != owner)
        {
            return;
        }

        _turnsLeft--;
        if (_turnsLeft <= 0)
        {
            _turnsLeft = 0;
            Log.Info("[no_damage_modifier] 回合版已到期，解除");
        }
    }

    /// <summary>兜底：战斗开始 / 结束时清零（正常流程里靠实例比较已经够用）。</summary>
    internal static void Reset()
    {
        _combat = null;
        _caster = null;
        _turnsLeft = 0;
        _untilCombatEnd = false;
    }
}

/// <summary>
/// 伤害修正：生效时直接返回传进来的基础伤害，跳过原方法（力量 / 虚弱 / 易伤 / 缓慢 / 遗物 / 附魔…全部不算）。
/// </summary>
internal static class NoModifierDamagePatch
{
    public static bool Prefix(ICombatState combatState, decimal damage, ref IEnumerable<AbstractModel> modifiers, ref decimal __result)
    {
        try
        {
            if (!NoDamageModifierGate.IsActive(combatState))
            {
                return true;   // 没开：走本体原逻辑
            }

            modifiers = Array.Empty<AbstractModel>();   // 原方法会为「修正后通知」填这个列表；跳过原方法就交空表，避免调用方拿到 null
            __result = damage;
            return false;
        }
        catch (Exception e)
        {
            Log.Error("[no_damage_modifier] 伤害修正补丁出错（已退回本体逻辑）：" + e.Message);
            return true;
        }
    }
}

/// <summary>
/// 格挡修正：生效时直接返回基础格挡，跳过原方法（敏捷 / 脆弱 / 遗物 / 附魔的格挡加值全部不算）。
/// </summary>
internal static class NoModifierBlockPatch
{
    public static bool Prefix(ICombatState combatState, decimal block, ref IEnumerable<AbstractModel> modifiers, ref decimal __result)
    {
        try
        {
            if (!NoDamageModifierGate.IsActive(combatState))
            {
                return true;
            }

            modifiers = Array.Empty<AbstractModel>();
            __result = block;
            return false;
        }
        catch (Exception e)
        {
            Log.Error("[no_damage_modifier] 格挡修正补丁出错（已退回本体逻辑）：" + e.Message);
            return true;
        }
    }
}

/// <summary>攻击次数修正：生效时返回基础次数（多打一下也是加伤）。</summary>
internal static class NoModifierHitCountPatch
{
    public static bool Prefix(ICombatState combatState, int originalHitCount, ref decimal __result)
    {
        try
        {
            if (!NoDamageModifierGate.IsActive(combatState))
            {
                return true;
            }

            __result = originalHitCount;
            return false;
        }
        catch (Exception e)
        {
            Log.Error("[no_damage_modifier] 攻击次数修正补丁出错（已退回本体逻辑）：" + e.Message);
            return true;
        }
    }
}

/// <summary>
/// 兜底（伤害）：Harmony 里前缀 return false 只会跳过原方法，**别的 mod 的后缀照样会跑**。
/// 所以这里再挂一条优先级最低（Last）的后缀，把返回值压回传进来的基础值。
/// </summary>
internal static class NoModifierDamageGuardPatch
{
    public static void Postfix(ICombatState combatState, decimal damage, ref decimal __result)
    {
        try
        {
            if (!NoDamageModifierGate.IsActive(combatState))
            {
                return;
            }

            __result = damage;
        }
        catch (Exception e)
        {
            Log.Error("[no_damage_modifier] 伤害兜底后缀出错（已忽略）：" + e.Message);
        }
    }
}

/// <summary>兜底（格挡）：同伤害，防别的 mod 的后缀把格挡改回去。</summary>
internal static class NoModifierBlockGuardPatch
{
    public static void Postfix(ICombatState combatState, decimal block, ref decimal __result)
    {
        try
        {
            if (!NoDamageModifierGate.IsActive(combatState))
            {
                return;
            }

            __result = block;
        }
        catch (Exception e)
        {
            Log.Error("[no_damage_modifier] 格挡兜底后缀出错（已忽略）：" + e.Message);
        }
    }
}

/// <summary>兜底（攻击次数）：同伤害。</summary>
internal static class NoModifierHitCountGuardPatch
{
    public static void Postfix(ICombatState combatState, int originalHitCount, ref decimal __result)
    {
        try
        {
            if (!NoDamageModifierGate.IsActive(combatState))
            {
                return;
            }

            __result = originalHitCount;
        }
        catch (Exception e)
        {
            Log.Error("[no_damage_modifier] 攻击次数兜底后缀出错（已忽略）：" + e.Message);
        }
    }
}

/// <summary>玩家回合开始：扣「N 回合」版的那一份时间。</summary>
internal static class NoModifierTurnStartPatch
{
    public static void Postfix(ICombatState combatState, Player player)
    {
        try
        {
            NoDamageModifierGate.OnPlayerTurnStart(combatState, player);
        }
        catch (Exception e)
        {
            Log.Error("[no_damage_modifier] 回合开始计时失败（已忽略）：" + e.Message);
        }
    }
}

/// <summary>
/// 战斗开始：清零（兜底）。必须挂**前缀**——本体的 BeforeCombatStart 里会执行遗物 / 药水等订阅，
/// 如果挂在后缀，就会把「战斗开始时施加本效果」的遗物刚设上的开关又清掉。
/// </summary>
internal static class NoModifierCombatStartPatch
{
    public static void Prefix(ICombatState combatState)
    {
        try
        {
            NoDamageModifierGate.Reset();
        }
        catch (Exception e)
        {
            Log.Error("[no_damage_modifier] 战斗开始清零失败（已忽略）：" + e.Message);
        }
    }
}

/// <summary>战斗结束：清零（兜底）。</summary>
internal static class NoModifierCombatEndPatch
{
    public static void Postfix(ICombatState combatState)
    {
        try
        {
            NoDamageModifierGate.Reset();
        }
        catch (Exception e)
        {
            Log.Error("[no_damage_modifier] 战斗结束清零失败（已忽略）：" + e.Message);
        }
    }
}

/// <summary>
/// 模组加载入口：手动打补丁（不用 [HarmonyPatch] 特性 → 不参与模组入口里的 PatchAll，
/// 任何一条找不到目标都只记日志，不会把整个模组拖挂）。
/// </summary>
[ModInitializer(nameof(Initialize))]
public static class NoDamageModifierRuntime
{
    private static bool _initialized;

    public static void Initialize()
    {
        if (_initialized)
        {
            return;
        }

        _initialized = true;
        string modName = typeof(NoDamageModifierRuntime).Assembly.GetName().Name ?? "mod";
        var harmony = new HarmonyLib.Harmony("Sts2CharForge.NoDamageModifier." + modName);

        // 三条伤害/格挡通道：前缀用最高优先级（先于别的 mod 的前缀跑，保证我们拿到的是原始入参），
        // 后缀用最低优先级（后于别的 mod 的后缀跑，把它们改过的返回值压回基础值）。
        PatchPrefix(harmony, "ModifyDamage", typeof(NoModifierDamagePatch), nameof(NoModifierDamagePatch.Prefix), HarmonyLib.Priority.First);
        PatchPrefix(harmony, "ModifyBlock", typeof(NoModifierBlockPatch), nameof(NoModifierBlockPatch.Prefix), HarmonyLib.Priority.First);
        PatchPrefix(harmony, "ModifyAttackHitCount", typeof(NoModifierHitCountPatch), nameof(NoModifierHitCountPatch.Prefix), HarmonyLib.Priority.First);

        PatchPostfix(harmony, "ModifyDamage", typeof(NoModifierDamageGuardPatch), nameof(NoModifierDamageGuardPatch.Postfix), HarmonyLib.Priority.Last);
        PatchPostfix(harmony, "ModifyBlock", typeof(NoModifierBlockGuardPatch), nameof(NoModifierBlockGuardPatch.Postfix), HarmonyLib.Priority.Last);
        PatchPostfix(harmony, "ModifyAttackHitCount", typeof(NoModifierHitCountGuardPatch), nameof(NoModifierHitCountGuardPatch.Postfix), HarmonyLib.Priority.Last);

        PatchPrefix(harmony, "BeforeCombatStart", typeof(NoModifierCombatStartPatch), nameof(NoModifierCombatStartPatch.Prefix));
        PatchPostfix(harmony, "AfterPlayerTurnStart", typeof(NoModifierTurnStartPatch), nameof(NoModifierTurnStartPatch.Postfix));
        PatchPostfix(harmony, "AfterCombatEnd", typeof(NoModifierCombatEndPatch), nameof(NoModifierCombatEndPatch.Postfix));

        Log.Info("[no_damage_modifier] 补丁装载完毕（3 条通道各挂前缀+兜底后缀，共 6 条；另加战斗开始清零 / 回合计时 / 战斗结束清零 3 条）");
    }

    private static void PatchPrefix(HarmonyLib.Harmony harmony, string methodName, Type patchType, string patchMethod, int? priority = null)
    {
        try
        {
            System.Reflection.MethodInfo? target = HarmonyLib.AccessTools.Method(typeof(Hook), methodName);
            if (target is null)
            {
                Log.Error($"[no_damage_modifier] 本体找不到 Hook.{methodName}，这一条不生效（其余照常）");
                return;
            }

            var hm = new HarmonyLib.HarmonyMethod(patchType, patchMethod);
            if (priority.HasValue)
            {
                hm.priority = priority.Value;
            }

            harmony.Patch(target, prefix: hm);
            Log.Info($"[no_damage_modifier] 已挂前缀：Hook.{methodName}");
        }
        catch (Exception e)
        {
            Log.Error($"[no_damage_modifier] Hook.{methodName} 补丁失败（这一条不生效，其余照常）：{e.Message}");
        }
    }

    private static void PatchPostfix(HarmonyLib.Harmony harmony, string methodName, Type patchType, string patchMethod, int? priority = null)
    {
        try
        {
            System.Reflection.MethodInfo? target = HarmonyLib.AccessTools.Method(typeof(Hook), methodName);
            if (target is null)
            {
                Log.Error($"[no_damage_modifier] 本体找不到 Hook.{methodName}，这一条不生效（其余照常）");
                return;
            }

            var hm = new HarmonyLib.HarmonyMethod(patchType, patchMethod);
            if (priority.HasValue)
            {
                hm.priority = priority.Value;
            }

            harmony.Patch(target, postfix: hm);
            Log.Info($"[no_damage_modifier] 已挂后缀：Hook.{methodName}");
        }
        catch (Exception e)
        {
            Log.Error($"[no_damage_modifier] Hook.{methodName} 补丁失败（这一条不生效，其余照常）：{e.Message}");
        }
    }
}

/// <summary>
/// 插件效果模板调用的入口。
///   · 回合版：<c>Plugins.NoDamageModifier.PluginNoDamageModifierEntry.EnableTurns({self}, {amount});</c>
///   · 本场战斗版：<c>Plugins.NoDamageModifier.PluginNoDamageModifierEntry.EnableCombat({self});</c>
/// </summary>
public static class PluginNoDamageModifierEntry
{
    /// <summary>N 回合内禁止加伤/减伤（1 = 本回合）。不在战斗里调用时什么都不做。</summary>
    public static void EnableTurns(Creature? self, decimal turns)
    {
        NoDamageModifierGate.EnableTurns(self?.CombatState, self, turns);
    }

    /// <summary>本场战斗内禁止加伤/减伤。不在战斗里调用时什么都不做。</summary>
    public static void EnableCombat(Creature? self)
    {
        NoDamageModifierGate.EnableCombat(self?.CombatState, self);
    }
}
