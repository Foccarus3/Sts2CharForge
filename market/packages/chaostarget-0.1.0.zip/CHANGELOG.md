# 更新日志

## 0.1.0（2026-11-21）

* 首个版本。
* 4 条效果：`混沌目标：本场战斗` / `本回合` / `下回合` / `解除`。
* 接管三类卡型：单体卡 `AnyEnemy` → 自己以外随机单体；随机卡 `RandomEnemy` → 可随机池扩成自己以外全场；
  群体卡 `AllEnemies` → 扩成自己以外全体。
* 全员卡 `AllAllies` 与 `AnyAlly` / `AnyPlayer` / `Osty` / `TargetedNoCreature` 一律不动。
* 目标池口径：`CombatState.Creatures` 中 `IsHittable` 且不等于出牌者的生物；随机走 `RunState.Rng.CombatTargets`，
  联机两端按 run seed 抽到同一只。
* 不注册任何模型（不占 `ModelId`、无状态图标、不进存档）；战斗结束自动清空。
* Harmony 补丁 6 处：`Hook.BeforeCardPlayed` / `Hook.AfterCardPlayed` / `Hook.AfterCombatEnd`、
  `CardPlay.Target`（getter）、`AttackCommand.GetPossibleTargets`、`CombatState.HittableEnemies`（getter）。
