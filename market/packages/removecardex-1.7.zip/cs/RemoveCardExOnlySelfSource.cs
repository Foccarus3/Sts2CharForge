// 插件 removecardex（v1.6）：为「只不删自己」效果提供 战斗副本 → 牌组原牌 的映射。
// 原理：战斗中打出的牌是战役牌组里原牌的克隆（CardModel.ToMutable），
// 这里用 Harmony 补丁 CardModel.ToMutable 的返回点，记录 副本(clone) → 原牌(source)，
// 删牌效果模板调用 GetSource(this) 查出这张战斗副本对应的牌组原牌并排除；
// 牌组里同牌名的其他原牌不在映射里，照删。
// 说明：v1.5 用 this.CanonicalInstance 排除失效——CanonicalInstance 指向的是 ModelDb
// 注册的“定义实例”，不是战役牌组里的那张牌实例；牌组实例与战斗副本之间唯一可靠的
// 联系就是克隆发生点（ToMutable），所以改为在克隆点记录映射。
using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading;
using HarmonyLib;
using MegaCrit.Sts2.Core.Models;

public static class RemoveCardExOnlySelfSource
{
    private static readonly ConditionalWeakTable<CardModel, CardModel> Map = new();
    private static int _patched;

    [ModuleInitializer]
    internal static void Init()
    {
        TryPatch();
    }

    internal static void TryPatch()
    {
        if (Interlocked.Exchange(ref _patched, 1) != 0) return;
        try
        {
            MethodInfo? m = typeof(CardModel).GetMethod(
                "ToMutable",
                BindingFlags.Public | BindingFlags.Instance,
                null,
                Type.EmptyTypes,
                null);
            if (m is null)
            {
                PatchError = "未找到 CardModel.ToMutable()";
                return;
            }
            new Harmony("removecardex.onlyself").Patch(
                m,
                postfix: new HarmonyMethod(typeof(RemoveCardExOnlySelfSource), nameof(Postfix)));
            PatchError = "OK";
        }
        catch (Exception ex)
        {
            PatchError = ex.GetType().Name + ": " + ex.Message;
        }
    }

    // Harmony 注入：__instance = 被克隆的牌组原牌，__result = 战斗副本
    internal static void Postfix(CardModel __instance, CardModel __result)
    {
        try
        {
            if (__instance is null || __result is null) return;
            Map.Remove(__result);
            Map.Add(__result, __instance);
        }
        catch
        {
        }
    }

    /// <summary>返回这张战斗副本对应的牌组原牌；查不到（非战斗副本、映射未建立等）返回 null。</summary>
    public static CardModel? GetSource(CardModel card)
    {
        TryPatch();
        return card is not null && Map.TryGetValue(card, out var src) ? src : null;
    }

    /// <summary>补丁挂载状态（排查用，不影响效果）。</summary>
    public static string PatchError { get; private set; } = "未初始化";
}
