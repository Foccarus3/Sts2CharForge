// 卡牌 GIF 替换插件：检测打出的卡，把当前逐帧动画换成插件 assets 里的 GIF。
// 依赖生成器的逐帧动画运行时（FrameAnimPlayer / __FrameAnimSprite）；没有启用动画的角色只打日志。
// 这个文件会被拷到 cs/Plugins/card_gif_swap/ 下，与模组一起编译。

using System;
using System.Collections.Generic;
using System.Reflection;
using Godot;
using HarmonyLib;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Nodes.Combat;

/// <summary>打出一张牌时检查过滤条件，命中就给该角色挂/更新一个 GIF 覆盖组件。</summary>
[HarmonyPatch(typeof(CardModel), nameof(CardModel.OnPlayWrapper))]
public static class CardGifSwapPlayPatch
{
    static void Prefix(CardModel __instance)
    {
        try { CardGifSwapRuntime.OnCardPlayed(__instance); }
        catch (Exception e) { Log.Error($"[card_gif_swap] 卡牌 GIF 替换失败: {e}"); }
    }
}

/// <summary>一条「哪张卡 → 哪张 GIF」规则；由插件扩展页的列表生成。</summary>
public sealed class CardGifEntry
{
    public string CardFilter { get; }
    public string GifFile { get; }
    public string Mode { get; }
    public bool SyncIdle { get; }

    public CardGifEntry(string cardFilter, string gifFile, string mode, bool syncIdle)
    {
        CardFilter = cardFilter ?? "";
        GifFile = gifFile ?? "";
        Mode = mode ?? "";
        SyncIdle = syncIdle;
    }
}

internal static class CardGifSwapRuntime
{
    internal static void OnCardPlayed(CardModel card)
    {
        if (card?.Owner?.Creature is null || !card.Owner.Creature.IsPlayer) return;
        var entry = FindEntry(card);
        if (entry is null) return;
        Log.Info($"[card_gif_swap] 打出 {card.GetType().Name} 命中规则「{entry.CardFilter}」→ {entry.GifFile}");
        var creature = card.Owner.Creature.GetCreatureNode();
        if (creature?.Visuals is null) return;
        if (creature.HasSpineAnimation) return;

        var comp = creature.Visuals.GetNodeOrNull<CardGifOverride>("__CardGifSwap");
        if (comp is null)
        {
            comp = new CardGifOverride { Name = "__CardGifSwap", Creature = creature };
            creature.Visuals.AddChild(comp);
        }
        comp.Activate(entry);
    }

    private static CardGifEntry? FindEntry(CardModel card)
    {
        // 列表从上到下，第一条命中的生效；把更具体的 Class 规则放上面即可覆盖 Type 规则。
        foreach (var e in CardGifSwapConfig.Entries)
            if (e is not null && Matches(e.CardFilter, card)) return e;
        return null;
    }

    private static bool Matches(string filter, CardModel card)
    {
        string f = (filter ?? "").Trim();
        if (f.Length == 0 || f.Equals("Any", StringComparison.OrdinalIgnoreCase)) return true;
        // V1.3：一个规则可以一次指定多张卡（逗号 / 顿号 / 分号 / | 分隔），
        // 例：Class:SparkleCard44,Class:SparkleCard45 或 Type:Attack,Class:SparkleCard44。
        foreach (string token in f.Split(new[] { ',', '，', ';', '；', '|' }, StringSplitOptions.RemoveEmptyEntries))
        {
            string t = token.Trim();
            if (t.Length == 0) continue;
            if (t.Equals("Any", StringComparison.OrdinalIgnoreCase)) return true;
            if (t.StartsWith("Type:", StringComparison.OrdinalIgnoreCase))
            {
                if (string.Equals(card.Type.ToString(), t[5..].Trim(), StringComparison.OrdinalIgnoreCase)) return true;
                continue;
            }
            if (t.StartsWith("Class:", StringComparison.OrdinalIgnoreCase))
            {
                if (string.Equals(card.GetType().Name, t[6..].Trim(), StringComparison.Ordinal)) return true;
                continue;
            }
            // 没写前缀时两种都认：先认类名，再认牌型
            if (string.Equals(card.GetType().Name, t, StringComparison.Ordinal)
                || string.Equals(card.Type.ToString(), t, StringComparison.OrdinalIgnoreCase)) return true;
        }
        return false;
    }
}

/// <summary>挂在角色视觉节点上的覆盖组件：只负责显示 / 回退，不改角色本身。</summary>
public sealed partial class CardGifOverride : Node
{
    private const string AnimName = "card_gif_swap";

    // V1.5：同一个 GIF 文件可能被多张卡 / 多条规则反复使用。解码一帧 800x450 的 GIF
    // 会产生几十个 ImageTexture，之前在每次 Activate 都重建，打出同一张卡就卡一下。
    // 这里按文件名缓存解码结果，换规则只换引用、不重新解码。
    private static readonly Dictionary<string, SpriteFrames> FrameCache = new(StringComparer.OrdinalIgnoreCase);

    public NCreature Creature { get; set; } = null!;

    private AnimatedSprite2D? _sprite;
    private SpriteFrames? _gifFrames;
    private CardGifEntry? _entry;
    private SpriteFrames? _idleFrames;
    private string _idleAnim = "";
    private int _idleFrame;
    private Vector2 _idleScale = Vector2.One;
    private Vector2 _idlePos;
    private bool _active;
    private bool _permanent;
    private bool _finishedHooked;
    private bool _loggedMissing;
    private bool _failed;

    public override void _Ready() => SetProcess(true);

    public void Activate(CardGifEntry entry)
    {
        if (Creature is null || !GodotObject.IsInstanceValid(Creature)) return;
        // V1.4：换一条规则（或同一角色正在播上一张卡的 GIF）时必须丢掉旧帧缓存，
        // 否则 _gifFrames ??= BuildFrames() 会一直复用它 —— 实测两条规则只播第一条的 GIF。
        CardGifEntry? previous = _entry;
        bool changed = !_active
            || previous is null
            || !string.Equals(previous.GifFile, entry.GifFile, StringComparison.Ordinal)
            || !string.Equals(previous.Mode, entry.Mode, StringComparison.Ordinal)
            || !string.Equals(previous.CardFilter, entry.CardFilter, StringComparison.Ordinal);
        _entry = entry;
        if (changed)
        {
            _gifFrames = null;
            _failed = false;
        }
        _sprite ??= FindSprite(Creature.Visuals);
        if (_sprite is null || !GodotObject.IsInstanceValid(_sprite))
        {
            if (!_loggedMissing)
            {
                _loggedMissing = true;
                Log.Warn("[card_gif_swap] 找不到 __FrameAnimSprite：请先在角色「动画」页启用逐帧动画");
            }
            return;
        }
        _permanent = entry.Mode.Contains("永久", StringComparison.Ordinal)
                     || entry.Mode.Equals("Permanent", StringComparison.OrdinalIgnoreCase);
        if (!_active) CaptureIdle();
        _active = true;
        ShowGif();
    }

    private void CaptureIdle()
    {
        if (_sprite is null) return;
        _idleFrames = _sprite.SpriteFrames;
        _idleAnim = _sprite.Animation;
        _idleFrame = _sprite.Frame;
        _idleScale = _sprite.Scale;
        _idlePos = _sprite.Position;
    }

    private void ShowGif()
    {
        if (_sprite is null || _entry is null) return;
        if (_failed) return;
        _gifFrames ??= BuildFrames();
        if (_gifFrames is null) { _failed = true; return; }
        _sprite.SpriteFrames = _gifFrames;
        _sprite.Animation = "card_gif_swap";
        _sprite.SpriteFrames.SetAnimationLoop("card_gif_swap", _permanent);
        if (_entry.SyncIdle)
        {
            _sprite.Scale = _idleScale;
            _sprite.Position = _idlePos;
        }
        if (!_finishedHooked)
        {
            _sprite.AnimationFinished += OnFinished;
            _finishedHooked = true;
        }
        _sprite.Play();
    }

    private SpriteFrames? BuildFrames()
    {
        if (_entry is null) return null;
        string file = (_entry.GifFile ?? "").Trim();
        if (file.Length == 0) return null;
        // 缓存键用「文件名 + 永久/一次」：同一个 GIF 的循环方式是 SpriteFrames 上的动画属性，
        // 一次性 / 永久不能混用同一份缓存（否则第二次会沿用第一次的 loop）。
        string cacheKey = file + "|" + (_permanent ? "loop" : "once");
        if (FrameCache.TryGetValue(cacheKey, out SpriteFrames? cached))
        {
            Log.Info($"[card_gif_swap] 复用已解码 GIF {file}（{(_permanent ? "永久" : "一次")}，不再重新解码）");
            return cached;
        }
        string userPath = CardGifSwapConfig.GifDir + file;
        string resPath = "res://plugin_assets/card_gif_swap/" + file;
        var gif = CardGifDecoder.Load(userPath);
        if (gif is null && !file.Contains("://") && !System.IO.Path.IsPathRooted(file))
            gif = CardGifDecoder.Load(resPath);
        if (gif is null && (file.Contains("://") || System.IO.Path.IsPathRooted(file)))
            gif = CardGifDecoder.Load(file);
        if (gif is null)
        {
            string full = ProjectSettings.GlobalizePath(userPath);
            Log.Warn($"[card_gif_swap] 读不到或解不开 GIF：{file}；请放到 {full}（也找过 {resPath}）");
            return null;
        }
        var (w, h, frames) = gif.Value;
        var sf = new SpriteFrames();
        sf.AddAnimation("card_gif_swap");
        foreach (var f in frames)
        {
            var img = Image.CreateFromData(w, h, false, Image.Format.Rgba8, f.Rgba);
            var tex = ImageTexture.CreateFromImage(img);
            sf.AddFrame("card_gif_swap", tex, f.Delay);
        }
        sf.SetAnimationLoop("card_gif_swap", _permanent);
        sf.SetAnimationSpeed("card_gif_swap", 1f);
        FrameCache[cacheKey] = sf;
        Log.Info($"[card_gif_swap] 已加载 {frames.Count} 帧 GIF {file}（{w}x{h}，{(_permanent ? "永久" : "一次")}）");
        return sf;
    }

    private void OnFinished()
    {
        if (!_active || _permanent || _sprite is null) return;
        if (!string.Equals(_sprite.Animation, AnimName, StringComparison.Ordinal)) return;
        _active = false;
        RestoreIdle();
    }

    private void RestoreIdle()
    {
        if (_sprite is null || !GodotObject.IsInstanceValid(_sprite)) return;
        if (_finishedHooked)
        {
            _sprite.AnimationFinished -= OnFinished;
            _finishedHooked = false;
        }
        // 优先让生成器的 FrameAnimPlayer 自己回 idle（它知道 CharDef 的参数）；
        // 取不到时退回进入覆盖前保存的帧 / 动画。
        var player = Creature?.Visuals?.GetNodeOrNull<Node>("__FrameAnimPlayer");
        if (player is not null)
        {
            try
            {
                var t = player.GetType();
                t.GetField("_current", BindingFlags.Instance | BindingFlags.NonPublic)?.SetValue(player, "");
                t.GetMethod("Play", new[] { typeof(string) })?.Invoke(player, new object[] { "idle_loop" });
                return;
            }
            catch (Exception e) { Log.Warn($"[card_gif_swap] 回待机失败，改用保存帧: {e.Message}"); }
        }
        if (_idleFrames is not null)
        {
            _sprite.SpriteFrames = _idleFrames;
            _sprite.Animation = _idleAnim;
            _sprite.Frame = Mathf.Max(0, Mathf.Min(_idleFrame, _idleFrames.GetFrameCount(_idleAnim) - 1));
            _sprite.Scale = _idleScale;
            _sprite.Position = _idlePos;
            _sprite.Play();
        }
    }

    public override void _Process(double delta)
    {
        if (Creature is null || !GodotObject.IsInstanceValid(Creature)) { _active = false; return; }
        if (Creature.Entity.IsDead) { StopForDeath(); return; }
        if (!_active) return;
        if (_sprite is null || !GodotObject.IsInstanceValid(_sprite))
        {
            _sprite = FindSprite(Creature.Visuals);
            if (_sprite is null) return;
        }
        // FrameAnimPlayer 收到 Idle / Attack 等触发会自己换帧；这里每帧把覆盖动画按回去。
        if (!string.Equals(_sprite.Animation, AnimName, StringComparison.Ordinal)
            || !ReferenceEquals(_sprite.SpriteFrames, _gifFrames))
            ShowGif();
    }

    private void StopForDeath()
    {
        _active = false;
        if (_sprite is not null && GodotObject.IsInstanceValid(_sprite) && _finishedHooked)
        {
            _sprite.AnimationFinished -= OnFinished;
            _finishedHooked = false;
        }
    }

    private static AnimatedSprite2D? FindSprite(Node? visuals)
    {
        if (visuals is null) return null;
        var body = visuals.GetNodeOrNull<Node2D>("%Visuals") ?? visuals.GetNodeOrNull<Node2D>("Visuals");
        var found = body?.GetNodeOrNull<AnimatedSprite2D>("__FrameAnimSprite")
                    ?? visuals.GetNodeOrNull<AnimatedSprite2D>("__FrameAnimSprite");
        if (found is not null) return found;
        return FindRecursive(visuals);
    }

    private static AnimatedSprite2D? FindRecursive(Node root)
    {
        for (int i = 0; i < root.GetChildCount(); i++)
        {
            var c = root.GetChild(i);
            if (c is AnimatedSprite2D a && string.Equals(a.Name.ToString(), "__FrameAnimSprite", StringComparison.Ordinal))
                return a;
            if (FindRecursive(c) is { } nested) return nested;
        }
        return null;
    }
}
