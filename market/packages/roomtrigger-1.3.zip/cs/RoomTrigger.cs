﻿#nullable enable

using System.Runtime.CompilerServices;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Rooms;
using MegaCrit.Sts2.Core.Runs;

/// <summary>
/// 房间触发辅助：判断“新的一幕（新 Act / 新章节）的第一间房”。
/// 每个宿主模型单独记录上次触发的 Act，避免多个遗物共用同一条触发时互相吞掉。
/// </summary>
public static class AbyssingRoomTrigger
{
    private static readonly ConditionalWeakTable<AbstractModel, ActStamp> LastAct = new();

    private sealed class ActStamp
    {
        public int ActIndex;
    }

    /// <summary>
    /// 当前进入的房间是不是该宿主模型在新 Act 的第一间房。
    /// 只在该 Act 的 ActFloor &lt;= 1 时成立；同一宿主同一 Act 只成立一次。
    /// </summary>
    public static bool IsNewAct(AbstractModel owner, AbstractRoom room)
    {
        RunState? state = RunManager.Instance.DebugOnlyGetState();
        if (state is null || state.ActFloor > 1)
        {
            return false;
        }

        if (!LastAct.TryGetValue(owner, out ActStamp? stamp))
        {
            stamp = new ActStamp { ActIndex = state.CurrentActIndex };
            LastAct.Add(owner, stamp);
            return true;
        }

        if (stamp.ActIndex == state.CurrentActIndex)
        {
            return false;
        }

        stamp.ActIndex = state.CurrentActIndex;
        return true;
    }
}
