#nullable enable

using HarmonyLib;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.Entities.Creatures;
using MegaCrit.Sts2.Core.Entities.Powers;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.ValueProps;

namespace Plugins.DamagePerStack;

/// <summary>
/// 伤害倍率结算时，给「在插件页登记过」的自定义状态乘上 (1 + 层数 × x%)。
///
/// 为什么用 Harmony 而不是触发时机：编辑器 V0.3.60 的「自定义状态」链只认内置的
/// 35 条触发时机（生成前 ProfileValidator 会拿 PowerTriggers.Supports 校验），
/// 插件触发时机在下拉里能选到，但生成时会被「第 N 个触发时机不认识」拦下。
///
/// 这个补丁只作用在「没有自己覆写 ModifyDamageMultiplicative」的模型上
/// （自定义状态默认就是这种）；本体那些自己覆写了的状态 / 遗物不受影响。
/// </summary>
[HarmonyPatch(typeof(AbstractModel), nameof(AbstractModel.ModifyDamageMultiplicative))]
internal static class DamagePerStackPatch
{
    private static void Postfix(
        AbstractModel __instance,
        ref decimal __result,
        Creature? target,
        decimal amount,
        ValueProp props,
        Creature? dealer,
        CardModel? cardSource,
        CardPlay? cardPlay)
    {
        if (__instance is not PowerModel power) return;
        if (dealer is null || dealer != power.Owner) return;   // 只看自己造成的伤害
        if (!props.IsPoweredAttack()) return;                  // 和本体力量 / 易伤同口径

        decimal pct = PctTable.PctOf(power);
        if (pct == 0m) return;

        __result *= System.Math.Max(0m, 1m + power.Amount * pct / 100m);
    }
}
