#nullable enable
namespace Plugins.DamagePerStack;

/// <summary>
/// 每层增伤的数值表。真正的数据由插件页生成到 PctTable.g.cs 里（partial 方法 Fill）。
/// 生成文件不存在时这里也能编译（partial 方法没有实现会被去掉），只是所有状态都不加成。
/// </summary>
public static partial class PctTable
{
    static partial void Fill(System.Collections.Generic.Dictionary<string, string> map);

    private static System.Collections.Generic.Dictionary<string, string>? _raw;

    /// <summary>状态 → 每层百分比。没登记 / 填错的按 0 处理（不加成）。</summary>
    public static decimal PctOf(MegaCrit.Sts2.Core.Models.AbstractModel model)
    {
        _raw ??= Build();
        if (_raw.TryGetValue(model.GetType().Name, out string? raw) &&
            decimal.TryParse(raw, System.Globalization.NumberStyles.Number,
                System.Globalization.CultureInfo.InvariantCulture, out decimal pct))
        {
            return pct;
        }

        return 0m;
    }

    private static System.Collections.Generic.Dictionary<string, string> Build()
    {
        var map = new System.Collections.Generic.Dictionary<string, string>();
        Fill(map);
        return map;
    }
}
