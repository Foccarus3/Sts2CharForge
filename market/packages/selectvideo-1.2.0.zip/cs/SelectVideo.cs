// ============================================================================
//  cs/SelectVideo.cs —— 「选人界面视频背景」插件（id: selectvideo）运行时。
//
//  作用：自定义角色在【选人界面】被选中时，把 AnimatedBg 背景层换成一段带声音的视频
//        （Ogg Theora + Vorbis —— Godot 4.5.1 唯一内置支持的视频容器）；
//        点「出发」/ 关界面立刻停止并释放（画面与声音一起停）。
//
//  打点（唯一正确组合，均由 ModEntry 的 harmony.PatchAll 自动注册）：
//    SelectCharacter  Postfix → 换背景（原生逻辑刚清空容器并塞进原版 <entry>_bg）
//    BeginRun         Prefix  → 开跑即停（后面紧接 FadeOut）
//    OnSubmenuClosed  Postfix → 回主菜单兜底停
//
//  ★ 配置来源（两种都支持，按顺序取）：
//    1. res://plugin_assets/selectvideo/selectvideo.json（面板「② 保存配置」会写）
//       结构：{ "enabled": true, "loop": true, "volumeDb": 0,
//               "videos": { "KARS": "kars_bg.ogv", "*": "all_bg.ogv" } }
//    2. 没有 JSON 时按文件名约定自动发现：
//       plugin_assets/selectvideo/<角色小写 id>.ogv   → 该角色的视频
//       plugin_assets/selectvideo/all.ogv / default.ogv / *.ogv（只有一个时）→ 通配
//       这样市场用户把 .ogv 丢进去、重新构建就能用，不需要编辑器面板。
//
//  三条铁律：
//    1. 本文件里【不许】声明 partial class : Node/Control —— Godot 源生成器会给它加
//       [ScriptPath]，与 ModEntry 的登记撞车（An item with the same key has already
//       been added → 整个 mod 初始化失败）。只 new VideoStreamPlayer()。
//    2. 所有逻辑包 try/catch，出错只 GD.PushWarning，绝不把异常扔进选人流程。
//    3. 藏原版背景时按节点名排除自己，不拿可能已释放的引用做 != 比较。
// ============================================================================
using System;
using System.Collections.Generic;
using Godot;
using HarmonyLib;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Nodes.Screens.CharacterSelect;

namespace Plugins.SelectVideo
{
    /// <summary>一个角色对应的一段视频配置。</summary>
    internal readonly struct SelectVideoEntry
    {
        public readonly string File;       // plugin_assets/selectvideo/ 下的文件名
        public readonly bool   Loop;
        public readonly float  VolumeDb;

        public SelectVideoEntry(string file, bool loop, float volumeDb)
        {
            File     = file;
            Loop     = loop;
            VolumeDb = volumeDb;
        }
    }

    internal static class SelectVideoRuntime
    {
        private const string Root      = "res://plugin_assets/selectvideo/";
        private const string CfgFile   = "selectvideo.json";
        private const string Tag       = "[selectvideo] ";
        private const string NodeName  = "__selectvideo_bg";
        private const string HostPath  = "AnimatedBg";      // NCharacterSelectScreen 的背景容器
        private const string WildKey   = "*";

        // ---- CFG-BEGIN（面板「保存配置」会把这一段整段重写；市场用户不编辑它也行）----
        // 键 = 角色 Id.Entry（类名 Slugify 后大写，例如 Kars → KARS）；"*" = 所有没单独配过的角色。
        // 注意：这份内嵌配置只是「兜底默认值」。只要 plugin_assets/selectvideo/selectvideo.json 存在，
        // 就以 JSON 为准（面板保存时会同时写 JSON）。
        internal static readonly Dictionary<string, SelectVideoEntry> Videos =
            new Dictionary<string, SelectVideoEntry>(StringComparer.OrdinalIgnoreCase)
            {
            };
        internal static readonly bool  Enabled     = true;
        internal static readonly float VideoAspect = 1.7777778f;   // 16:9（转码统一 1280x720 / 1920x1080）
        // ---- CFG-END

        // ---------------------------------------------------------------- 运行时状态

        private static bool    _cfgLoaded;
        private static bool    _cfgEnabled;
        private static bool    _cfgLoop    = true;
        private static float   _cfgVolume;
        private static readonly Dictionary<string, SelectVideoEntry> _map =
            new Dictionary<string, SelectVideoEntry>(StringComparer.OrdinalIgnoreCase);

        /// <summary>目录里只有一个视频时，所有角色都用它（市场用户的「丢一个就完事」路径）。</summary>
        private static SelectVideoEntry _single;
        private static bool _hasSingle;

        private static VideoStreamPlayer _player;
        private static Control           _host;
        private static string            _playingKey;
        private static bool              _hostHooked;

        internal static void Log(string m)  => GD.Print(Tag + m);
        internal static void Warn(string m) => GD.PushWarning(Tag + m);

        private static bool Alive(GodotObject o) => o != null && GodotObject.IsInstanceValid(o);

        /// <summary>播放器还活着、还挂在这个容器上、还在场景树里（原版 SelectCharacter 每点一次都会清空容器）。</summary>
        private static bool Attached()
            => Alive(_player) && _player.IsInsideTree() && Alive(_host) && _player.GetParent() == _host;

        // ---------------------------------------------------------------- 配置装载

        /// <summary>第一次用到时装载一次：JSON 优先，其次文件名约定，最后内嵌 CFG。</summary>
        private static void EnsureConfig()
        {
            if (_cfgLoaded) return;
            _cfgLoaded   = true;
            _cfgEnabled  = Enabled;
            _cfgVolume   = 0f;
            _cfgLoop     = true;

            // ---- 1) 内嵌 CFG 打底 ----
            try
            {
                if (Videos != null)
                {
                    foreach (var kv in Videos)
                    {
                        if (kv.Key != null && !string.IsNullOrWhiteSpace(kv.Value.File))
                            _map[kv.Key] = kv.Value;
                    }
                }
            }
            catch (Exception e) { Warn("读内嵌 CFG 失败：" + e.Message); }

            // ---- 2) JSON 覆盖 ----
            bool jsonOk = TryLoadJson();

            // ---- 3) JSON 不存在时按文件名约定自动发现 ----
            if (!jsonOk) AutoDiscover();

            Log("配置：启用=" + _cfgEnabled + " 映射 " + _map.Count + " 条" + (jsonOk ? "（来自 selectvideo.json）" : "（来自文件名自动发现）"));
        }

        private static bool TryLoadJson()
        {
            try
            {
                string path = Root + CfgFile;
                if (!FileAccess.FileExists(path)) return false;

                string text = FileAccess.GetFileAsString(path);
                if (string.IsNullOrWhiteSpace(text)) return false;

                Godot.Json json = new Godot.Json();
                Error err = json.Parse(text);
                if (err != Error.Ok) { Warn("selectvideo.json 解析失败（第 " + json.GetErrorLine() + " 行：" + json.GetErrorMessage() + "）"); return false; }

                Variant data = json.GetData();
                if (data.VariantType != Variant.Type.Dictionary) { Warn("selectvideo.json 根节点不是对象"); return false; }
                Godot.Collections.Dictionary root = data.AsGodotDictionary();

                if (root.ContainsKey("enabled"))   _cfgEnabled = Truthy(root["enabled"]);
                if (root.ContainsKey("loop"))      _cfgLoop    = Truthy(root["loop"]);
                if (root.ContainsKey("volumeDb"))  _cfgVolume  = (float)root["volumeDb"].AsDouble();

                Godot.Collections.Dictionary vids = null;
                if (root.ContainsKey("videos") && root["videos"].VariantType == Variant.Type.Dictionary)
                    vids = root["videos"].AsGodotDictionary();

                if (vids != null)
                {
                    foreach (var k in vids.Keys)
                    {
                        string key  = k.AsString();
                        string file = vids[k].AsString();
                        if (string.IsNullOrWhiteSpace(key) || string.IsNullOrWhiteSpace(file)) continue;
                        _map[key] = new SelectVideoEntry(file.Trim(), _cfgLoop, _cfgVolume);
                    }
                }

                return _map.Count > 0 || vids != null;
            }
            catch (Exception e)
            {
                Warn("读 selectvideo.json 失败（改用自动发现）：" + e.Message);
                return false;
            }
        }

        private static bool Truthy(Variant v)
        {
            switch (v.VariantType)
            {
                case Variant.Type.Bool:   return v.AsBool();
                case Variant.Type.Int:    return v.AsInt64() != 0;
                case Variant.Type.Float:  return Math.Abs(v.AsDouble()) > 0.0001;
                case Variant.Type.String: return !string.IsNullOrWhiteSpace(v.AsString())
                                              && v.AsString().Trim().ToLowerInvariant() is not ("0" or "false" or "off" or "no");
                default: return false;
            }
        }

        /// <summary>
        /// 没有 JSON 时按文件名约定自动发现（市场用户走这条路）：
        ///   &lt;角色小写 id&gt;.ogv          → 该角色专用
        ///   all.ogv / default.ogv      → 通配
        ///   目录里只有一个 .ogv         → 当通配
        /// </summary>
        private static void AutoDiscover()
        {
            var files = new List<string>();
            try
            {
                DirAccess d = DirAccess.Open(Root);
                if (d == null) return;
                d.ListDirBegin();
                for (string n = d.GetNext(); !string.IsNullOrEmpty(n); n = d.GetNext())
                {
                    if (d.CurrentIsDir()) continue;
                    if (!n.EndsWith(".ogv", StringComparison.OrdinalIgnoreCase)) continue;
                    files.Add(n);
                }
                d.ListDirEnd();
            }
            catch (Exception e) { Warn("扫描 " + Root + " 失败：" + e.Message); return; }

            if (files.Count == 0) return;

            // 目录里只有一个视频 → 直接给所有角色用（市场用户最常见的用法：丢一个 ovg 进去就完事）
            if (files.Count == 1)
            {
                _single = new SelectVideoEntry(files[0], _cfgLoop, _cfgVolume);
                _hasSingle = true;
                Log("只发现一个视频 " + files[0] + "，将对所有角色生效");
                return;
            }

            foreach (string f in files)
            {
                string stem = f.Substring(0, f.Length - 4);           // 去掉 .ogv
                string low  = stem.ToLowerInvariant();

                if (low is "all" or "default" or "everyone" or "wildcard")
                {
                    _map[WildKey] = new SelectVideoEntry(f, _cfgLoop, _cfgVolume);
                    continue;
                }

                // 去掉常见的 _bg / -bg 尾巴，再当成角色 id（大写）登记
                string id = low;
                if (id.EndsWith("_bg"))      id = id.Substring(0, id.Length - 3);
                else if (id.EndsWith("-bg")) id = id.Substring(0, id.Length - 3);
                else if (id.EndsWith("bg"))  id = id.Substring(0, id.Length - 2);

                if (id.Length == 0) continue;
                _map[id.ToUpperInvariant()] = new SelectVideoEntry(f, _cfgLoop, _cfgVolume);
            }
        }

        // ------------------------------------------------------------------ 播放

        /// <summary>由 SelectCharacter 的 Postfix 调用。screen 就是被打补丁的那个界面实例。</summary>
        internal static void Attach(NCharacterSelectScreen screen, CharacterModel character)
        {
            try
            {
                EnsureConfig();
                if (!_cfgEnabled || screen == null || character == null) return;

                string entry = character.Id.Entry;
                if (string.IsNullOrEmpty(entry)) return;

                // 同一个角色、播放器还挂着 → 不重播（原版点同一个按钮不会重建背景）
                if (string.Equals(entry, _playingKey, StringComparison.OrdinalIgnoreCase) && Attached()) return;

                SelectVideoEntry cfg;
                if (!TryResolve(entry, out cfg)) return;      // 没配：什么都不做，原版背景照旧

                string path = Root + cfg.File;
                VideoStream stream = ResourceLoader.Load<VideoStream>(path);
                if (stream == null)
                {
                    try { stream = new VideoStreamTheora { File = path }; }   // 兜底（.ogv 是原始资源，不走导入）
                    catch (Exception e) { Warn("构造 VideoStreamTheora 失败：" + e.Message); }
                }
                if (stream == null) { Warn("缺 " + path + "（视频没进 pck？）"); return; }

                _host = screen.GetNodeOrNull<Control>(HostPath);
                if (_host == null) { Warn("找不到 " + HostPath + "，跳过"); return; }

                HideVanilla();                        // 先藏原版（此时 _player 可能还是旧/失效的）
                VideoStreamPlayer p = EnsurePlayer();
                if (p == null) return;

                p.Stream     = stream;
                p.Loop       = cfg.Loop;
                p.Expand     = true;                 // 填满我们算好的 16:9 矩形（不会变形）
                p.Bus        = "Master";             // 工程只有 Master(bus 0) / SFX(bus 1) 两条总线
                p.VolumeDb   = cfg.VolumeDb;
                p.AudioTrack = 0;                    // .ogv 里那条 Vorbis 音轨（转码时已硬校验存在）
                p.Play();

                FitCover();
                CallDeferredFit();                   // 布局刚建好时 Size 可能还是 0，下一帧再算一次

                _playingKey = entry;
                Log($"播放 {path} 角色={entry} 时长={p.GetStreamLength():0.00}s 循环={cfg.Loop} 音量={cfg.VolumeDb}dB");
            }
            catch (Exception e) { Warn("Attach 出错（已忽略）：" + e.Message); }
        }

        /// <summary>先按 Id.Entry 找，再按 "*" 兜底，最后用「目录里唯一那个视频」兜底。</summary>
        private static bool TryResolve(string entry, out SelectVideoEntry cfg)
        {
            cfg = default;
            if (_map.TryGetValue(entry, out cfg) && !string.IsNullOrWhiteSpace(cfg.File)) return true;
            if (_map.TryGetValue(WildKey, out cfg) && !string.IsNullOrWhiteSpace(cfg.File)) return true;
            if (_hasSingle && !string.IsNullOrWhiteSpace(_single.File)) { cfg = _single; return true; }
            cfg = default;
            return false;
        }

        private static VideoStreamPlayer EnsurePlayer()
        {
            if (Attached()) return _player;

            // 原版刚把容器子节点全 RemoveChild + QueueFree 了，我们那个也在里面
            if (Alive(_player))
            {
                try { _player.Stop(); _player.Stream = null; _player.QueueFree(); } catch { }
            }
            _player = null;

            var p = new VideoStreamPlayer
            {
                Name        = NodeName,
                MouseFilter = Control.MouseFilterEnum.Ignore,   // 别吃掉角色按钮的点击
                Expand      = true,
            };
            _host.AddChild(p);
            // 先用满铺锚点：就算这一帧拿不到容器尺寸，画面也是盖满的（最多按容器比例轻微拉伸）
            p.SetAnchorsPreset(Control.LayoutPreset.FullRect);
            p.OffsetLeft = p.OffsetTop = p.OffsetRight = p.OffsetBottom = 0f;
            try { _host.MoveChild(p, 0); } catch { }            // 压到背景层最底下

            if (!_hostHooked)
            {
                try { _host.Resized += OnHostResized; _hostHooked = true; } catch { }
            }

            _player = p;
            Log("已挂到 " + HostPath);
            return p;
        }

        private static void OnHostResized()
        {
            try { if (Attached()) FitCover(); } catch { }
        }

        private static void CallDeferredFit()
        {
            try { Callable.From(FitCover).CallDeferred(); } catch { }
        }

        /// <summary>
        /// 按容器尺寸做 cover 铺满：视频固定 16:9，而 AnimatedBg 比视口更大更宽
        /// （1920x1080 上实测约 2560x1200，比例 2.13:1）。直接把 16:9 画面拉伸填满会横向拉宽约 20%，
        /// 所以自己算一个 16:9 矩形居中铺满 —— 多出来的部分被裁掉（这才是背景图该有的样子）。
        /// </summary>
        private static void FitCover()
        {
            if (!Attached()) return;
            Vector2 hs = _host.Size;
            if (hs.X <= 1f || hs.Y <= 1f) return;                // 布局还没算好：保持满铺锚点，等下一帧

            float aspect = VideoAspect > 0.1f ? VideoAspect : 1.7777778f;

            float w = hs.X;
            float h = w / aspect;
            if (h < hs.Y) { h = hs.Y; w = h * aspect; }

            _player.SetAnchorsPreset(Control.LayoutPreset.TopLeft);
            _player.OffsetLeft = _player.OffsetTop = 0f;
            _player.Position = new Vector2((hs.X - w) * 0.5f, (hs.Y - h) * 0.5f);
            _player.Size     = new Vector2(w, h);
        }

        /// <summary>把 AnimatedBg 里除自己以外的子节点都藏起来（原版 &lt;entry&gt;_bg 就是这么被盖掉的）。</summary>
        private static void HideVanilla()
        {
            if (!Alive(_host)) return;
            int n = 0;
            foreach (Node child in _host.GetChildren())
            {
                if (child is CanvasItem ci && ci.Name != NodeName && ci.Visible)
                {
                    ci.Visible = false;
                    n++;
                }
            }
            if (n > 0) Log($"隐藏原版背景节点 {n} 个");
        }

        private static void ShowVanilla()
        {
            if (!Alive(_host)) return;
            foreach (Node child in _host.GetChildren())
            {
                if (child is CanvasItem ci && ci.Name != NodeName && !ci.Visible) ci.Visible = true;
            }
        }

        // ------------------------------------------------------------------ 停止

        internal static void Stop(string why)
        {
            try
            {
                if (_hostHooked && Alive(_host))
                {
                    try { _host.Resized -= OnHostResized; } catch { }
                }
                _hostHooked = false;

                if (Alive(_player))
                {
                    try { _player.Stop(); } catch { }            // 画面 + 声音一起停
                    _player.Stream = null;                       // 释放 Theora / Vorbis 解码器
                    try { _player.QueueFree(); } catch { }
                    Log("已停止并释放（" + why + "）");
                }
                _player = null;
                _playingKey = null;
                ShowVanilla();
            }
            catch (Exception e) { Warn("Stop 出错（已忽略）：" + e.Message); }
        }
    }

    // ------------------------------------------------ Harmony（ModEntry 已 PatchAll，无需注册）

    [HarmonyPatch(typeof(NCharacterSelectScreen), nameof(NCharacterSelectScreen.SelectCharacter))]
    internal static class SelectVideoPatchSelectCharacter
    {
        [HarmonyPostfix]
        private static void Postfix(NCharacterSelectScreen __instance, NCharacterSelectButton charSelectButton)
        {
            try
            {
                if (__instance == null || charSelectButton == null || charSelectButton.IsLocked) return;
                SelectVideoRuntime.Attach(__instance, charSelectButton.Character);
            }
            catch (Exception e) { SelectVideoRuntime.Warn("SelectCharacter 补丁出错：" + e.Message); }
        }
    }

    [HarmonyPatch(typeof(NCharacterSelectScreen), nameof(NCharacterSelectScreen.BeginRun))]
    internal static class SelectVideoPatchBeginRun
    {
        [HarmonyPrefix]
        private static void Prefix() => SelectVideoRuntime.Stop("BeginRun");
    }

    [HarmonyPatch(typeof(NCharacterSelectScreen), nameof(NCharacterSelectScreen.OnSubmenuClosed))]
    internal static class SelectVideoPatchSubmenuClosed
    {
        [HarmonyPostfix]
        private static void Postfix() => SelectVideoRuntime.Stop("OnSubmenuClosed");
    }
}
