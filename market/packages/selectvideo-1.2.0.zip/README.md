# 选人界面视频背景（selectvideo）

把**自定义角色**在**选人界面**的背景大图换成一段**带声音的视频**；点「出发」或返回主菜单立刻停止（画面 + 声音 + 解码器一起释放）。

---

## 1. 三步用起来

1. 打开 Sts2CharForge → 顶部出现「**选人视频**」页签（没有就先去「插件」页点「重新加载插件」）；
2. 「选择视频…」挑一个本地文件（`mp4 / mkv / webm / mov / gif / ogv / avi / flv` 都行）
   → 选「目标角色」→ 点「**① 转码并导入**」；
3. 点「**② 保存配置（写生成代码）**」→ 到「构建 / 日志」页：**生成工程** → **一键构建 + 安装**。

进游戏 → 单人 → 选人界面点那个角色：**背景变视频且有声音**；点「出发」立刻停。

> 「构建 / 日志」页点「生成工程」会清空旧工程，但 **`plugin_assets/` 是唯一保留目录**，所以视频不会丢。
> 稳妥顺序：**生成工程 → 再回来点一次「② 保存配置」→ 一键构建 + 安装**。

---

## 1.5 智能判定：已经是 .ogv 就直接导入（不转码）
选完文件，面板会**立刻用 ffprobe 探测**，然后按结果走三条路之一 —— 不用你自己判断：

| 探测结果 | 面板行为 | 耗时 |
|---|---|---|
| 已是 **Theora + Vorbis**（标准 .ogv） | **原样直接导入，完全不转码** | 毫秒级 |
| 已是 **Theora** 但音轨不是 Vorbis（如 theora+aac） | **只补一条 Vorbis 音轨**，画面 `-c:v copy` 不重编 | 约 0.1–0.3 秒 |
| 视频不是 Theora（h264 / vp9 / gif…） | 正常转码（带进度 + 预计剩余 + 可取消） | 见下表 |

选完文件时状态栏会直接告诉你走哪条路，例如：

```
状态：已选：xxx.ogv —— 已是 Ogg Theora + Vorbis，点「① 转码并导入」会直接导入，不转码（秒完成）
状态：已选：xxx.mkv —— 已是 Theora 视频，但没有 Vorbis 音轨，点「①」会只补一条音轨（很快）
状态：已选：xxx.mp4（需要转码：视频编码是 h264，不是 theora）
```

**探测不只看扩展名**：`ogg` / `mkv` / `mov` 里装 theora+vorbis 也能被认出来；反过来把 h264 改名成 `.ogv` 会被拦下要求转码。

### 转码有多慢（实测基准，别硬等）

`libtheora` 是单线程编码器，**比实时还慢**。本机实测（16 核 / 3.5 GHz 级 CPU）：

| 源 | 分辨率 | 时长 | 转码耗时 | 倍速 |
|---|---|---|---|---|
| 1920×1080 30fps h264 | →1280×720 | 30 秒 | **48 秒** | 0.62x |
| 1918×1080 30fps h264, 372 MB | →1920×1080 | 240 秒 | **714 秒（11 分 54 秒）** | **0.34x** |

所以：

* 转码时状态栏会显示**真实进度**（读 ffmpeg 的 `out_time_us` 和 `speed`），形如
  `转码中… 已用 1 分 16 秒  10%（25 秒 / 4 分 0 秒，0.33x），预计还要 10 分 45 秒`；
* **等不及就点「取消转码」**：会立刻杀掉 ffmpeg 子进程并清掉半成品；
* 想要快：**把源剪到 30 秒内**（这是选人界面背景，循环播放几秒就够），或把「转码分辨率」降到 **1280x720**（实测 0.8x）。

### 体积提醒

`.ogv` 是**原样进 pck、不压缩**的。240 秒 1080p 的成品有 **222 MB**，pck 会跟着涨 222 MB，装 mod 会很难受。
成品超过 60 MB 时状态栏会给出警告。建议：**≤30 秒 + 1280×720**（30 秒约 2.4 MB、15 秒约 1.5 MB）。

---

## 2. 为什么只能是 `.ogv`

| 项 | 结论 |
|---|---|
| Godot 4.5.1 内置唯一视频容器 | **Ogg Theora（视频）+ Vorbis（音频）**，扩展名必须是 `.ogv` |
| 播放器 | `Godot.VideoStreamPlayer`（是 Control），自带 `AudioTrack` / `Bus` / `VolumeDb` |
| `.ogv` 会不会被「导入」改名 | 不会。`.ogv` 是**原始资源**，`--export-pack` 原样打进 pck（本机实测：pck 里能直接搜到 `plugin_assets/selectvideo/xxx.ogv`） |
| 其它格式 | mp4 / h264-in-ogv / webm 一律播不了（编码器能出文件，Godot 解不了） |

转码命令（面板里就是这么调的，逐参数别改）：

```
ffmpeg -y -i <源> -vf "scale=W:H:force_original_aspect_ratio=decrease,pad=W:H:(ow-iw)/2:(oh-ih)/2,format=yuv420p" \
       -c:v libtheora -q:v 7 -c:a libvorbis -q:a 4 -ar 44100 -ac 2 -shortest <输出.ogv>
```

| 参数 | 为什么必须 |
|---|---|
| `-c:v libtheora` | Godot 只认 Theora |
| `format=yuv420p` | Theora 编码器只吃这个像素格式，其它会失败或绿屏 |
| `-c:a libvorbis` | 音轨必须 Vorbis；**绝不能带 `-an`**，否则「有画面没声音」 |
| `-ar 44100 -ac 2` | 44.1k 立体声，避免某些声卡无声 |
| `-shortest` | 音视频等长，防止尾部不同步 |
| `scale + pad` | 统一 16:9；运行时按 16:9 做 cover 铺满，源片比例不对会变形 |

转码后**硬校验**（不过就拒绝导入）：

```
ffprobe -v error -show_entries stream=codec_type,codec_name -of default=nw=1 <输出.ogv>
# 必须同时看到 codec_name=theora / codec_type=video / codec_name=vorbis / codec_type=audio
```

---

## 3. 声音走哪条总线

工程 `default_bus_layout.tres` 只有两条总线：**`Master`（bus 0）** 和 `SFX`（bus 1，send → Master）。
所以运行时固定 `Bus = "Master"`、`AudioTrack = 0`（`.ogv` 里那条 Vorbis）。音量由面板的「音量(dB)」决定，默认 0 dB。

> 游戏设置里的「主音量」滑块作用在 Master 总线上，拖到 0 时视频也没声 —— 这是预期行为。

---

## 4. 打点为什么是这三个

| 需求 | Harmony 打点 | 为什么 |
|---|---|---|
| 换背景 | `NCharacterSelectScreen.SelectCharacter` **Postfix** | 原生逻辑刚把 `AnimatedBg` 子节点清空并塞进原版 `<entry>_bg`，Postfix 里再塞视频、藏原版，顺序才对 |
| 开跑即停 | `BeginRun` **Prefix** | 后面紧接着 `Transition.FadeOut`，Prefix 停最干净 |
| 关界面兜底 | `OnSubmenuClosed` **Postfix** | 回主菜单也停 |

`Stop()` **不能**写进 `SelectCharacter` —— 它每点一次角色都会触发，会变成「选了就停」，看不到视频。

---

## 5. 多个角色 / 通配

* 映射键 = **角色 `Id.Entry`**（就是类名 Slugify 后的大写：`Kars` → `KARS`，`KarsPet` → `KARS_PET`）；
  面板会自动算出来显示在角色下拉里，也可以手填。
* 键 `*` = **所有**没单独配过的角色都用这一段（默认没有 `*` 条目 = 没配的角色完全维持原版）。
* 一个插件可以给多个角色各配一段，互不影响。

---

## 6. 不生效先看控制台 `[selectvideo]`

| 日志 | 含义 / 怎么办 |
|---|---|
| `Probe：… → 可直接导入` | 探测判定为已是目标格式，点「①」不会再转码 |
| `Probe：… → 需补音轨` | 视频是 Theora，点「①」只补一条 Vorbis 音轨 |
| `Probe：… → 需转码：视频编码是 h264` | 正常转码路径 |
| `[selectvideo] 已挂到 AnimatedBg` | 注入成功 |
| `[selectvideo] 播放 res://… 角色=KARS 时长=6.00s 循环=True 音量=0dB` | 正在播（时长 0 说明编码参数不对） |
| `[selectvideo] 缺 res://plugin_assets/selectvideo/x.ogv` | 视频没进 pck：没点「② 保存配置」，或没重新生成工程 / 没重新构建 |
| `[selectvideo] 该角色没配视频` | 这个角色 Id 不在映射里，也没配 `*`（键大小写不敏感，但拼写要对） |
| `[selectvideo] 找不到 AnimatedBg，跳过` | 游戏版本变了（容器节点改名），需要更新插件 |
| `[selectvideo] 已停止并释放（BeginRun）` | 点「出发」停成功 |

---

## 7. 已知边界

* 只改**选人界面**（`NCharacterSelectScreen`）；战斗、篝火、商店、地图都不动。
* 视频建议 **≤30 秒、16:9**，否则 pck 会很大（`.ogv` 原样入包，不压缩）。
* 音轨必须**源素材自带**；素材本身无声时会被 ffprobe 校验拦住 —— 请换一个带声音的视频。
* 随机角色按钮走 `Character` 是随机出来的角色，按 `*` 通配逻辑处理；没配 `*` 时随机按钮不显示视频（符合「没配就维持原样」）。
* 多人模式里选人界面同样生效（只影响本地画面 + 本地音频，不参与同步）。

---

## 8. 文件清单

```
plugins\selectvideo\
├─ plugin.json            清单（id / csFiles / editorExtension）
├─ SelectVideoUi.dll      编辑器扩展（编译产物，必须在插件根目录、和 plugin.json 同级）
├─ src\
│  ├─ SelectVideoUi.csproj
│  └─ SelectVideoUi.cs    面板：选视频 → ffmpeg 转码 → ffprobe 校验 → 导入 → 预览 → 回写配置
├─ cs\
│  └─ SelectVideo.cs      运行时：注入播放器 + 停止释放 + CFG 区段（含默认映射）
├─ assets\
│  └─ <角色>_bg.ogv       转码产物（ImportAsset 写入；构建不清理）
└─ config.json            面板回填用（运行时**不**读它）
```
