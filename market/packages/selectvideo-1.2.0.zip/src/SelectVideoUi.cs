// ============================================================================
//  插件 selectvideo · 编辑器扩展（选人界面视频背景）
//
//  做四件事（全部包在 try/catch 里，出问题只写日志，不影响编辑器原本功能）：
//    1. 往主 TabControl 里挂一个一级页签「选人视频」（照 petboost 的实测做法）；
//    2. 面板里选本地视频（mp4/mkv/webm/mov/gif/ogv/avi/flv）→ 调 ffmpeg 转成
//       Ogg Theora(.ogv) + Vorbis 音轨（Godot 4.5.1 唯一能播的容器），
//       ffprobe 硬校验 theora + vorbis 两条流都在，缺音轨就不导入；
//    3. 导入插件 assets\，并把同一份文件用 host.Generate 复制进当前生成工程的
//       plugin_assets\selectvideo\（生成工程那次构建才会进 pck）；
//    4. 保存时重写 cs\SelectVideo.cs 的 CFG-BEGIN..CFG-END 区段 + 写 config.json。
//
//  依赖：ffmpeg.exe / ffprobe.exe（PATH、环境包自带 tools\ffmpeg\bin、或手动指定）。
// ============================================================================
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using Sts2CharForge.Core.Plugins;
using Sts2CharForge.Core.Profile;

namespace SelectVideoUi
{
    /// <summary>入口类型（plugin.json 的 editorExtension.entry 指向它）。</summary>
    public sealed class SelectVideoExtension : ICharForgeEditorExtension
    {
        public string ApiVersion => "1";

        public IReadOnlyList<IEditorPage> CreatePages(IEditorHost host)
        {
            try { SelectVideoPanel.Install(host); }
            catch (Exception e) { try { host?.Log("[选人视频] 初始化失败：" + e.Message); } catch { } }
            return Array.Empty<IEditorPage>();
        }
    }

    internal static class SelectVideoPanel
    {
        private const string TabTitle  = "选人视频";
        private const string CsRelPath = "cs/SelectVideo.cs";
        private const string RuntimeCfgName = "selectvideo.json";   // 运行时读的那份（随 pck 走）
        private const string CfgBegin  = "// ---- CFG-BEGIN";
        private const string CfgEnd    = "// ---- CFG-END";
        private const string Wildcard  = "*";

        private static IEditorHost _host;
        private static DispatcherTimer _timer;
        private static int _ticks;
        private static bool _injecting, _injected;
        private static bool _loggedBuilt;
        private static FrameworkElement _ui;

        // 控件
        private static TextBlock _status;
        private static TextBox   _videoText;
        private static TextBox   _ffmpegText;
        private static ComboBox  _charCombo;
        private static TextBox   _manualKey;
        private static ComboBox  _resCombo;
        private static CheckBox  _loopCheck;
        private static TextBox   _volBox;
        private static Image     _posterImage;
        private static ListBox   _mapList;

        // 当前存档 → 角色条目
        private static readonly List<CharRow> _chars = new List<CharRow>();
        private static bool _loading;

        // 映射表：键（角色 Id.Entry 或 "*"）→ 文件名
        private static readonly Dictionary<string, string> _rows =
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        private sealed class CharRow
        {
            public string Display;
            public string Key;        // 角色 Id.Entry（Slugify 后大写），"*" 表示通配
            public override string ToString() => Display;
        }

        // ---------------------------------------------------------------- 启动 / 注入

        internal static void Install(IEditorHost host)
        {
            _host = host;
            _injected = _injecting = false;
            _ui = null;
            _ticks = 0;
            _loggedBuilt = false;
            if (_timer != null) { try { _timer.Stop(); _timer.Tick -= OnTick; } catch { } _timer = null; }

            Trace("===== Install =====");
            Application app;
            try { app = Application.Current; }
            catch (Exception ex) { Trace("取 Application.Current 异常：" + ex.Message); return; }
            if (app == null) { Trace("Application.Current 为空（非 WPF 环境），跳过注入。"); return; }
            Trace("拿到 Application，准备注入");

            // 先直接在 UI 线程上试一次（不等定时器），再用定时器兜底
            try
            {
                app.Dispatcher.BeginInvoke(new Action(() =>
                {
                    try { InjectOnce(); }
                    catch (Exception ex) { Trace("首次注入异常：" + ex); }
                }));
            }
            catch (Exception ex) { Trace("BeginInvoke 失败：" + ex.Message); }

            try
            {
                _timer = new DispatcherTimer(DispatcherPriority.Background, app.Dispatcher)
                { Interval = TimeSpan.FromMilliseconds(500) };
                _timer.Tick += OnTick;
                _timer.Start();
                Trace("定时器已启动");
            }
            catch (Exception ex) { Trace("启动定时器失败：" + ex); }
        }

        private static void OnTick(object sender, EventArgs e)
        {
            if (_injected) { Stop(); return; }
            if (++_ticks > 720) { Stop(); Log("一直没找到主 TabControl，放弃注入。"); return; }
            if (_injecting) return;
            _injecting = true;
            try { InjectOnce(); }
            catch (Exception ex) { Trace("注入异常：" + ex.Message); }
            finally { _injecting = false; }
        }

        private static void InjectOnce()
        {
            var win = Application.Current?.MainWindow;
            if (win == null) return;
            var tabs = FindMainTabs(win);
            if (tabs == null) return;

            if (_ui == null) _ui = BuildUi();
            if (_ui == null) return;
            if (!_loggedBuilt) { _loggedBuilt = true; Trace("界面已构建，主 TabControl 找到，准备挂页签"); }

            // 先摘掉上一次加载留下的同名页签（它的内容属于已卸载的 ALC，留着会继续响应旧代码）
            var stale = new List<TabItem>();
            foreach (var o in tabs.Items)
            {
                if (o is TabItem ti && SafeHeader(o) == TabTitle) stale.Add(ti);
            }
            foreach (var ti in stale)
            {
                try { tabs.Items.Remove(ti); Trace("移除旧的「" + TabTitle + "」页签"); } catch (Exception e) { Trace("移除旧页签失败：" + e.Message); }
            }

            var item = new TabItem { Header = TabTitle, Content = _ui };
            tabs.Items.Add(item);
            try { tabs.SelectedItem = item; } catch { }

            _injected = true;
            Stop();
            Trace("已挂上「" + TabTitle + "」页签");
            LoadSavedConfig();
            ReloadChars();
        }

        /// <summary>
        /// 精确找主 TabControl：优先 AutomationId = "MainTabs"（编辑器主界面用的就是这个 id），
        /// 找不到再退回 BFS 第一个。避免误命中「插件」页内部的子 TabControl。
        /// </summary>
        private static TabControl FindMainTabs(DependencyObject root)
        {
            if (root == null) return null;
            var queue = new Queue<DependencyObject>();
            queue.Enqueue(root);
            int guard = 0;
            while (queue.Count > 0 && guard++ < 20000)
            {
                DependencyObject node = queue.Dequeue();
                try
                {
                    if (node is TabControl tc)
                    {
                        string id = System.Windows.Automation.AutomationProperties.GetAutomationId(node);
                        if (id == "MainTabs") return tc;
                    }
                }
                catch { }

                int n;
                try { n = VisualTreeHelper.GetChildrenCount(node); } catch { continue; }
                for (int i = 0; i < n; i++)
                {
                    DependencyObject child = null;
                    try { child = VisualTreeHelper.GetChild(node, i); } catch { }
                    if (child != null) queue.Enqueue(child);
                }
            }
            return FindFirst<TabControl>(root);
        }

        private static void Stop()
        {
            try { if (_timer != null) { _timer.Stop(); _timer.Tick -= OnTick; _timer = null; } } catch { }
        }

        // ---------------------------------------------------------------- 界面

        private static FrameworkElement BuildUi()
        {
            var grid = new Grid();
            for (int i = 0; i < 9; i++) grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            // 0) 标题 + 状态
            var head = new DockPanel { LastChildFill = true, Margin = new Thickness(0, 0, 0, 8) };
            var title = new TextBlock
            {
                Text = "选人界面视频背景（自定义角色）",
                FontWeight = FontWeights.Bold,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 12, 0),
            };
            DockPanel.SetDock(title, Dock.Left);
            head.Children.Add(title);
            _status = new TextBlock
            {
                Text = "状态：等待选择视频",
                Opacity = 0.8,
                TextTrimming = TextTrimming.CharacterEllipsis,
                VerticalAlignment = VerticalAlignment.Center,
            };
            head.Children.Add(_status);
            Grid.SetRow(head, 0);
            grid.Children.Add(head);

            // 1) 视频文件
            var rowVideo = new DockPanel { LastChildFill = true, Margin = new Thickness(0, 0, 0, 6) };
            rowVideo.Children.Add(new TextBlock { Text = "视频文件：", Width = 90, VerticalAlignment = VerticalAlignment.Center });
            var btnPick = new Button { Content = "选择视频…", Padding = new Thickness(10, 2, 10, 2) };
            DockPanel.SetDock(btnPick, Dock.Right);
            btnPick.Click += (s, e) => { try { PickVideo(); } catch (Exception ex) { SetStatus("出错：" + ex.Message); } };
            rowVideo.Children.Add(btnPick);
            _videoText = new TextBox { IsReadOnly = true, VerticalAlignment = VerticalAlignment.Center };
            rowVideo.Children.Add(_videoText);
            Grid.SetRow(rowVideo, 1);
            grid.Children.Add(rowVideo);

            // 2) ffmpeg
            var rowFf = new DockPanel { LastChildFill = true, Margin = new Thickness(0, 0, 0, 6) };
            rowFf.Children.Add(new TextBlock { Text = "ffmpeg.exe：", Width = 90, VerticalAlignment = VerticalAlignment.Center });
            var btnFf = new Button { Content = "浏览…", Padding = new Thickness(10, 2, 10, 2) };
            DockPanel.SetDock(btnFf, Dock.Right);
            btnFf.Click += (s, e) => { try { PickFfmpeg(); } catch (Exception ex) { SetStatus("出错：" + ex.Message); } };
            rowFf.Children.Add(btnFf);
            _ffmpegText = new TextBox
            {
                VerticalAlignment = VerticalAlignment.Center,
                ToolTip = "留空会自动在 PATH、<程序目录>\\tools\\ffmpeg\\bin\\、<程序目录>\\..\\tools\\ffmpeg\\bin\\ 里找；ffprobe 必须和它同目录。",
            };
            rowFf.Children.Add(_ffmpegText);
            Grid.SetRow(rowFf, 2);
            grid.Children.Add(rowFf);

            // 3) 目标角色 + 手动 Id
            var rowChar = new WrapPanel { Margin = new Thickness(0, 0, 0, 6) };
            rowChar.Children.Add(new TextBlock { Text = "目标角色：", Width = 90, VerticalAlignment = VerticalAlignment.Center });
            _charCombo = new ComboBox { MinWidth = 300, VerticalAlignment = VerticalAlignment.Center };
            _charCombo.SelectionChanged += (s, e) => { try { SyncManualKeyFromCombo(); } catch { } };
            rowChar.Children.Add(_charCombo);
            var btnReload = new Button { Content = "刷新角色列表", Padding = new Thickness(9, 1, 9, 1), Margin = new Thickness(8, 0, 0, 0) };
            btnReload.Click += (s, e) => { try { ReloadChars(); } catch (Exception ex) { SetStatus("出错：" + ex.Message); } };
            rowChar.Children.Add(btnReload);
            rowChar.Children.Add(new TextBlock
            {
                Text = "角色 Id（可手填）：", Margin = new Thickness(14, 0, 4, 0),
                VerticalAlignment = VerticalAlignment.Center,
            });
            _manualKey = new TextBox
            {
                Width = 140, VerticalAlignment = VerticalAlignment.Center,
                ToolTip = "运行时用的键 = 角色 Id.Entry（类名 Slugify 后的大写，例如 Kars → KARS）。\n留空则用左边下拉选中的那个；填 * = 所有没单独配过的角色。",
            };
            rowChar.Children.Add(_manualKey);
            Grid.SetRow(rowChar, 3);
            grid.Children.Add(rowChar);

            // 4) 分辨率 + 循环 + 音量
            var rowOpt = new WrapPanel { Margin = new Thickness(0, 0, 0, 6) };
            rowOpt.Children.Add(new TextBlock { Text = "转码分辨率：", Width = 90, VerticalAlignment = VerticalAlignment.Center });
            _resCombo = new ComboBox { Width = 150, VerticalAlignment = VerticalAlignment.Center };
            _resCombo.Items.Add("1280x720（推荐）");
            _resCombo.Items.Add("1920x1080（更清晰/更大）");
            _resCombo.Items.Add("854x480（更小）");
            _resCombo.SelectedIndex = 0;
            rowOpt.Children.Add(_resCombo);
            _loopCheck = new CheckBox
            {
                Content = "循环播放", IsChecked = true, Margin = new Thickness(14, 0, 0, 0),
                VerticalAlignment = VerticalAlignment.Center,
            };
            rowOpt.Children.Add(_loopCheck);
            rowOpt.Children.Add(new TextBlock { Text = "音量(dB)：", Margin = new Thickness(14, 0, 4, 0), VerticalAlignment = VerticalAlignment.Center });
            _volBox = new TextBox { Text = "0", Width = 60, VerticalAlignment = VerticalAlignment.Center };
            rowOpt.Children.Add(_volBox);
            Grid.SetRow(rowOpt, 4);
            grid.Children.Add(rowOpt);

            // 5) 按钮
            var rowBtn = new WrapPanel { Margin = new Thickness(0, 0, 0, 6) };
            rowBtn.Children.Add(Btn("① 转码并导入", OnTranscode, 0));
            rowBtn.Children.Add(Btn("② 保存配置（写生成代码）", OnSave, 8));
            rowBtn.Children.Add(Btn("取消转码", CancelTranscode, 8));
            rowBtn.Children.Add(Btn("删除选中映射", OnRemove, 8));
            rowBtn.Children.Add(Btn("打开插件目录", OnOpenPluginDir, 8));
            Grid.SetRow(rowBtn, 5);
            grid.Children.Add(rowBtn);

            // 6) 映射表
            var rowMap = new DockPanel { LastChildFill = true, Margin = new Thickness(0, 0, 0, 6) };
            rowMap.Children.Add(new TextBlock { Text = "已配置：", Width = 90, VerticalAlignment = VerticalAlignment.Top });
            _mapList = new ListBox { Height = 84, VerticalAlignment = VerticalAlignment.Stretch };
            rowMap.Children.Add(_mapList);
            Grid.SetRow(rowMap, 6);
            grid.Children.Add(rowMap);

            // 7) 首帧预览
            _posterImage = new Image
            {
                Height = 240, Stretch = Stretch.Uniform,
                HorizontalAlignment = HorizontalAlignment.Left,
                Margin = new Thickness(0, 0, 0, 6),
            };
            Grid.SetRow(_posterImage, 7);
            grid.Children.Add(_posterImage);

            // 8) 说明
            var hint = new TextBlock
            {
                TextWrapping = TextWrapping.Wrap, Opacity = 0.65,
                Text = "视频统一转成 Ogg Theora(.ogv) + Vorbis 音轨 —— Godot 4.5.1 唯一内置支持的视频容器。"
                     + "转码后会硬校验 theora + vorbis 两条流，缺音轨会直接拒绝导入（进游戏会没声音）。\n"
                     + "顺序：① 转码并导入 → ② 保存配置 → 到「构建 / 日志」页点「生成工程」→「一键构建 + 安装」。"
                     + "之后进游戏 → 单人 → 选人界面点那个角色：背景变视频且有声；点「出发」立刻停。",
            };
            Grid.SetRow(hint, 8);
            grid.Children.Add(hint);

            return new Border
            {
                Padding = new Thickness(12),
                Child = grid,
                HorizontalAlignment = HorizontalAlignment.Stretch,
            };
        }

        private static Button Btn(string text, Action onClick, double left)
        {
            var b = new Button
            {
                Content = text,
                Padding = new Thickness(10, 2, 10, 2),
                Margin = new Thickness(left, 0, 0, 0),
                VerticalAlignment = VerticalAlignment.Center,
            };
            b.Click += (s, e) => { try { onClick(); } catch (Exception ex) { SetStatus("出错：" + ex.Message); Trace(ex.ToString()); } };
            return b;
        }

        // ---------------------------------------------------------------- 角色列表

        private static void ReloadChars()
        {
            try
            {
                _loading = true;
                _chars.Clear();

                var win = Application.Current?.MainWindow;
                CharacterProfile profile = null;
                try { profile = win?.GetType().GetProperty("Profile")?.GetValue(win) as CharacterProfile; } catch { }

                string key = "*";
                string name = null;
                if (profile != null)
                {
                    name = string.IsNullOrWhiteSpace(profile.DisplayName) ? profile.CharacterClass : profile.DisplayName;
                    key = EntryOf(profile.CharacterClass);
                }

                _chars.Add(new CharRow { Key = Wildcard, Display = "（*）所有没单独配置的角色（通配）" });
                if (profile != null && !string.IsNullOrWhiteSpace(profile.CharacterClass))
                    _chars.Add(new CharRow
                    {
                        Key = key,
                        Display = (name ?? profile.CharacterClass) + "（" + profile.CharacterClass + " → Id " + key + "）",
                    });

                string keep = _manualKey?.Text ?? "";
                _charCombo.Items.Clear();
                foreach (var c in _chars) _charCombo.Items.Add(c);
                _charCombo.SelectedIndex = _chars.Count > 1 ? 1 : 0;
                if (!string.IsNullOrWhiteSpace(keep)) _manualKey.Text = keep;
                else SyncManualKeyFromCombo();

                SetStatus(_chars.Count > 1
                    ? "已读到当前存档角色：" + key + "（改完记得 ① 转码导入 → ② 保存配置）"
                    : "没读到存档角色：先打开一个自定义角色存档，或直接在「角色 Id」里手填");
                Trace("ReloadChars：count=" + (_chars.Count - 1) + " key=" + key);
            }
            catch (Exception e) { SetStatus("读角色列表失败：" + e.Message); }
            finally { _loading = false; }
        }

        private static void SyncManualKeyFromCombo()
        {
            if (_loading) return;
            if (_charCombo?.SelectedItem is CharRow row && _manualKey != null) _manualKey.Text = row.Key;
        }

        private static string CurrentKey()
        {
            string s = (_manualKey?.Text ?? "").Trim();
            if (s.Length > 0) return s;
            if (_charCombo?.SelectedItem is CharRow row) return row.Key;
            return Wildcard;
        }

        /// <summary>与本体 StringHelper.Slugify 等价：Kars → KARS，KarsPet → KARS_PET。</summary>
        private static string EntryOf(string className)
        {
            if (string.IsNullOrWhiteSpace(className)) return Wildcard;
            string s = Regex.Replace(className.Trim(), "([A-Za-z0-9]|\\G(?!^))([A-Z])", "$1_$2");
            s = Regex.Replace(s.ToUpperInvariant(), "\\s+", "_");
            s = Regex.Replace(s, "[^A-Z0-9_]", "");
            return s.Length == 0 ? Wildcard : s;
        }

        // ---------------------------------------------------------------- 映射表

        private static void RefreshMapList()
        {
            try
            {
                if (_mapList == null) return;
                object keep = _mapList.SelectedItem;
                _mapList.Items.Clear();
                foreach (var kv in _rows.OrderBy(k => k.Key == Wildcard ? 0 : 1).ThenBy(k => k.Key, StringComparer.OrdinalIgnoreCase))
                    _mapList.Items.Add(kv.Key + "  →  " + kv.Value);
                if (keep != null && _mapList.Items.Contains(keep)) _mapList.SelectedItem = keep;
            }
            catch { }
        }

        private static string SelectedMapKey()
        {
            if (!(_mapList?.SelectedItem is string s)) return null;
            int i = s.IndexOf("  →  ", StringComparison.Ordinal);
            return i > 0 ? s.Substring(0, i).Trim() : null;
        }

        // ---------------------------------------------------------------- 选文件

        private static void PickVideo()
        {
            var dlg = new Microsoft.Win32.OpenFileDialog
            {
                Title = "选择要作为选人界面背景的视频（已经是 .ogv 会直接导入，不转码）",
                Filter = "视频文件|*.mp4;*.mkv;*.webm;*.mov;*.gif;*.ogv;*.ogg;*.avi;*.flv;*.wmv;*.m4v|Ogg Theora 视频|*.ogv;*.ogg|所有文件|*.*",
            };
            if (dlg.ShowDialog() == true)
            {
                _videoText.Text = dlg.FileName;
                // 选完立刻探测一次，能直接用的就别让用户再等转码
                ProbeAndReport(dlg.FileName);
            }
        }

        /// <summary>
        /// 选定文件后立刻探测：能不能直接当 .ogv 用？
        /// 命中就换一条状态提示，让用户知道「下一步点 ① 会秒完成」。
        /// </summary>
        private static void ProbeAndReport(string src)
        {
            try
            {
                string ffprobe = FindTool("ffprobe.exe");
                var probe = ProbeSource(src, ffprobe);
                string name = Path.GetFileName(src);

                if (probe.IsReady)
                {
                    if (probe.IsPerfect)
                        SetStatus("已选：" + name + " —— 已是 Ogg Theora + Vorbis，点「① 转码并导入」会**直接导入，不转码**（秒完成）");
                    else
                        SetStatus("已选：" + name + " —— 已是 Theora 视频，但没有 Vorbis 音轨，点「①」会只补一条音轨（很快）");
                    Trace("Probe：" + probe.Describe());
                    return;
                }

                string why = probe.QualityCount > 1
                    ? "这个文件里有 " + probe.QualityCount + " 个视频流（多视角/多码率），需要转码"
                    : "需要转码：" + probe.BlockReason;
                SetStatus("已选：" + name + "（" + why + "）");
                Trace("Probe：" + probe.Describe());
            }
            catch (Exception e) { Trace("探测失败：" + e.Message); }
        }

        private static void PickFfmpeg()
        {
            var dlg = new Microsoft.Win32.OpenFileDialog { Title = "选择 ffmpeg.exe", Filter = "ffmpeg|ffmpeg.exe|exe|*.exe" };
            if (dlg.ShowDialog() == true) _ffmpegText.Text = dlg.FileName;
        }

        private static void OnOpenPluginDir()
        {
            try
            {
                string dir = _host?.PluginDir;
                if (string.IsNullOrWhiteSpace(dir) || !Directory.Exists(dir)) { SetStatus("插件目录不存在"); return; }
                Process.Start(new ProcessStartInfo("explorer.exe", "\"" + dir + "\"") { UseShellExecute = true });
                SetStatus("已打开：" + dir);
            }
            catch (Exception e) { SetStatus("打开目录失败：" + e.Message); }
        }

        // ---------------------------------------------------------------- 源文件探测

        /// <summary>探测结果。决定「能不能跳过转码直接导入」。</summary>
        private sealed class SourceProbe
        {
            public bool   ProbeOk;              // ffprobe 是否跑成功
            public bool   HasVideo;
            public bool   HasAudio;
            public int    AudioStreams;
            public string VideoCodec = "";
            public string AudioCodec = "";
            public int    Width, Height;
            public double Fps, DurationSeconds;
            public int    QualityCount;         // 视频流个数（>1 说明是多视角/多码率）
            public string FormatName = "";      // 容器名（matroska / ogg / mp4 …）
            public long   FileBytes;

            /// <summary>视频流已经是 Theora。</summary>
            public bool VideoIsTheora =>
                ProbeOk && HasVideo && VideoCodec.Equals("theora", StringComparison.OrdinalIgnoreCase);

            /// <summary>音轨已经是 Vorbis（或干脆没有音轨）。</summary>
            public bool AudioIsVorbisOrNone =>
                ProbeOk && (!HasAudio || AudioCodec.Equals("vorbis", StringComparison.OrdinalIgnoreCase));

            /// <summary>整个文件已经是 Godot 要的东西 —— 可以原样当 .ogv 用。</summary>
            public bool IsPerfect => VideoIsTheora && AudioIsVorbisOrNone && QualityCount <= 1;

            /// <summary>视频已是 Theora，只差音轨（补一条 Vorbis 很快，不用重编视频）。</summary>
            public bool IsReady => VideoIsTheora && QualityCount <= 1;

            /// <summary>不能直接用的原因（给用户看）。</summary>
            public string BlockReason
            {
                get
                {
                    if (!ProbeOk)        return "探测失败（文件可能是纯数据或损坏）";
                    if (!HasVideo)       return "没有视频流";
                    if (QualityCount > 1) return "有多个视频流";
                    if (!VideoIsTheora)  return "视频编码是 " + (string.IsNullOrEmpty(VideoCodec) ? "未知" : VideoCodec) + "，不是 theora";
                    if (!AudioIsVorbisOrNone) return "音轨是 " + (string.IsNullOrEmpty(AudioCodec) ? "未知" : AudioCodec) + "，不是 vorbis";
                    return "";
                }
            }

            public string Describe()
            {
                if (!ProbeOk) return "probe 失败";
                var v = VideoCodec + " " + Width + "x" + Height + " @" + Fps.ToString("0.##") + "fps";
                var a = HasAudio ? AudioCodec : "(无音轨)";
                return "容器=" + FormatName + " 视频=" + v + "（" + QualityCount + " 个流） 音频=" + a
                     + " 时长=" + DurationSeconds.ToString("0.0") + "s 大小=" + (FileBytes / 1024 / 1024) + "MB"
                     + " → " + (IsPerfect ? "可直接导入" : IsReady ? "需补音轨" : "需转码：" + BlockReason);
            }
        }

        /// <summary>
        /// 用 ffprobe 读流信息。
        /// 关键：不要用 default=nw=1（它按 key 名字排序输出，codec_name 会排在 codec_type 前面，
        /// 用「读到 codec_type 才知道下一个 codec_name 属于谁」的状态机会全部错位）。
        /// 改用 -of csv=p=0 —— 一条流正好一行、字段顺序固定 = 我们请求的顺序。
        /// </summary>
        private static SourceProbe ProbeSource(string path, string ffprobe)
        {
            var r = new SourceProbe();
            if (string.IsNullOrWhiteSpace(ffprobe) || !File.Exists(path)) return r;
            try { r.FileBytes = new FileInfo(path).Length; } catch { }

            // ---- 流信息：codec_name,codec_type,width,height,r_frame_rate 每流一行 ----
            string so, se;
            int code = RunTool(ffprobe,
                "-v error -show_entries stream=codec_name,codec_type,width,height,r_frame_rate -of csv=p=0 \"" + path + "\"",
                out so, out se);

            if (code != 0 && string.IsNullOrWhiteSpace(so))
            {
                Trace("ffprobe 读流失败：" + LastLines(se, 3));
                return r;
            }

            r.ProbeOk = true;
            int videoSeen = 0;

            foreach (string raw in (so ?? "").Replace("\r", "").Split('\n'))
            {
                string line = raw.Trim();
                if (line.Length == 0) continue;

                // 形如：theora,video,1280,720,30/1   或   aac,audio
                string[] f = line.Split(',');
                if (f.Length < 2) continue;

                string cname = f[0].Trim();
                string ctype = f[1].Trim().ToLowerInvariant();

                if (ctype == "video")
                {
                    videoSeen++;
                    if (videoSeen == 1)
                    {
                        r.VideoCodec = cname;
                        if (f.Length > 2 && int.TryParse(f[2], out int w)) r.Width = w;
                        if (f.Length > 3 && int.TryParse(f[3], out int h)) r.Height = h;
                        if (f.Length > 4) r.Fps = ParseFps(f[4]);
                    }
                }
                else if (ctype == "audio")
                {
                    r.AudioStreams++;
                    if (r.AudioStreams == 1) r.AudioCodec = cname;
                }
            }

            // ---- 容器名 + 时长（容器本身没时长时，退一步用流里的 duration）----
            string so2, se2;
            if (RunTool(ffprobe, "-v error -show_entries format=format_name,duration -of csv=p=0 \"" + path + "\"",
                        out so2, out se2) == 0)
            {
                string fmt = (so2 ?? "").Replace("\r", "").Split('\n')[0].Trim();
                if (fmt.Length > 0)
                {
                    string[] g = fmt.Split(',');
                    if (g.Length > 0) r.FormatName = g[0].Trim().Trim('"');
                    if (g.Length > 1)
                        double.TryParse(g[1].Trim(), System.Globalization.NumberStyles.Float,
                                        System.Globalization.CultureInfo.InvariantCulture, out r.DurationSeconds);
                }
            }

            // 容器时长缺失（有些 mkv 的 format.duration 是 N/A）→ 用第一条视频流的 duration
            if (r.DurationSeconds <= 0)
            {
                string so3, se3;
                if (RunTool(ffprobe, "-v error -select_streams v:0 -show_entries stream=duration -of csv=p=0 \"" + path + "\"",
                            out so3, out se3) == 0)
                {
                    string sv = (so3 ?? "").Replace("\r", "").Split('\n')[0].Trim();
                    double.TryParse(sv, System.Globalization.NumberStyles.Float,
                                    System.Globalization.CultureInfo.InvariantCulture, out r.DurationSeconds);
                }
            }

            r.HasVideo     = videoSeen > 0;
            r.QualityCount = videoSeen;
            r.HasAudio     = r.AudioStreams > 0;
            return r;
        }

        private static double ParseFps(string v)
        {
            if (string.IsNullOrWhiteSpace(v)) return 0;
            int slash = v.IndexOf('/');
            if (slash > 0
                && double.TryParse(v.Substring(0, slash), System.Globalization.NumberStyles.Float,
                                   System.Globalization.CultureInfo.InvariantCulture, out double num)
                && double.TryParse(v.Substring(slash + 1), System.Globalization.NumberStyles.Float,
                                   System.Globalization.CultureInfo.InvariantCulture, out double den)
                && den > 0)
                return num / den;
            double.TryParse(v, System.Globalization.NumberStyles.Float,
                            System.Globalization.CultureInfo.InvariantCulture, out double fps);
            return fps;
        }

        /// <summary>
        /// 画质是否还算「目标规格」。用于提醒：能直接用但明显偏大时，转码反而更合适。
        /// 返回 null = 没问题；否则返回原因。
        /// </summary>
        private static string QualityAdvisory(SourceProbe p)
        {
            if (!p.IsPerfect) return null;
            var (tw, th) = Resolution();
            if (p.Width > tw * 1.5 || p.Height > th * 1.5)
                return "分辨率 " + p.Width + "x" + p.Height + " 比目标 " + tw + "x" + th + " 大不少，直接导入会让 pck 偏大（想压小就换「强制转码」）";
            if (p.Fps > 61)
                return "帧率 " + p.Fps.ToString("0.#") + "fps 偏高，直接导入会让 pck 偏大";
            return null;
        }

        /// <summary>把已经是目标格式的文件直接搬进插件 assets\（必要时改名为 .ogv）。</summary>
        private static void ImportDirect(SourceProbe probe, string src, string key, string outName,
                                          string outDir, string outPath)
        {
            string notes = "";

            // ① 视频是 theora 但没有 vorbis 音轨 → 只补一条静音音轨（不重编视频，很快）
            if (!probe.AudioIsVorbisOrNone)
            {
                string ffmpeg = FindTool("ffmpeg.exe");
                string tmpDir = Path.Combine(Path.GetTempPath(), "selectvideo_tmp");
                Directory.CreateDirectory(tmpDir);
                string tmp = Path.Combine(tmpDir, outName);
                try { if (File.Exists(tmp)) File.Delete(tmp); } catch { }

                SetStatus("视频已是 Theora，正在补一条 Vorbis 音轨（不重编画面，很快）…");
                // 注意顺序：-f lavfi 必须紧贴它自己的 -i；每个 -map 也要在对应输入之后。
                // 视频用 -c:v copy 原样搬，音频从 anullsrc 生成静音 Vorbis。
                string args =
                    "-y -hide_banner -loglevel error " +
                    "-i \"" + src + "\" " +
                    "-f lavfi -i anullsrc=channel_layout=stereo:sample_rate=44100 " +
                    "-map 0:v:0 -map 1:a:0 " +
                    "-c:v copy -c:a libvorbis -q:a 4 -ar 44100 -ac 2 " +
                    "-shortest \"" + tmp + "\"";
                string so, se;
                int code = RunTool(ffmpeg, args, out so, out se);
                if (code != 0 || !File.Exists(tmp))
                {
                    Trace("补音轨失败 code=" + code + "\n" + se);
                    SetStatus("补音轨失败：" + LastLines(se, 3) + "。可以换一个带声音的视频，或用「强制转码」。");
                    return;
                }
                try { File.Delete(outPath); } catch { }
                File.Move(tmp, outPath);
                notes = "视频原样复制 + 补了一条 Vorbis 音轨";
            }
            else
            {
                // ② 完整可用（或本来就没音轨）→ 原样复制
                SetStatus("检测到已是 Ogg Theora，直接导入（不转码）…");
                try
                {
                    // 用户选的可能就是插件里那份（上次导入过的）——同路径时不要自己复制自己
                    bool same = string.Equals(Path.GetFullPath(src), Path.GetFullPath(outPath),
                                              StringComparison.OrdinalIgnoreCase);
                    if (!same)
                    {
                        if (File.Exists(outPath)) File.Delete(outPath);
                        File.Copy(src, outPath, true);
                    }
                    else
                    {
                        Trace("源文件已在插件 assets 内，跳过复制：" + outPath);
                    }
                }
                catch (Exception e)
                {
                    SetStatus("直接导入失败：" + e.Message);
                    Trace(e.ToString());
                    return;
                }
                notes = probe.HasAudio ? "已是 Ogg Theora + Vorbis，原样导入" : "已是 Ogg Theora（源无音轨），原样导入";
            }

            // host.ImportAsset(源, 名) 内部就是「把源复制到 <PluginDir>\assets\<名>」，
            // 源和目标同一个文件会失败。所以本地已就位时，从一个临时副本再导入一次。
            string importSrc = outPath;
            string tmpCopy = null;
            try
            {
                if (File.Exists(outPath))
                {
                    tmpCopy = Path.Combine(Path.GetTempPath(), "selectvideo_tmp", Guid.NewGuid().ToString("N") + ".ogv");
                    Directory.CreateDirectory(Path.GetDirectoryName(tmpCopy));
                    File.Copy(outPath, tmpCopy, true);
                    importSrc = tmpCopy;
                }
            }
            catch (Exception e) { Trace("做临时副本失败（改用直接落盘）：" + e.Message); }

            string rel = _host.ImportAsset(importSrc, outName);
            if (!string.IsNullOrEmpty(tmpCopy)) { try { File.Delete(tmpCopy); } catch { } }

            if (string.IsNullOrEmpty(rel))
            {
                Trace("ImportAsset 返回空：src=" + importSrc + " name=" + outName);
                SetStatus("导入失败：ImportAsset 返回空（文件名非法 / 插件目录不可写）。看 selectvideo.log。");
                return;
            }

            _rows[key] = outName;
            RefreshMapList();

            double sec = probe.DurationSeconds;
            SetStatus("【跳过转码】" + notes + " → " + key + " 用 " + outName
                    + "（" + (new FileInfo(outPath).Length / 1024) + " KB，"
                    + (sec > 0 ? sec.ToString("0.0") + " 秒视频" : "时长未知") + "）。接着点「② 保存配置」。");

            MakePoster(outPath, outDir, outName);
            Trace("直接导入：" + outName + " → key=" + key + "  " + notes);
        }

        /// <summary>抽首帧做预览（失败无所谓）。</summary>
        private static void MakePoster(string outPath, string outDir, string outName)
        {
            try
            {
                string posterPath = Path.Combine(outDir, Path.GetFileNameWithoutExtension(outName) + "_poster.png");
                string a1, a2;
                RunTool(FindTool("ffmpeg.exe"),
                    "-y -hide_banner -loglevel error -i \"" + outPath + "\" -frames:v 1 -vf \"scale=640:-2\" \"" + posterPath + "\"",
                    out a1, out a2);
                if (File.Exists(posterPath) && _posterImage != null) _posterImage.Source = LoadBitmap(posterPath);
            }
            catch { }
        }

        // ---------------------------------------------------------------- 找 ffmpeg / 跑进程

        private static string FindTool(string exeName)
        {
            string manual = (_ffmpegText?.Text ?? "").Trim();
            if (exeName == "ffmpeg.exe" && manual.Length > 0)
            {
                if (File.Exists(manual)) return manual;
                string sib = Path.Combine(Path.GetDirectoryName(manual) ?? "", exeName);
                if (File.Exists(sib)) return sib;
            }
            if (manual.Length > 0)
            {
                string sib = Path.Combine(Path.GetDirectoryName(manual) ?? "", exeName);
                if (File.Exists(sib)) return sib;
            }

            string pathVar = Environment.GetEnvironmentVariable("PATH") ?? "";
            foreach (var dir in pathVar.Split(Path.PathSeparator))
            {
                try
                {
                    string f = Path.Combine(dir.Trim().Trim('"'), exeName);
                    if (File.Exists(f)) return f;
                }
                catch { }
            }

            string appDir = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly()?.Location ?? "");
            var candidates = new List<string>();
            if (!string.IsNullOrEmpty(appDir))
            {
                candidates.Add(Path.GetFullPath(Path.Combine(appDir, @"tools\ffmpeg\bin", exeName)));
                candidates.Add(Path.GetFullPath(Path.Combine(appDir, @"..\tools\ffmpeg\bin", exeName)));
                candidates.Add(Path.GetFullPath(Path.Combine(appDir, @"..\..\tools\ffmpeg\bin", exeName)));
            }
            string pluginDir = _host?.PluginDir;
            if (!string.IsNullOrWhiteSpace(pluginDir))
                candidates.Add(Path.GetFullPath(Path.Combine(pluginDir, @"tools\ffmpeg\bin", exeName)));
            foreach (var c in candidates) if (File.Exists(c)) return c;

            return null;
        }

        private static int RunTool(string exe, string args, out string stdout, out string stderr,
                                   bool trackForCancel = false)
        {
            var psi = new ProcessStartInfo(exe, args)
            {
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding = Encoding.UTF8,
            };
            using (var p = Process.Start(psi))
            {
                if (trackForCancel) _transcodeProc = p;      // 让「取消转码」能杀掉它
                var so = p.StandardOutput.ReadToEndAsync();
                var se = p.StandardError.ReadToEndAsync();
                try { p.WaitForExit(); }
                finally { if (trackForCancel) _transcodeProc = null; }
                stdout = SafeResult(so);
                stderr = SafeResult(se);
                return p.ExitCode;
            }
        }

        private static string SafeResult(Task<string> t)
        {
            try { return t.Wait(3000) ? t.Result : ""; } catch { return ""; }
        }

        private static string LastLines(string s, int n)
        {
            if (string.IsNullOrWhiteSpace(s)) return "(无输出)";
            var lines = s.Replace("\r", "").Split('\n').Where(x => x.Trim().Length > 0).ToArray();
            return string.Join(" | ", lines.Skip(Math.Max(0, lines.Length - n)));
        }

        // ---------------------------------------------------------------- ① 转码并导入

        private static void OnTranscode()
        {
            try
            {
                string src = (_videoText?.Text ?? "").Trim();
                if (src.Length == 0 || !File.Exists(src)) { SetStatus("先点「选择视频…」挑一个视频文件"); return; }

                string key = CurrentKey();
                if (string.IsNullOrWhiteSpace(key)) { SetStatus("先在「目标角色」里选一个，或手填角色 Id"); return; }

                string ffprobe = FindTool("ffprobe.exe");
                if (ffprobe == null) { SetStatus("没找到 ffprobe.exe（必须和 ffmpeg 在同一目录）：请在上面的 ffmpeg 框里手填路径"); return; }

                var (w, h) = Resolution();
                string outName = FileNameOf(key);
                string outDir  = Path.Combine(_host.PluginDir, "assets");
                Directory.CreateDirectory(outDir);
                string outPath = Path.Combine(outDir, outName);

                // ---- 先探测：已经是目标格式就跳过转码 ----
                var probe = ProbeSource(src, ffprobe);
                Trace("OnTranscode 探测：" + probe.Describe());

                if (probe.IsReady)
                {
                    string adv = QualityAdvisory(probe);
                    ImportDirect(probe, src, key, outName, outDir, outPath);
                    if (adv != null) SetStatus(_statusText + "　⚠ " + adv);
                    return;
                }

                // ---- 需要转码 ----
                string ffmpeg = FindTool("ffmpeg.exe");
                if (ffmpeg == null) { SetStatus("这个文件需要转码，但没找到 ffmpeg.exe：在上面手填路径，或用「浏览…」选一个"); return; }

                // 估算：libtheora 实测约 0.6~0.8 倍速（比实时慢），用于给 ETA，不保证准
                double est = probe.DurationSeconds > 0 ? probe.DurationSeconds / 0.65 : 0;

                // 目标分辨率不要超过源（放大只会更慢更糊）
                if (probe.Width > 0 && probe.Height > 0 && (probe.Width < w || probe.Height < h))
                {
                    // 保持 16:9 的较小那档
                    if (probe.Height <= 480) { w = 854; h = 480; }
                    else if (probe.Height <= 720) { w = 1280; h = 720; }
                }

                string tmpDir = Path.Combine(Path.GetTempPath(), "selectvideo_tmp");
                Directory.CreateDirectory(tmpDir);
                string tmpPath = Path.Combine(tmpDir, outName);
                try { if (File.Exists(tmpPath)) File.Delete(tmpPath); } catch { }
                try { if (File.Exists(outPath)) File.Delete(outPath); } catch { }

                _transcodeStart = DateTime.Now;
                _transcodeTotal = probe.DurationSeconds;
                _transcodeOut   = tmpPath;
                _transcodePath  = outPath;
                _transcodeName  = outName;
                _transcodeDir   = outDir;
                _transcodeKey   = key;
                _transcodeProbe = ffprobe;
                _progressFile   = Path.Combine(tmpDir, "progress_" + Guid.NewGuid().ToString("N") + ".txt");

                // 实测基准（1918x1080 / 240s / 372MB → 714s）：libtheora 大约 0.34 倍速。
                // 这里给用户一个诚实的首估，之后由 ffmpeg 的真实进度接管。
                double rough = probe.DurationSeconds > 0 ? probe.DurationSeconds / 0.34 : 0;

                SetStatus("转码中… " + w + "x" + h
                        + (rough > 0 ? "，预计约 " + FormatEta(rough) : "")
                        + "（源 " + (probe.DurationSeconds > 0 ? probe.DurationSeconds.ToString("0") + "s" : "时长未知")
                        + (probe.HasAudio ? "" : "，无音轨") + "；界面可继续用）");
                // -progress 会把「key=value」按行写进这个文件（直接写 stdout 会被我们同步读走、拿不到实时值）
                string args =
                    "-y -hide_banner -loglevel error -nostats " +
                    "-progress \"" + _progressFile + "\" " +
                    "-threads 0 -i \"" + src + "\" " +
                    "-vf \"scale=" + w + ":" + h + ":force_original_aspect_ratio=decrease," +
                    "pad=" + w + ":" + h + ":(ow-iw)/2:(oh-ih)/2,format=yuv420p\" " +
                    "-c:v libtheora -q:v 7 -speed_level 2 " +
                    "-c:a libvorbis -q:a 4 -ar 44100 -ac 2 " +
                    "-shortest \"" + tmpPath + "\"";

                StartProgressWatcher();

                Task.Run(() =>
                {
                    string so, se;
                    int code = RunTool(ffmpeg, args, out so, out se, trackForCancel: true);
                    Ui(() =>
                    {
                        StopProgressWatcher();
                        if (_transcodeCancelled)
                        {
                            _transcodeCancelled = false;
                            try { if (File.Exists(_transcodeOut)) File.Delete(_transcodeOut); } catch { }
                            return;                       // 已由 CancelTranscode 报过状态，别再覆盖
                        }
                        FinishTranscode(code, se, _transcodeProbe, _transcodeOut, _transcodePath,
                                        _transcodeName, _transcodeDir, _transcodeKey);
                    });
                });
            }
            catch (Exception e) { StopProgressWatcher(); SetStatus("转码出错：" + e.Message); Trace(e.ToString()); }
        }

        // ---------------------------------------------------------------- 转码进度

        private static DateTime _transcodeStart;
        private static double   _transcodeTotal;
        private static string   _transcodeOut, _transcodePath, _transcodeName, _transcodeDir, _transcodeKey, _transcodeProbe;
        private static DispatcherTimer _progressTimer;
        private static string _statusText = "";

        private static string FormatEta(double seconds)
        {
            if (seconds < 1) return "不到 1 秒";
            if (seconds < 60) return Math.Round(seconds) + " 秒";
            return Math.Floor(seconds / 60) + " 分 " + Math.Round(seconds % 60) + " 秒";
        }

        /// <summary>
        /// 每 700ms 看一眼输出文件长到哪了，用「已过时间 / 已完成进度」推算剩余时间。
        /// ffmpeg 的 -progress 走的是 stdout，我们这边拿不到（同步 RunTool），所以用文件大小估：
        /// 先按字节增长速率估总时长不可靠，改用「已用时 ÷ 已转时长」。
        /// 已转时长从 ffmpeg 的 -progress 拿不到，于是退一步：按时间线性给一个进度条式提示。
        /// </summary>
        private static void StartProgressWatcher()
        {
            try
            {
                StopProgressWatcher();
                var app = Application.Current;
                if (app == null) return;
                _progressTimer = new DispatcherTimer(DispatcherPriority.Background, app.Dispatcher)
                { Interval = TimeSpan.FromMilliseconds(1000) };
                _progressTimer.Tick += (s, e) =>
                {
                    try
                    {
                        double elapsed = (DateTime.Now - _transcodeStart).TotalSeconds;

                        // ★ 优先用 ffmpeg -progress 打出来的真实进度（out_time_us + speed），最准。
                        // 拿不到（还没写第一行）时才退回按倍率估算。
                        double done = 0, ffSpeed = 0;
                        try
                        {
                            if (File.Exists(_progressFile))
                            {
                                // 文件可能正被 ffmpeg 写着，允许共享读
                                using (var fs = new FileStream(_progressFile, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                                using (var sr = new StreamReader(fs))
                                {
                                    string all = sr.ReadToEnd();
                                    foreach (string line in all.Split('\n'))
                                    {
                                        string t = line.Trim();
                                        if (t.StartsWith("out_time_us=", StringComparison.Ordinal)
                                            && long.TryParse(t.Substring(12), out long us) && us > 0)
                                            done = us / 1_000_000.0;
                                        else if (t.StartsWith("speed=", StringComparison.Ordinal))
                                        {
                                            // 形如 speed=0.925x / speed=N/A
                                            string sv = t.Substring(6).Trim().TrimEnd('x', 'X');
                                            if (double.TryParse(sv, System.Globalization.NumberStyles.Float,
                                                                System.Globalization.CultureInfo.InvariantCulture, out double sp)
                                                && sp > 0.001) ffSpeed = sp;
                                        }
                                    }
                                }
                            }
                        }
                        catch { }

                        string eta = "";
                        if (_transcodeTotal > 0 && done > 0.5 && done < _transcodeTotal)
                        {
                            // ffmpeg 自己报的 speed 最可信；没有就用「已完成 ÷ 已用时」
                            double rate = ffSpeed > 0 ? ffSpeed : done / Math.Max(0.001, elapsed);
                            double left = (_transcodeTotal - done) / Math.Max(0.001, rate);
                            int pct = (int)Math.Round(done / _transcodeTotal * 100);
                            eta = "  " + pct + "%（" + FormatEta(done) + " / " + FormatEta(_transcodeTotal)
                                + "，" + rate.ToString("0.00") + "x），预计还要 " + FormatEta(left);
                        }
                        else if (_transcodeTotal > 0)
                        {
                            // 还没有进度：用实测基准 0.34 倍速给个粗估
                            double expect = _transcodeTotal / 0.34;
                            eta = "，预计约 " + FormatEta(expect);
                        }

                        long bytes = File.Exists(_transcodeOut) ? new FileInfo(_transcodeOut).Length : 0;
                        SetStatus("转码中… 已用 " + FormatEta(elapsed) + eta
                                + "（已写出 " + (bytes / 1024.0 / 1024.0).ToString("0.0") + " MB · 点「取消转码」可停止）");
                    }
                    catch { }
                };
                _progressTimer.Start();
            }
            catch { }
        }

        private static Process _transcodeProc;
        private static bool _transcodeCancelled;
        private static string _progressFile;

        private static void StopProgressWatcher()
        {
            try { if (_progressTimer != null) { _progressTimer.Stop(); _progressTimer = null; } } catch { }
        }

        /// <summary>取消正在跑的转码（杀掉 ffmpeg 子进程）。</summary>
        private static void CancelTranscode()
        {
            try
            {
                _transcodeCancelled = true;
                if (_transcodeProc != null && !_transcodeProc.HasExited)
                {
                    try { _transcodeProc.Kill(true); } catch { try { _transcodeProc.Kill(); } catch { } }
                    Trace("用户取消了转码，已结束 ffmpeg 进程");
                }
                StopProgressWatcher();
                try { if (!string.IsNullOrEmpty(_transcodeOut) && File.Exists(_transcodeOut)) File.Delete(_transcodeOut); } catch { }
                try { if (!string.IsNullOrEmpty(_progressFile) && File.Exists(_progressFile)) File.Delete(_progressFile); } catch { }
                SetStatus("已取消转码（上次选好的视频仍在，可以重新点「①」或换一个已经是 .ogv 的文件）");
            }
            catch (Exception e) { Trace("取消转码失败：" + e.Message); }
        }

        private static void FinishTranscode(int code, string stderr, string ffprobe,
                                            string tmpPath, string outPath, string outName, string outDir, string key)
        {
            try
            {
                if (code != 0 || !File.Exists(tmpPath))
                {
                    Trace("ffmpeg 失败 code=" + code + "\n" + stderr);
                    SetStatus("转码失败：" + LastLines(stderr, 3));
                    return;
                }

                // ---- 硬校验：必须 theora + vorbis 两条流都在 ----
                string so2, se2;
                RunTool(ffprobe,
                    "-v error -show_entries stream=codec_type,codec_name -of default=nw=1 \"" + tmpPath + "\"",
                    out so2, out se2);
                string probe = (so2 ?? "") + "\n" + (se2 ?? "");

                bool hasTheora = probe.Contains("codec_name=theora");
                bool hasVorbis = probe.Contains("codec_name=vorbis");
                if (!hasTheora || !hasVorbis)
                {
                    Trace("校验失败：theora=" + hasTheora + " vorbis=" + hasVorbis + "\n" + probe);
                    SetStatus("校验失败：视频流=" + hasTheora + "，音轨=" + hasVorbis
                            + "。这个素材没有声音或编码不对，换一个带音轨的视频再试。");
                    try { File.Delete(tmpPath); } catch { }
                    return;
                }

                // ---- 搬进插件 assets\（由 host.ImportAsset 负责：源在临时目录、目标在插件目录，同名也不算自复制）----
                string rel = _host.ImportAsset(tmpPath, outName);
                if (string.IsNullOrEmpty(rel))
                {
                    Trace("ImportAsset 返回空：src=" + tmpPath + " name=" + outName + " pluginDir=" + _host.PluginDir);
                    SetStatus("导入失败：ImportAsset 返回空（文件名非法 / 源文件不存在 / 插件目录不可写）。看 selectvideo.log。");
                    return;
                }
                try { File.Delete(tmpPath); } catch { }

                string written = Path.Combine(_host.PluginDir, rel.Replace('/', Path.DirectorySeparatorChar));
                if (File.Exists(written)) outPath = written;

                _rows[key] = outName;
                RefreshMapList();

                double used = (DateTime.Now - _transcodeStart).TotalSeconds;
                long outBytes = new FileInfo(outPath).Length;

                // 体积提醒：ogv 原样进 pck，几百 MB 会让 mod 很难装
                string sizeWarn = "";
                if (outBytes > 60L * 1024 * 1024)
                    sizeWarn = "　⚠ 产物 " + (outBytes / 1024 / 1024) + " MB 偏大（会一起进 pck）："
                             + "建议把源剪短到 30 秒内，或把「转码分辨率」改成 1280x720 再转一次";

                SetStatus("已转码 " + (outBytes / 1024) + " KB，用时 " + FormatEta(used)
                        + "（theora + vorbis 校验通过）→ " + key + " 用 " + outName
                        + "。接着点「② 保存配置」。" + sizeWarn);

                MakePoster(outPath, outDir, outName);
                Trace("转码完成：" + outName + " → key=" + key + " 用时 " + used.ToString("0.0") + "s 校验 theora/vorbis 通过");
            }
            catch (Exception e) { SetStatus("转码收尾出错：" + e.Message); Trace(e.ToString()); }
            finally
            {
                try { if (!string.IsNullOrEmpty(_progressFile) && File.Exists(_progressFile)) File.Delete(_progressFile); } catch { }
            }
        }

        private static (int w, int h) Resolution()
        {
            switch (_resCombo?.SelectedIndex ?? 0)
            {
                case 1: return (1920, 1080);
                case 2: return (854, 480);
                default: return (1280, 720);
            }
        }

        /// <summary>映射键 → 安全的 .ogv 文件名（"*" → all_bg.ogv）。</summary>
        private static string FileNameOf(string key)
        {
            string baseName;
            if (key == Wildcard) baseName = "all";
            else
            {
                baseName = Regex.Replace(key, "[^A-Za-z0-9_-]", "_");
                if (baseName.Length == 0) baseName = "char";
            }
            return baseName.ToLowerInvariant() + "_bg.ogv";
        }

        /// <summary>读 png 并立刻释放文件句柄（否则下次转码覆盖会 IOException）。</summary>
        private static ImageSource LoadBitmap(string path)
        {
            var bmp = new System.Windows.Media.Imaging.BitmapImage();
            bmp.BeginInit();
            bmp.CacheOption = System.Windows.Media.Imaging.BitmapCacheOption.OnLoad;
            bmp.UriSource = new Uri(path, UriKind.Absolute);
            bmp.EndInit();
            bmp.Freeze();
            return bmp;
        }

        // ---------------------------------------------------------------- 删除映射

        private static void OnRemove()
        {
            try
            {
                string key = SelectedMapKey() ?? CurrentKey();
                if (string.IsNullOrWhiteSpace(key) || !_rows.ContainsKey(key))
                {
                    SetStatus("先在下面的列表里选一条要删的映射（或在「目标角色」里选它）");
                    return;
                }
                string file = _rows[key];
                _rows.Remove(key);

                string pluginFile = Path.Combine(_host.PluginDir, "assets", file);
                if (File.Exists(pluginFile)) { try { File.Delete(pluginFile); } catch (Exception e) { Trace("删插件内视频失败：" + e.Message); } }

                if (!string.IsNullOrWhiteSpace(_host.OutputDir))
                {
                    string projFile = Path.Combine(_host.OutputDir, "plugin_assets", "selectvideo", file);
                    if (File.Exists(projFile)) { try { File.Delete(projFile); } catch (Exception e) { Trace("删工程内视频失败：" + e.Message); } }
                }

                RefreshMapList();
                SetStatus("已移除「" + key + "」的视频（记得点 ② 保存配置，再重新生成工程）");
            }
            catch (Exception e) { SetStatus("移除失败：" + e.Message); }
        }

        // ---------------------------------------------------------------- ② 保存配置

        private static void OnSave()
        {
            try
            {
                if (_rows.Count == 0) { SetStatus("还没有任何映射：先 ① 转码并导入"); return; }

                string csPath = Path.Combine(_host.PluginDir, "cs", "SelectVideo.cs");
                if (!File.Exists(csPath)) { _host.ReportProblem("找不到 " + CsRelPath); return; }

                string text = File.ReadAllText(csPath, Encoding.UTF8);
                int b = text.IndexOf(CfgBegin, StringComparison.Ordinal);
                int e = text.IndexOf(CfgEnd, StringComparison.Ordinal);
                if (b < 0 || e < b) { _host.ReportProblem(CsRelPath + " 里的 CFG 标记没找到"); return; }

                bool loop = _loopCheck?.IsChecked == true;
                float vol  = ParseFloat(_volBox?.Text, 0f);

                var sb = new StringBuilder();
                sb.Append(CfgBegin).Append("（这一段由「选人界面视频背景」面板生成，保存配置时整段重写）----\n");
                sb.Append("        // 键 = 角色 Id.Entry（类名 Slugify 后大写，例如 Kars → KARS）；\"*\" = 所有没单独配过的角色。\n");
                sb.Append("        internal static readonly Dictionary<string, SelectVideoEntry> Videos =\n");
                sb.Append("            new Dictionary<string, SelectVideoEntry>(StringComparer.OrdinalIgnoreCase)\n");
                sb.Append("            {\n");
                foreach (var kv in _rows.OrderBy(k => k.Key == Wildcard ? 0 : 1).ThenBy(k => k.Key, StringComparer.OrdinalIgnoreCase))
                {
                    sb.Append("                [\"").Append(EscapeCs(kv.Key)).Append("\"] = new SelectVideoEntry(\"")
                      .Append(EscapeCs(kv.Value)).Append("\", ")
                      .Append(loop ? "true" : "false").Append(", ")
                      .Append(Num(vol)).Append("f),\n");
                }
                sb.Append("            };\n");
                sb.Append("        internal static readonly bool  Enabled     = true;\n");
                sb.Append("        internal static readonly float VideoAspect = 1.7777778f;   // 16:9（转码统一 1280x720 / 1920x1080）\n");
                sb.Append("        ").Append(CfgEnd);

                File.WriteAllText(csPath, text.Substring(0, b) + sb.ToString() + text.Substring(e + CfgEnd.Length),
                    new UTF8Encoding(false));

                // 面板回填用（运行时也读这份的副本 —— 见下面 selectvideo.json）
                var vids = new JsonObject();
                foreach (var kv in _rows) vids[kv.Key] = kv.Value;
                var root = new JsonObject
                {
                    ["enabled"]    = true,
                    ["videos"]     = vids,
                    ["loop"]       = loop,
                    ["volumeDb"]   = vol,
                    ["resolution"] = _resCombo?.SelectedIndex ?? 0,
                };
                var opts = new JsonSerializerOptions
                {
                    WriteIndented = true,
                    Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
                };
                string localJson = Path.Combine(_host.PluginDir, "config.json");
                File.WriteAllText(localJson, root.ToJsonString(opts) + "\n", new UTF8Encoding(false));

                // ★ 运行时真正读的那一份，要随工程进 pck
                var runtimeJson = new JsonObject
                {
                    ["enabled"]  = true,
                    ["videos"]   = vids.DeepClone(),
                    ["loop"]     = loop,
                    ["volumeDb"] = vol,
                };
                string assetsDir = Path.Combine(_host.PluginDir, "assets");
                Directory.CreateDirectory(assetsDir);
                File.WriteAllText(Path.Combine(assetsDir, RuntimeCfgName),
                    runtimeJson.ToJsonString(opts) + "\n", new UTF8Encoding(false));

                SetStatus("已保存 " + _rows.Count + " 条 → " + CsRelPath + " 与 "
                        + RuntimeCfgName + "。去「构建 / 日志」页：生成工程 → 一键构建 + 安装。");
                Trace("Save：entries=" + _rows.Count + " loop=" + loop + " vol=" + vol);

                // ---- 把视频 + 运行时配置复制进当前生成工程（plugin_assets 构建时不会被清）----
                CopyVideosIntoProject();
            }
            catch (Exception e) { SetStatus("保存失败：" + e.Message); Trace(e.ToString()); }
        }

        private static string Num(float v) => v.ToString("0.###", System.Globalization.CultureInfo.InvariantCulture);

        /// <summary>
        /// 得到当前生成工程目录。
        /// host.OutputDir 在插件加载那一刻就被固定了 —— 如果那时还没「生成工程」/还没打开存档，它就是空串，
        /// 之后再点生成也不会变。所以这里依次兜底：
        ///   1. host.OutputDir（有就用）
        ///   2. MainWindow.CurrentProfilePath（…\自定义角色存档\KarsMod.json → 去掉扩展名 = 工程目录）
        ///   3. Profile.Paths.OutputDir + 存档名
        /// </summary>
        private static string ResolveOutputDir()
        {
            try
            {
                string fromHost = _host?.OutputDir;
                if (!string.IsNullOrWhiteSpace(fromHost) && Directory.Exists(fromHost)) return fromHost;
            }
            catch { }

            try
            {
                var win = Application.Current?.MainWindow;
                if (win != null)
                {
                    // 2) 当前存档路径 → 去掉 .json = 工程目录
                    string profilePath = null;
                    try { profilePath = win.GetType().GetProperty("CurrentProfilePath")?.GetValue(win) as string; } catch { }
                    if (!string.IsNullOrWhiteSpace(profilePath))
                    {
                        string dir = Path.Combine(Path.GetDirectoryName(profilePath) ?? "",
                                                  Path.GetFileNameWithoutExtension(profilePath));
                        if (Directory.Exists(dir)) { Trace("OutputDir 取自 CurrentProfilePath：" + dir); return dir; }
                    }

                    // 3) Profile.Paths.OutputDir + SaveName
                    var profile = win.GetType().GetProperty("Profile")?.GetValue(win);
                    if (profile != null)
                    {
                        var paths = profile.GetType().GetProperty("Paths")?.GetValue(profile);
                        string outRoot = paths?.GetType().GetProperty("OutputDir")?.GetValue(paths) as string;
                        string saveName = profile.GetType().GetProperty("SaveName")?.GetValue(profile) as string;
                        if (string.IsNullOrWhiteSpace(saveName))
                            saveName = profile.GetType().GetProperty("ModId")?.GetValue(profile) as string;
                        if (!string.IsNullOrWhiteSpace(outRoot) && !string.IsNullOrWhiteSpace(saveName))
                        {
                            string dir = Path.Combine(outRoot, saveName);
                            if (Directory.Exists(dir)) { Trace("OutputDir 取自 Profile.Paths：" + dir); return dir; }
                        }
                    }
                }
            }
            catch (Exception e) { Trace("推断 OutputDir 失败：" + e.Message); }

            return null;
        }

        /// <summary>
        /// 把插件 assets\ 里的 .ogv 复制进当前生成工程的 plugin_assets\selectvideo\。
        /// 生成前的清理函数叫 ClearGeneratedProjectKeepingPluginAssets —— plugin_assets 是唯一保留目录，
        /// 所以直接写文件即可（和 host.Generate 内部做的事一样，但不需要那个确认框）。
        /// </summary>
        private static void CopyVideosIntoProject()
        {
            try
            {
                string outDir = ResolveOutputDir();
                if (string.IsNullOrWhiteSpace(outDir) || !Directory.Exists(outDir))
                {
                    SetStatus("已保存配置。当前还没有生成工程：先去「构建 / 日志」点「生成工程」，"
                            + "然后再点一次「② 保存配置」把视频复制进工程。");
                    return;
                }

                string destDir = Path.Combine(outDir, "plugin_assets", "selectvideo");
                Directory.CreateDirectory(destDir);

                int n = 0;
                var missing = new List<string>();
                foreach (var kv in _rows)
                {
                    string src = Path.Combine(_host.PluginDir, "assets", kv.Value);
                    if (!File.Exists(src)) { missing.Add(kv.Value); continue; }
                    string dst = Path.Combine(destDir, kv.Value);
                    try
                    {
                        File.Copy(src, dst, true);
                        n++;
                    }
                    catch (Exception e) { missing.Add(kv.Value + "（" + e.Message + "）"); }
                }

                // 运行时配置也要进工程（否则游戏里退回文件名自动发现）
                try
                {
                    string cfgSrc = Path.Combine(_host.PluginDir, "assets", RuntimeCfgName);
                    if (File.Exists(cfgSrc)) File.Copy(cfgSrc, Path.Combine(destDir, RuntimeCfgName), true);
                    else Trace("运行时配置没生成：" + cfgSrc);
                }
                catch (Exception e) { Trace("复制 " + RuntimeCfgName + " 失败：" + e.Message); }

                if (missing.Count > 0)
                {
                    Trace("复制进工程缺失：" + string.Join("；", missing));
                    SetStatus("已保存 " + _rows.Count + " 条，复制进工程 " + n + " 个；缺：" + string.Join("；", missing));
                }
                else
                {
                    Trace("复制进工程 " + n + " 个 → " + destDir);
                    SetStatus("已保存 " + _rows.Count + " 条，并把 " + n + " 个 .ogv 复制进工程（"
                            + Path.Combine("plugin_assets", "selectvideo") + "）。"
                            + "去「构建 / 日志」页：生成工程 → 一键构建 + 安装。");
                }
            }
            catch (Exception e)
            {
                Trace("复制进工程失败：" + e.Message);
                SetStatus("配置已保存，但复制视频进工程失败：" + e.Message);
            }
        }

        private static float ParseFloat(string s, float def)
            => float.TryParse((s ?? "").Trim(), System.Globalization.NumberStyles.Float,
                              System.Globalization.CultureInfo.InvariantCulture, out var v) ? v : def;

        private static string EscapeCs(string s)
        {
            if (s == null) return "";
            var sb = new StringBuilder(s.Length + 8);
            foreach (char ch in s)
            {
                if (ch == '\\') sb.Append("\\\\");
                else if (ch == '"') sb.Append("\\\"");
                else if (ch == '\r') sb.Append("\\r");
                else if (ch == '\n') sb.Append("\\n");
                else sb.Append(ch);
            }
            return sb.ToString();
        }

        private static void LoadSavedConfig()
        {
            try
            {
                string p = Path.Combine(_host.PluginDir, "config.json");
                if (!File.Exists(p)) { RefreshMapList(); return; }

                var node = JsonNode.Parse(File.ReadAllText(p, Encoding.UTF8)) as JsonObject;
                if (node?["videos"] is JsonObject vids)
                {
                    foreach (var kv in vids)
                    {
                        if (kv.Value is JsonValue jv && jv.TryGetValue<string>(out var s) && !string.IsNullOrWhiteSpace(s))
                            _rows[kv.Key] = s;
                    }
                }
                if (node?["loop"] is JsonValue lv && lv.TryGetValue<bool>(out var loop) && _loopCheck != null)
                    _loopCheck.IsChecked = loop;
                if (node?["volumeDb"] is JsonValue dv && dv.TryGetValue<double>(out var db) && _volBox != null)
                    _volBox.Text = db.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture);
                if (node?["resolution"] is JsonValue rv && rv.TryGetValue<int>(out var res) && _resCombo != null
                    && res >= 0 && res < _resCombo.Items.Count)
                    _resCombo.SelectedIndex = res;

                RefreshMapList();
                Trace("读回 " + _rows.Count + " 条配置");
            }
            catch (Exception e) { Trace("读 config.json 失败：" + e.Message); }
        }

        // ---------------------------------------------------------------- 杂项

        private static void Ui(Action action)
        {
            try
            {
                var app = Application.Current;
                if (app == null) { try { action(); } catch { } return; }
                app.Dispatcher.BeginInvoke(new Action(() => { try { action(); } catch (Exception e) { Trace("UI 回调异常：" + e.Message); } }));
            }
            catch { }
        }

        private static void SetStatus(string text)
        {
            try { if (_status != null) _status.Text = "状态：" + text; } catch { }
        }

        private static void Log(string m) => Trace(m);

        private static void Trace(string m)
        {
            string line = DateTime.Now.ToString("HH:mm:ss.fff") + "  " + m + Environment.NewLine;

            // 1) 宿主日志（「插件」页 / 控制台都能看到）
            try { _host?.Log("[选人视频] " + m); } catch { }

            // 2) 插件目录下的日志文件
            try
            {
                string dir = _host?.PluginDir;
                if (!string.IsNullOrWhiteSpace(dir))
                    File.AppendAllText(Path.Combine(dir, "selectvideo.log"), line, new UTF8Encoding(false));
            }
            catch { }

            // 3) 兜底：临时目录（插件目录不可写时至少还有一份）
            try
            {
                File.AppendAllText(Path.Combine(Path.GetTempPath(), "selectvideo.log"), line, new UTF8Encoding(false));
            }
            catch { }

            try { Console.WriteLine("[selectvideo] " + m); } catch { }
            try { Debug.WriteLine("[selectvideo] " + m); } catch { }
        }

        /// <summary>
        /// 广度优先找第一个 T。逐个子节点 try/catch —— 插件重新加载后，旧页签内容属于已卸载的
        /// AssemblyLoadContext，访问它会抛异常；如果整段包一个 try，一个坏子树就会让整个查找提前中止
        /// （表现：定时器一直跑、页签永远挂不上）。
        /// </summary>
        private static T FindFirst<T>(DependencyObject root) where T : DependencyObject
        {
            if (root == null) return null;
            var queue = new Queue<DependencyObject>();
            queue.Enqueue(root);
            int guard = 0;

            while (queue.Count > 0 && guard++ < 20000)
            {
                DependencyObject node = queue.Dequeue();
                try { if (node is T hit) return hit; } catch { continue; }

                int n;
                try { n = VisualTreeHelper.GetChildrenCount(node); } catch { continue; }
                for (int i = 0; i < n; i++)
                {
                    DependencyObject child = null;
                    try { child = VisualTreeHelper.GetChild(node, i); } catch { }
                    if (child != null) queue.Enqueue(child);
                }
            }
            return null;
        }

        /// <summary>尽量安全地读一个 DependencyObject 的名字（旧 ALC 的对象可能已不可用）。</summary>
        private static string SafeHeader(object o)
        {
            try { return (o as TabItem)?.Header as string; } catch { return null; }
        }
    }
}
