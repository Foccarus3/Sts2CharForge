# 图片播放（全场叠加动画）

给卡牌 / 遗物 / 药水 / 自定义状态 / 锻造图加一个「**在屏幕上播放一张图**」的效果：
叠在整屏最上层，播 N 秒，入场、出场各一段动画。时长、动画类型、尺寸、位置、不透明度全部在
**「插件」页的图片表**里配，改完点一次「生成到当前工程」就生效。

- 插件 id：`image_cutin`
- 版本：1.0.0（apiVersion 2）
- 自带文件：`cs/ImageCutInRuntime.cs`（随模组一起编译，不加载 DLL）

---

## 一、装插件

把整个 `图片播放` 文件夹放进编辑器插件目录（bundle 下的 `程序文件\plugins\`）：

```
Sts2CharForge-bundle\程序文件\plugins\图片播放\
    plugin.json
    cs\ImageCutInRuntime.cs
    README.md
```

然后编辑器「插件」页点「重新加载插件」，左边列表能看到「图片播放（全场叠加动画）」，
右边「信息」页能看到 **2 条效果**、**2 个页面**，⚠ 列表是空的。

---

## 二、放图（相对路径，跟着 mod 打包走）

先认一下 bundle 里的目录（以 `Sts2CharForge-bundle\` 为根）：

```
Sts2CharForge-bundle\
├─ 程序文件\                         ← 编辑器本体（Sts2CharForge.exe 所在）
├─ 插件\图片播放\                    ← 本插件的源文件
└─ 自定义角色存档\<你的存档名>\       ← 生成出来的 mod 工程（下面叫「工程目录」）
   └─ plugin_assets\image_cutin\      ← 图放这里
       cutin.png
       lae_ult.png
```

把图片丢进工程目录的 `plugin_assets\image_cutin\`（目录没有就自己建）。`plugin_assets` 是工程自己的目录，
生成工程不会清它，构建时随工程打进 pck —— 装了 mod 的人都能看到，不用在每台机器上单独拷。

**两个路径前缀对应到磁盘哪里**（运行时用的是 Godot 路径，对照下表找）：

| 运行时写法 | 磁盘位置 |
|---|---|
| `res://` | 工程目录 = `自定义角色存档\<你的存档名>\`；`res://plugin_assets/image_cutin/` 就是上面那个文件夹 |
| `user://` | `%APPDATA%\SlayTheSpire2\`；`user://image_cutin/` = `%APPDATA%\SlayTheSpire2\image_cutin\`，本机兜底，不随 mod 分发 |

**路径口径**：表里写的都是相对工程目录的相对路径，**不绑工程名、不绑机器**，
换任何 mod 工程、换台电脑都通用。绝对路径只在本地调试用，别写进要分发的配置。

* 支持 **PNG / JPG / WEBP / BMP**；带透明通道的 PNG 最合适（叠在战斗画面上不会挡背景）。
* 文件名别用中文也别用空格，例如 `cutin.png`、`lae_ult.png`。

表里「图片文件」能填的写法：

| 填法 | 解析到哪 |
|---|---|
| `cutin.png`（纯文件名） | 先工程 `plugin_assets\image_cutin\cutin.png`，再用户目录兜底 |
| `assets/cutin.png` | 规范相对路径，映射到工程 `plugin_assets\image_cutin\cutin.png` |
| `images/cutin.png` | 相对工程目录根 → `res://images/cutin.png` |
| `res://…` / `user://…` | 全路径原样（对照上表找磁盘位置） |
| `D:\art\cutin.png` | 绝对路径，仅本地调试 |

找图顺序（纯文件名时）：

1. 工程目录 `plugin_assets\image_cutin\<文件名>`（`res://plugin_assets/image_cutin/<文件名>`）—— **优先**。
   工程里的 PNG 会被 Godot 导入成资源打进 pck，运行时先走 `ResourceLoader` 拿纹理（pck 里只有 `.ctex`，读原始字节读不到），
   失败再退回读原始字节（开发期直接用工程目录跑）。
2. 用户目录 `%APPDATA%\SlayTheSpire2\image_cutin\<文件名>`（`user://image_cutin/<文件名>`）—— 本机兜底，
   不随 mod 分发，适合临时换图调试。

> 别把图放游戏安装目录里的 `mods\xxx.pck` 旁边 —— pck 是个打包文件，往里塞图必须重新导出工程。

---

## 三、填表

「插件」页 → 左边选中本插件 → 右边「**图片播放：图片表**」。一行一张图，**行号就是效果里填的号**：

| 栏位 | 说明 |
|---|---|
| 图片文件 | 相对路径：`cutin.png` / `assets/cutin.png` / `images/cutin.png`，或 `res://` / `user://` 全路径；绝对路径仅本地调试 |
| 显示时长 N（秒） | 从出现到完全消失的总时长 |
| 入场时长（秒） | 入场动画用多久 |
| 出场时长（秒） | 出场动画用多久 |
| 入场效果 | 淡入 / 从下方滑入 / 从上方滑入 / 从左侧滑入 / 从右侧滑入 / 弹出（缩放）/ 放大渐显 / 无（直接出现） |
| 出场效果 | 淡出 / 向下滑出 / 向上滑出 / 向左滑出 / 向右滑出 / 缩小消失 / 无（直接消失） |
| 尺寸（屏宽 %） | 100 = 铺满屏幕能放下的最大尺寸（保持比例、不拉伸），50 = 一半大 |
| 位置 | 居中 / 偏上 / 偏下（各偏 12% 屏高） |
| 不透明度（%） | 最终停在多少，100 = 完全不透明 |

改完点「**生成到当前工程**」→ 写 `cs/Plugins/image_cutin/ImageCutInConfig.cs`。
（直接点「生成工程」也会写，不用两个都点。）

时间轴：

```
|←—— 入场 ——→|←——— 停留 ———→|←—— 出场 ——→|
             总时长 N（从出现到完全消失）
```

`入场 + 出场` 超过 N 时，出场会被压到剩下的时间；入场 / 出场选「无」时那段并进停留。

---

## 四、用效果

卡牌 / 遗物 / 药水 / 自定义状态 / 锻造图的「效果种类」下拉里多出两条：

| 效果 | 行为 |
|---|---|
| **图片播放：播放图片（第 N 号）** | 数值框 = 表里的行号，图立刻开始播，**不阻塞**后面的结算 |
| **图片播放：播放图片并等待（阻塞后续）** | 同上，但会等图播完（N 秒）才继续跑后面的效果 |

例：一张「觉醒」牌，效果列表 = ①图片播放（第 1 号）②造成 20 点伤害 —— 图一开始播，伤害同时结算。

想「图演完再打」：把 ① 换成「播放并等待」。

> 卡牌链**别勾「下回合生效」**：延迟到下回合才播，多半不是你要的。

---

## 五、边界（重要）

* **纯表现**：不改数值、不推进随机数、不动本体 UI 树 → **联机不会不同步**，各端各播自己的。
* 图上**不挡鼠标**（`MouseFilter = Ignore`），边播边点牌没问题。
* **快进 / 无交互模式**（联机等待、自动测试）不叠图。
* 同时触发多张会**叠在一起**，后触发的在上面；要避免就在卡上加条件。
* 正在播的时候进下一层 / 切场景，图会在根画面上把剩余时间播完（一般一两秒）。
* 纹理按文件名缓存：改了图但**文件名没变**，要重启游戏才会换过来（想热换就换个文件名、改一下表）。
* 「播放并等待」会把这张牌的结算整个拖住 N 秒多，**别在日常输出牌上用。**

---

## 六、验证

1. 「插件」页 →「重新加载插件」→ 列表里出现本插件，⚠ 为空，贡献 2 条效果 + 2 个页面。
2. 工程里建 `plugin_assets\image_cutin\`，把 `cutin.png` 丢进去。
3. 「插件」页 →「图片播放：图片表」→ 填一行：`cutin.png`、N=3、入场 0.5、出场 0.5、淡入 / 淡出、100%、居中、100%。
4. 点「生成到当前工程」，工程里应有 `cs\Plugins\image_cutin\ImageCutInConfig.cs`。
5. 随便做一张牌，效果选「图片播放：播放图片（第 N 号）」，数值填 1，生成工程 → 构建安装。
6. 进游戏打出那张牌：图从透明淡入、停 2 秒、淡出消失。
7. 日志（`%APPDATA%\SlayTheSpire2\logs`）搜 `[图片播放]`：
   * `已加载图片 res://plugin_assets/image_cutin/cutin.png（资源）` → 走 pck 里的导入资源读到了；
   * `已加载图片 user://image_cutin/cutin.png（1920x1080）` → 走用户目录的原始字节读到了；
   * `读不到图片「cutin.png」，找过：...` → 文件位置 / 名字不对（大小写也要对上）；
   * `图片表是空的` → 没填表或没点「生成到当前工程」。

---

## 七、实现说明（给后来改代码的人）

* 叠加层：`SceneTree.Root` 上挂一个 `CanvasLayer(Layer = 200)`，只建一次、之后复用；
  每次播放往里加一个满屏 `Control` + `TextureRect`（`KeepAspectCentered`），播完 `QueueFree`。
* 动画：`Tween` 动 `modulate`（透明度）/ `offset_left|right|top|bottom`（位移，同时改两边保证尺寸不变）/
  `scale`（缩放，`PivotOffset` 取屏幕中心）；时间轴用 `SceneTreeTimer` 走，跟着游戏倍速。
* 图片：`file` 只写文件名时，先拼 `res://plugin_assets/image_cutin/<名字>`，
  用 `ResourceLoader.Exists` + `ResourceLoader.Load<Texture2D>` 取（工程里的 PNG 被导入成 `.ctex` 打进 pck，
  pck 里没有原始文件，只能走资源加载）；取不到再退回 `Godot.FileAccess.GetFileAsBytes` 读原始字节
  → `Image.LoadPng/Jpg/Webp/BmpFromBuffer` → `ImageTexture.CreateFromImage`（开发期 `user://`、绝对路径走这条），
  按文件名缓存。`Path.IsPathRooted` / 带 `://` 的写法原样用；`assets/<名字>` 剥掉 `assets/` 前缀映射到
  `plugin_assets/image_cutin/<名字>`；`a/b.png` 这种先试 `res://plugin_assets/image_cutin/a/b.png`，再试 `res://a/b.png`。
* 图片表：页面生成 `ImageCutInConfig`（`ImageCutInEntry[]`），运行时用**反射**取 `Plugins.ImageCutIn.ImageCutInConfig.Entries`
  —— 万一还没生成这张表，也只会打一条日志，不会让整个模组编不过。
* 页面值一律写成**原样字符串**（`@"..."`），所以 Windows 绝对路径里的 `\` 不会被当成转义符（`\u` / `\a` 那种编译错）。
* 只依赖 `MegaCrit.Sts2.Core.Helpers.NonInteractiveMode` 与 `Log`，其余全是 Godot 通用 API。
* 已做过的验证（都在本机跑过）：
  1. 用游戏真实程序集（`GodotSharp.dll` + `sts2.dll`）编译：**0 错误 0 警告**；
  2. 用编辑器自己的 `PluginRegistry.Load` 扫描：**Problems 0 / Notes 0**，效果与页面都在；
  3. 用编辑器自己的 `PluginGen.WritePages` 按两行样表生成 `ImageCutInConfig.cs`，再和运行时一起编译：**0 错误**。
