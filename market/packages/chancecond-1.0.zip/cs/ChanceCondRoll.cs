// 概率条件（插件 chancecond）的运行时。
// 生成工程时本文件会被拷到 cs/Plugins/chancecond/ 下，和模组一起编译、一起打包。
// 条件表达式只调用这里的三条静态方法：
//   ChanceCondRoll.Roll(player, percent)         每次求值重新摇
//   ChanceCondRoll.OncePerTurn(player, percent)  同一回合内结果固定（按 玩家 + 战斗实例 + 回合数 + 概率值 缓存；
//                                                战斗外没有「回合」概念，退回每次求值重摇）
//   ChanceCondRoll.Local(percent)                纯本地随机（System.Random，不读种子）
//
// 随机流的选择：本体编辑器自带的「概率生效」那一栏用的是
//     double __chanceRoll = <player>.RunState.Rng.Niche.NextDouble() * 100.0;
// 这里沿用同一条（RunState.Rng.Niche）—— 它本身就是「不影响抽牌 / 奖励这些有顺序语义的随机数、
// 专门给这类一次性判定用」的那条流；而且它随存档序列化、联机开局会同步，所以：
//   * 不会打乱抽牌 / 奖励 / 选牌的随机结果；
//   * 同一局同样的调用顺序，两根客户端算出来一致；
//   * 读档后接着往下摇，不会把开头几次再放一遍。
#nullable enable

using System;
using System.Collections.Generic;
using MegaCrit.Sts2.Core.Combat;
using MegaCrit.Sts2.Core.Entities.Players;

namespace Plugins.ChanceCond;

/// <summary>「N% 概率判定」条件（插件 chancecond）的运行时。</summary>
public static class ChanceCondRoll
{
    private static readonly object Gate = new object();

    private static readonly Dictionary<Player, Dictionary<decimal, bool>> TurnCache =
        new Dictionary<Player, Dictionary<decimal, bool>>();
    private static ICombatState? _turnScope;
    private static int _turnRound = int.MinValue;

    /// <summary>
    /// 每次求值都重新摇一次（不缓存）。
    /// 【如果】节点：命中走「是」，没中走「否」。
    /// 【循环】节点：条件每轮重算 → 每轮重摇，没中就结束循环（生成端还有 50 轮硬保护）。
    /// </summary>
    public static bool Roll(Player? player, decimal percent)
    {
        if (percent <= 0m) return false;      // 0% = 永不中
        if (percent >= 100m) return true;     // 100% = 必中
        if (player is null) return LocalHit(percent);

        lock (Gate)
        {
            return IsHit(player, percent);
        }
    }

    /// <summary>
    /// 同一回合里无论被问多少次，答案都一样；下一回合重新摇。
    /// 适合【如果】节点，以及会被反复求值的地方（比如写进 IsPlayable 的那种检查）。
    /// ⚠ 不要接【循环】：循环条件每轮都会重算，但这里一回合只摇一次 —— 要么一直循环（50 轮保护兜底），
    /// 要么一次都不循环。
    /// </summary>
    public static bool OncePerTurn(Player? player, decimal percent)
    {
        if (percent <= 0m) return false;
        if (percent >= 100m) return true;
        if (player is null) return LocalHit(percent);

        lock (Gate)
        {
            ICombatState? combat = player.Creature?.CombatState;

            // 战斗外没有「回合」这个概念：不缓存，每次求值重摇。
            if (combat is null) return IsHit(player, percent);

            int round = combat.RoundNumber;
            if (!ReferenceEquals(combat, _turnScope) || round != _turnRound)
            {
                TurnCache.Clear();
                _turnScope = combat;
                _turnRound = round;
            }

            // 每个玩家各摇各的：同一回合、同一个概率值，联机里不同玩家可以一个中一个不中。
            if (!TurnCache.TryGetValue(player, out Dictionary<decimal, bool>? percents))
            {
                percents = new Dictionary<decimal, bool>();
                TurnCache[player] = percents;
            }

            if (percents.TryGetValue(percent, out bool cached))
            {
                return cached;
            }

            bool value = IsHit(player, percent);
            percents[percent] = value;
            return value;
        }
    }

    /// <summary>
    /// 纯本地随机：不读局内种子，也不碰本体的随机流。
    /// 单人玩没问题；联机两端会各摇各的（不同步），开联机 / 看回放时别用。
    /// </summary>
    public static bool Local(decimal percent)
    {
        if (percent <= 0m) return false;
        if (percent >= 100m) return true;
        return LocalHit(percent);
    }

    // —— 内部 ——

    /// <summary>本体「概率生效」同款：RunState.Rng.Niche 摇 0–100。</summary>
    private static bool IsHit(Player player, decimal percent)
    {
        return player.RunState.Rng.Niche.NextDouble() * 100.0 < (double)percent;
    }

    private static bool LocalHit(decimal percent)
    {
        return System.Random.Shared.NextDouble() * 100.0 < (double)percent;
    }
}
