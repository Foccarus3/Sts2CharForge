// 「记录面板」游戏内逻辑（V2.1 - 支持动态槽位、整体UI/槽位边框、专属图片等）
#nullable disable

using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Threading.Tasks;
using Godot;
using MegaCrit.Sts2.Core.Combat;
using MegaCrit.Sts2.Core.Commands;
using MegaCrit.Sts2.Core.Context;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.Entities.Creatures;
using MegaCrit.Sts2.Core.Entities.Players;
using MegaCrit.Sts2.Core.Entities.Powers;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.HoverTips;
using MegaCrit.Sts2.Core.Localization;
using MegaCrit.Sts2.Core.Logging;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Nodes;
using MegaCrit.Sts2.Core.Nodes.Cards;
using MegaCrit.Sts2.Core.Nodes.CommonUi;
using MegaCrit.Sts2.Core.Nodes.HoverTips;
using MegaCrit.Sts2.Core.Nodes.Pooling;
using MegaCrit.Sts2.Core.Nodes.Rooms;

public static class SlotCardRecorder
{
    private static int _slotCount = 3;

    private sealed class SlotEntry
    {
        public string CardClass = "";
        public string CardTitle = "";
        public string PowerClass = "";
        public int Stacks;
        public string UiImage = "";
        public CardModel Model;
        public bool IsUpgraded;
    }

    private static readonly List<SlotEntry> _slots = new List<SlotEntry>();
    private static readonly List<NCard> _pooledCards = new List<NCard>();

    private static string _scope = "本场战斗";
    private static string _uiBg = "";
    private static float _uiWidth = 600f;
    private static float _uiHeight = 150f;
    private static float _uiTopOffset = 8f;
    private static float _cardSize = 100f;
    private static bool _allowDrag = true;
    private static bool _savePos = true;
    private static bool _showHover = true;
    
    private static string _uiBorderColor = "#000000";
    private static string _uiBorderImage = "";
    private static string _slotBorderColor = "#FFFFFF";

    private static readonly Dictionary<string, string[]> _pairs = new Dictionary<string, string[]>();
    private static readonly Dictionary<string, Type> _typeCache = new Dictionary<string, Type>();

    private static Control _topBar;
    private static Control _panelContainer;
    private static Button _toggleBtn;
    
    private class SlotUI
    {
        public Control Root;
        public Control CardHolder;
        public Label PowerLabel;
        public Panel Border;
    }
    private static SlotUI[] _slotUIs;
    private static bool _isOpen = true;

    private static bool _isDragging = false;
    private static Vector2 _dragStartPos;
    private static Vector2 _dragStartMousePos;

    public static void TryInstall(NGlobalUi globalUi)
    {
        try
        {
            if (globalUi == null) return;
            RemoveTopBar();
            ReloadConfig();
            BuildTopBar(globalUi);
        }
        catch (Exception e)
        {
            Log.Error("SlotCardRecorder: 安装失败 - " + e.GetType().Name + ": " + e.Message);
        }
    }

    private static void RemoveTopBar()
    {
        try
        {
            if (_topBar != null && GodotObject.IsInstanceValid(_topBar))
            {
                _topBar.TreeExiting -= OnTopBarExiting;
                _topBar.QueueFree();
            }
        }
        catch { }
        _topBar = null;
        _panelContainer = null;
        _toggleBtn = null;
        _slotUIs = null;
        CleanupPooledCards();
    }

    private static void OnTopBarExiting()
    {
        try { _slots.Clear(); CleanupPooledCards(); } catch { }
    }

    private static void BuildTopBar(NGlobalUi globalUi)
    {
        _topBar = new Control();
        _topBar.Name = "__SlotRecorderTopBar";
        _topBar.AnchorLeft = 0.5f; _topBar.AnchorTop = 0f; _topBar.AnchorRight = 0.5f; _topBar.AnchorBottom = 0f;
        
        _topBar.OffsetLeft = -_uiWidth / 2f;
        _topBar.OffsetTop = _uiTopOffset;
        _topBar.OffsetRight = _uiWidth / 2f;
        _topBar.OffsetBottom = _uiTopOffset + _uiHeight;
        
        _topBar.MouseFilter = Control.MouseFilterEnum.Stop; 
        if (_allowDrag) _topBar.GuiInput += OnTopBarGuiInput;

        if (_savePos)
        {
            try
            {
                string configPath = "user://slot_recorder_pos.cfg";
                var cfg = new ConfigFile();
                if (cfg.Load(configPath) == Error.Ok)
                {
                    float sx = (float)cfg.GetValue("pos", "x", _topBar.Position.X);
                    float sy = (float)cfg.GetValue("pos", "y", _topBar.Position.Y);
                    _topBar.Position = new Vector2(sx, sy);
                }
            }
            catch { }
        }

        _toggleBtn = new Button();
        _toggleBtn.Text = "▲"; 
        _toggleBtn.AddThemeFontSizeOverride("font_size", 12);
        _toggleBtn.Flat = true;
        _toggleBtn.FocusMode = Control.FocusModeEnum.None;
        _toggleBtn.AnchorLeft = 0.5f; _toggleBtn.AnchorTop = 0f; _toggleBtn.AnchorRight = 0.5f; _toggleBtn.AnchorBottom = 0f;
        _toggleBtn.OffsetLeft = -16f; _toggleBtn.OffsetTop = -28f; _toggleBtn.OffsetRight = 16f; _toggleBtn.OffsetBottom = -6f;
        _toggleBtn.Pressed += OnTogglePressed;
        _topBar.AddChild(_toggleBtn);

        _panelContainer = new Control();
        _panelContainer.Name = "__SlotRecorderPanel";
        _panelContainer.AnchorLeft = 0f; _panelContainer.AnchorTop = 0f; _panelContainer.AnchorRight = 1f; _panelContainer.AnchorBottom = 1f;
        _panelContainer.OffsetLeft = 0f; _panelContainer.OffsetTop = 0f; _panelContainer.OffsetRight = 0f; _panelContainer.OffsetBottom = 0f;
        _panelContainer.MouseFilter = Control.MouseFilterEnum.Ignore;
        _topBar.AddChild(_panelContainer);

        // === 整体 UI 边框 ===
        if (!string.IsNullOrEmpty(_uiBorderImage))
        {
            try
            {
                string path = _uiBorderImage.Replace("assets/", "res://plugin_assets/SlotCardRecorder/");
                if (!path.StartsWith("res://")) path = "res://" + path;
                Texture2D tex = GD.Load<Texture2D>(path);
                if (tex != null)
                {
                    NinePatchRect border = new NinePatchRect();
                    border.Texture = tex;
                    border.PatchMarginLeft = 10;
                    border.PatchMarginTop = 10;
                    border.PatchMarginRight = 10;
                    border.PatchMarginBottom = 10;
                    border.AnchorLeft = 0f; border.AnchorTop = 0f; border.AnchorRight = 1f; border.AnchorBottom = 1f;
                    border.OffsetLeft = 0f; border.OffsetTop = 0f; border.OffsetRight = 0f; border.OffsetBottom = 0f;
                    border.MouseFilter = Control.MouseFilterEnum.Ignore;
                    
                    if (!string.IsNullOrEmpty(_uiBorderColor))
                    {
                        try { border.Modulate = new Color(_uiBorderColor); } catch { }
                    }
                    
                    _panelContainer.AddChild(border);
                }
            }
            catch (Exception e) { Log.Error("SlotCardRecorder: 加载整体边框图片失败 - " + e.Message); }
        }
        else if (!string.IsNullOrEmpty(_uiBorderColor))
        {
            try
            {
                Panel border = new Panel();
                border.AnchorLeft = 0f; border.AnchorTop = 0f; border.AnchorRight = 1f; border.AnchorBottom = 1f;
                border.OffsetLeft = 0f; border.OffsetTop = 0f; border.OffsetRight = 0f; border.OffsetBottom = 0f;
                border.MouseFilter = Control.MouseFilterEnum.Ignore;
                var style = new StyleBoxFlat();
                style.BgColor = new Color(0, 0, 0, 0);
                style.BorderWidthLeft = 3; style.BorderWidthTop = 3; style.BorderWidthRight = 3; style.BorderWidthBottom = 3;
                style.BorderColor = new Color(_uiBorderColor);
                border.AddThemeStyleboxOverride("panel", style);
                _panelContainer.AddChild(border);
            }
            catch { }
        }

        if (!string.IsNullOrEmpty(_uiBg))
        {
            try
            {
                string path = _uiBg.Replace("assets/", "res://plugin_assets/SlotCardRecorder/");
                if (!path.StartsWith("res://")) path = "res://" + path;
                Texture2D tex = GD.Load<Texture2D>(path);
                if (tex != null)
                {
                    TextureRect bg = new TextureRect();
                    bg.Texture = tex;
                    bg.ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize;
                    bg.StretchMode = TextureRect.StretchModeEnum.Scale;
                    bg.AnchorLeft = 0f; bg.AnchorTop = 0f; bg.AnchorRight = 1f; bg.AnchorBottom = 1f;
                    bg.OffsetLeft = 0f; bg.OffsetTop = 0f; bg.OffsetRight = 0f; bg.OffsetBottom = 0f;
                    bg.MouseFilter = Control.MouseFilterEnum.Ignore;
                    _panelContainer.AddChild(bg);
                }
            }
            catch (Exception e) { Log.Error("SlotCardRecorder: 加载背景图失败 - " + e.Message); }
        }

        CenterContainer center = new CenterContainer();
        center.AnchorLeft = 0f; center.AnchorTop = 0f; center.AnchorRight = 1f; center.AnchorBottom = 1f;
        center.OffsetLeft = 0f; center.OffsetTop = 0f; center.OffsetRight = 0f; center.OffsetBottom = 0f;
        center.MouseFilter = Control.MouseFilterEnum.Ignore;
        _panelContainer.AddChild(center);

        GridContainer grid = new GridContainer();
        grid.Columns = Math.Min(_slotCount, 4); 
        grid.AddThemeConstantOverride("h_separation", 20);
        grid.AddThemeConstantOverride("v_separation", 10);
        grid.MouseFilter = Control.MouseFilterEnum.Ignore;
        center.AddChild(grid);

        float slotWidth = (_uiWidth / Math.Min(_slotCount, 4)) - 20f; 
        
        _slotUIs = new SlotUI[_slotCount];
        for (int i = 0; i < _slotCount; i++)
        {
            SlotUI ui = new SlotUI();
            
            ui.Root = new Control();
            ui.Root.CustomMinimumSize = new Vector2(slotWidth, _uiHeight / (float)Math.Ceiling(_slotCount / 4.0) - 10f);
            ui.Root.MouseFilter = Control.MouseFilterEnum.Ignore;

            int slotIndex = i;
            ui.Root.GuiInput += (InputEvent ev) => {
                if (ev is InputEventMouseButton mb && mb.Pressed && mb.ButtonIndex == MouseButton.Right)
                {
                    ClearSlot(slotIndex);
                }
            };

            // 槽位边框
            ui.Border = new Panel();
            ui.Border.AnchorLeft = 0f; ui.Border.AnchorTop = 0f; ui.Border.AnchorRight = 1f; ui.Border.AnchorBottom = 1f;
            ui.Border.OffsetLeft = 0f; ui.Border.OffsetTop = 0f; ui.Border.OffsetRight = 0f; ui.Border.OffsetBottom = 0f;
            ui.Border.MouseFilter = Control.MouseFilterEnum.Ignore;
            
            var style = new StyleBoxFlat();
            style.BgColor = new Color(0, 0, 0, 0); 
            style.BorderWidthLeft = 2; style.BorderWidthTop = 2; style.BorderWidthRight = 2; style.BorderWidthBottom = 2;
            if (!string.IsNullOrEmpty(_slotBorderColor))
            {
                try { style.BorderColor = new Color(_slotBorderColor); } catch { style.BorderColor = Colors.White; }
            }
            ui.Border.AddThemeStyleboxOverride("panel", style);
            ui.Root.AddChild(ui.Border);

            ui.CardHolder = new Control();
            ui.CardHolder.AnchorLeft = 0.5f; ui.CardHolder.AnchorTop = 0f; ui.CardHolder.AnchorRight = 0.5f; ui.CardHolder.AnchorBottom = 0f;
            ui.CardHolder.OffsetLeft = 0f; ui.CardHolder.OffsetTop = 0f; ui.CardHolder.OffsetRight = 0f; ui.CardHolder.OffsetBottom = 0f;
            ui.CardHolder.MouseFilter = Control.MouseFilterEnum.Ignore;
            ui.Root.AddChild(ui.CardHolder);

            ui.PowerLabel = new Label();
            ui.PowerLabel.Text = "—";
            ui.PowerLabel.HorizontalAlignment = Godot.HorizontalAlignment.Center;
            ui.PowerLabel.VerticalAlignment = Godot.VerticalAlignment.Center;
            ui.PowerLabel.AddThemeFontSizeOverride("font_size", 14);
            ui.PowerLabel.AnchorLeft = 0f; ui.PowerLabel.AnchorTop = 1f; ui.PowerLabel.AnchorRight = 1f; ui.PowerLabel.AnchorBottom = 1f;
            ui.PowerLabel.OffsetLeft = 0f; ui.PowerLabel.OffsetTop = -20f; ui.PowerLabel.OffsetRight = 0f; ui.PowerLabel.OffsetBottom = 0f;
            ui.PowerLabel.MouseFilter = Control.MouseFilterEnum.Ignore;
            
            if (!string.IsNullOrEmpty(_uiBg))
            {
                ui.PowerLabel.AddThemeColorOverride("font_outline_color", new Color(0, 0, 0, 1));
                ui.PowerLabel.AddThemeConstantOverride("outline_size", 3);
            }
            ui.Root.AddChild(ui.PowerLabel);

            grid.AddChild(ui.Root);
            _slotUIs[i] = ui;
        }

        globalUi.AddChild(_topBar);
        _topBar.TreeExiting += OnTopBarExiting;
        RefreshTopBar();
    }

    private static void ClearSlot(int index)
    {
        try
        {
            if (index >= 0 && index < _slots.Count)
            {
                SlotEntry old = _slots[index];
                _slots.RemoveAt(index);
                ApplyPower(old, -1);
                RefreshTopBar();
                Log.Info($"SlotCardRecorder: 右键手动清空了第 {index+1} 个槽位。");
            }
        }
        catch (Exception e) { Log.Error("SlotCardRecorder: 清空槽位失败 - " + e.Message); }
    }

    private static void OnTopBarGuiInput(InputEvent @event)
    {
        if (@event is InputEventMouseButton mb)
        {
            if (mb.ButtonIndex == MouseButton.Left)
            {
                if (mb.Pressed)
                {
                    _isDragging = true;
                    _dragStartPos = _topBar.Position;
                    _dragStartMousePos = mb.GlobalPosition;
                }
                else
                {
                    _isDragging = false;
                    if (_savePos)
                    {
                        try
                        {
                            string configPath = "user://slot_recorder_pos.cfg";
                            var cfg = new ConfigFile();
                            cfg.SetValue("pos", "x", _topBar.Position.X);
                            cfg.SetValue("pos", "y", _topBar.Position.Y);
                            cfg.Save(configPath);
                        }
                        catch { }
                    }
                }
            }
        }
        else if (@event is InputEventMouseMotion mm && _isDragging)
        {
            Vector2 delta = mm.GlobalPosition - _dragStartMousePos;
            _topBar.Position = _dragStartPos + delta;
        }
    }

    private static void OnTogglePressed()
    {
        try
        {
            _isOpen = !_isOpen;
            Tween tw = _topBar.CreateTween();
            if (_isOpen)
            {
                _toggleBtn.Text = "▲";
                tw.TweenProperty(_panelContainer, "position:y", 0f, 0.25f).SetTrans(Tween.TransitionType.Cubic).SetEase(Tween.EaseType.Out);
            }
            else
            {
                _toggleBtn.Text = "▼";
                tw.TweenProperty(_panelContainer, "position:y", -(_uiHeight + 20f), 0.25f).SetTrans(Tween.TransitionType.Cubic).SetEase(Tween.EaseType.Out);
            }
        }
        catch (Exception e) { Log.Error("SlotCardRecorder: 切换展开失败 - " + e.Message); }
    }

    private static void RefreshTopBar()
    {
        try
        {
            CleanupPooledCards();

            for (int i = 0; i < _slotCount; i++)
            {
                SlotUI ui = _slotUIs[i];
                if (ui == null || !GodotObject.IsInstanceValid(ui.Root)) continue;

                foreach (Node child in ui.CardHolder.GetChildren())
                {
                    child.QueueFree();
                }

                if (i < _slots.Count)
                {
                    SlotEntry e = _slots[i];
                    
                    string text = string.IsNullOrEmpty(e.PowerClass) ? "无状态" : $"{e.PowerClass} (+{e.Stacks})";
                    if (e.IsUpgraded) text += " (已升级)";
                    ui.PowerLabel.Text = text;

                    bool imageLoaded = false;

                    if (!string.IsNullOrEmpty(e.UiImage))
                    {
                        try
                        {
                            string path = e.UiImage.Replace("assets/", "res://plugin_assets/SlotCardRecorder/");
                            if (!path.StartsWith("res://")) path = "res://" + path;

                            Texture2D tex = GD.Load<Texture2D>(path);
                            if (tex != null)
                            {
                                TextureRect img = new TextureRect();
                                img.Texture = tex;
                                img.ExpandMode = TextureRect.ExpandModeEnum.IgnoreSize;
                                img.StretchMode = TextureRect.StretchModeEnum.KeepAspectCentered;
                                img.CustomMinimumSize = new Vector2(_cardSize, _cardSize);
                                img.Position = new Vector2(-_cardSize / 2f, 0f);
                                img.MouseFilter = Control.MouseFilterEnum.Ignore;
                                ui.CardHolder.AddChild(img);
                                imageLoaded = true;
                            }
                        }
                        catch { }
                    }

                    if (!imageLoaded && e.Model != null)
                    {
                        NCard ncard = NCard.Create(e.Model);
                        if (ncard != null)
                        {
                            float scale = _cardSize / 300f;
                            ncard.Scale = new Vector2(scale, scale);
                            ncard.Position = new Vector2(0f, 63f * scale); 
                            try { ncard.UpdateVisuals(PileType.Deck, CardPreviewMode.Normal); } catch { }
                            ncard.MouseFilter = Control.MouseFilterEnum.Ignore;
                            _pooledCards.Add(ncard);
                            ui.CardHolder.AddChild(ncard);
                        }
                    }

                    if (_showHover && ui.Root != null)
                    {
                        try
                        {
                            var tips = new List<IHoverTip>();
                            var pm = GetPowerModel(e.PowerClass);
                            if (pm != null) tips.AddRange(pm.HoverTips);
                            if (e.Model != null) tips.AddRange(e.Model.HoverTips);
                            
                            if (tips.Count > 0)
                                NHoverTipSet.CreateAndShow(ui.Root, tips);
                        }
                        catch { }
                    }
                }
                else
                {
                    ui.PowerLabel.Text = "—";
                }
            }
        }
        catch (Exception ex)
        {
            Log.Error("SlotCardRecorder: 刷新UI失败 - " + ex.Message);
        }
    }

    private static PowerModel GetPowerModel(string name)
    {
        try
        {
            Type pt = ResolveType(name);
            if (pt == null) return null;
            MethodInfo modelDbPower = typeof(ModelDb).GetMethod("Power", Type.EmptyTypes);
            if (modelDbPower == null) return null;
            MethodInfo closed = modelDbPower.MakeGenericMethod(pt);
            return closed.Invoke(null, null) as PowerModel;
        }
        catch { return null; }
    }

    private static void CleanupPooledCards()
    {
        for (int i = 0; i < _pooledCards.Count; i++)
        {
            NCard card = _pooledCards[i];
            try
            {
                if (card != null && GodotObject.IsInstanceValid(card))
                {
                    NodePool.Free(card);
                    Node parent = card.GetParent();
                    if (parent != null) parent.RemoveChild(card);
                }
            }
            catch { }
        }
        _pooledCards.Clear();
    }

    private static void ReloadConfig()
    {
        _pairs.Clear();
        try
        {
            Type t = ResolveType("SlotRecorderConfig");
            if (t == null) return;

            _scope = t.GetField("Scope")?.GetValue(null) as string ?? "本场战斗";
            _uiBg = t.GetField("UiBg")?.GetValue(null) as string ?? "";
            _uiBorderColor = t.GetField("UiBorderColor")?.GetValue(null) as string ?? "#000000";
            _uiBorderImage = t.GetField("UiBorderImage")?.GetValue(null) as string ?? "";
            _slotBorderColor = t.GetField("BorderColor")?.GetValue(null) as string ?? "#FFFFFF";
            
            _slotCount = Convert.ToInt32(t.GetField("SlotCount")?.GetValue(null) ?? 3);
            if (_slotCount < 1) _slotCount = 1;

            var fW = t.GetField("UiWidth")?.GetValue(null);
            if (fW != null) _uiWidth = Convert.ToSingle(fW);

            var fH = t.GetField("UiHeight")?.GetValue(null);
            if (fH != null) _uiHeight = Convert.ToSingle(fH);

            var fT = t.GetField("UiTopOffset")?.GetValue(null);
            if (fT != null) _uiTopOffset = Convert.ToSingle(fT);

            var fS = t.GetField("CardSize")?.GetValue(null);
            if (fS != null) _cardSize = Convert.ToSingle(fS);

            var bDrag = t.GetField("AllowDrag")?.GetValue(null);
            if (bDrag is bool bd) _allowDrag = bd;

            var bPos = t.GetField("SavePos")?.GetValue(null);
            if (bPos is bool bp) _savePos = bp;

            var bHover = t.GetField("ShowHover")?.GetValue(null);
            if (bHover is bool bh) _showHover = bh;

            string[][] pairs = t.GetField("Pairs")?.GetValue(null) as string[][];
            if (pairs != null)
            {
                foreach (string[] row in pairs)
                {
                    if (row == null || row.Length < 2) continue;
                    string card = row[0] ?? "";
                    if (string.IsNullOrEmpty(card)) continue;
                    
                    int stacks = 1;
                    if (row.Length >= 3) int.TryParse(row[2], out stacks);
                    if (stacks <= 0) stacks = 1;
                    
                    string uiImage = "";
                    if (row.Length >= 4) uiImage = row[3] ?? "";

                    _pairs[card] = new string[] { row[1] ?? "", stacks.ToString(), uiImage };
                }
            }
        }
        catch (Exception e)
        {
            Log.Error("SlotCardRecorder: 读取配置失败 - " + e.GetType().Name + ": " + e.Message);
        }
    }

    public static void OnCardPlayed(CardPlay cardPlay)
    {
        try
        {
            if (cardPlay == null || !cardPlay.IsFirstInSeries) return;
            CardModel card = cardPlay.Card;
            if (card == null) return;

            string cls = card.GetType().Name;
            string full = card.GetType().FullName ?? "";

            bool inTable = _pairs.ContainsKey(cls) || _pairs.ContainsKey(full);
            if (!inTable) return;

            SlotEntry entry = new SlotEntry
            {
                CardClass = cls,
                CardTitle = SafeTitle(card),
                Model = card,
                IsUpgraded = card.IsUpgraded
            };

            string[] pair;
            if (_pairs.TryGetValue(cls, out pair) || _pairs.TryGetValue(full, out pair))
            {
                entry.PowerClass = pair[0] ?? "";
                int st;
                entry.Stacks = int.TryParse(pair[1], out st) && st > 0 ? st : 1;
                if (pair.Length >= 3) entry.UiImage = pair[2] ?? "";
            }

            while (_slots.Count >= _slotCount)
            {
                SlotEntry old = _slots[0];
                _slots.RemoveAt(0);
                ApplyPower(old, -1);
                if (_topBar != null && GodotObject.IsInstanceValid(_topBar))
                {
                    var flash = _topBar.CreateTween();
                    flash.TweenProperty(_topBar, "modulate", new Color(1, 0.5f, 0.5f), 0.1f);
                    flash.TweenProperty(_topBar, "modulate", new Color(1, 1, 1), 0.1f);
                }
            }
            _slots.Add(entry);
            ApplyPower(entry, +1);
            RefreshTopBar();
        }
        catch (Exception e)
        {
            Log.Error("SlotCardRecorder: 记录出牌失败 - " + e.GetType().Name + ": " + e.Message);
        }
    }

    public static void OnCombatEnd()
    {
        try
        {
            if (_scope != null && _scope.Contains("整局")) return;
            ClearAll();
        }
        catch (Exception e)
        {
            Log.Error("SlotCardRecorder: 战斗结束清理失败 - " + e.GetType().Name + ": " + e.Message);
        }
    }

    private static void ClearAll()
    {
        for (int i = 0; i < _slots.Count; i++) ApplyPower(_slots[i], -1);
        _slots.Clear();
        RefreshTopBar();
    }

    private static void ApplyPower(SlotEntry e, int sign)
    {
        try
        {
            if (e == null || string.IsNullOrEmpty(e.PowerClass)) return;
            Type pt = ResolveType(e.PowerClass);
            if (pt == null) { Log.Error("SlotCardRecorder: 找不到状态类 " + e.PowerClass); return; }

            Player player = GetLocalPlayer();
            if (player == null) return;
            Creature target = player.Creature;
            if (target == null) return;

            decimal amount = (decimal)(e.Stacks * sign);
            _ = ApplyPowerAsync(pt, target, amount);
        }
        catch (Exception ex)
        {
            Log.Error("SlotCardRecorder: 应用状态失败 - " + ex.GetType().Name + ": " + ex.Message);
        }
    }

    private static async Task ApplyPowerAsync(Type powerType, Creature target, decimal amount)
    {
        try
        {
            MethodInfo modelDbPower = typeof(ModelDb).GetMethod("Power", Type.EmptyTypes);
            if (modelDbPower == null) return;
            MethodInfo closed = modelDbPower.MakeGenericMethod(powerType);
            PowerModel canonical = closed.Invoke(null, null) as PowerModel;
            if (canonical == null) return;

            PowerModel mutable = canonical.ToMutable();
            if (mutable == null) return;

            MethodInfo apply = typeof(PowerCmd).GetMethod("Apply", new[]
            {
                typeof(PlayerChoiceContext), typeof(PowerModel), typeof(Creature),
                typeof(decimal), typeof(Creature), typeof(CardModel), typeof(bool)
            });
            if (apply == null) return;

            object result = apply.Invoke(null, new object[]
            {
                new ThrowingPlayerChoiceContext(), mutable, target, amount,
                target, null, false
            });
            if (result is Task t) await t;
        }
        catch (Exception ex)
        {
            Log.Error("SlotCardRecorder: 异步应用状态失败 - " + ex.GetType().Name + ": " + ex.Message);
        }
    }

    private static Player GetLocalPlayer()
    {
        try
        {
            NCombatRoom room = NCombatRoom.Instance;
            if (room == null) return null;
            CombatManager cm = CombatManager.Instance;
            if (cm == null || !cm.IsInProgress) return null;
            foreach (NCreature node in room.CreatureNodes)
            {
                if (node == null || !GodotObject.IsInstanceValid(node)) continue;
                Creature entity = node.Entity;
                if (entity == null) continue;
                ICombatState cs = entity.CombatState;
                if (cs == null) continue;
                Player p = LocalContext.GetMe(cs);
                if (p != null) return p;
            }
        }
        catch { }
        return null;
    }

    private static string SafeTitle(CardModel c)
    {
        try { return c.Title ?? ""; } catch { return ""; }
    }

    private static Type ResolveType(string name)
    {
        if (string.IsNullOrEmpty(name)) return null;
        try
        {
            Type hit;
            if (_typeCache.TryGetValue(name, out hit)) return hit;
            Assembly asm = typeof(SlotCardRecorder).Assembly;
            hit = asm.GetType(name, false);
            if (hit == null)
            {
                Type[] all;
                try { all = asm.GetTypes(); }
                catch (ReflectionTypeLoadException ex) { all = ex.Types; }
                foreach (Type ct in all)
                {
                    if (ct == null || ct.Name != name) continue;
                    if (typeof(CardModel).IsAssignableFrom(ct)) { hit = ct; break; }
                    if (hit == null) hit = ct;
                }
            }
            _typeCache[name] = hit;
            return hit;
        }
        catch { return null; }
    }
}