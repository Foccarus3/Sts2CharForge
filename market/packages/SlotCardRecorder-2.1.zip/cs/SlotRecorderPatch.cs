// 「记录面板」安装补丁
using MegaCrit.Sts2.Core.Combat;
using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.GameActions.Multiplayer;
using MegaCrit.Sts2.Core.Hooks;
using MegaCrit.Sts2.Core.Nodes.CommonUi;
using MegaCrit.Sts2.Core.Rooms;
using MegaCrit.Sts2.Core.Runs;

[HarmonyLib.HarmonyPatch(typeof(NGlobalUi), "_Ready")]
public static class SlotRecorderInstallPatch
{
    static void Postfix(NGlobalUi __instance) => SlotCardRecorder.TryInstall(__instance);
}

[HarmonyLib.HarmonyPatch(typeof(Hook), nameof(Hook.AfterCardPlayed))]
public static class SlotRecorderCardPlayedPatch
{
    static void Postfix(ICombatState combatState, PlayerChoiceContext choiceContext, CardPlay cardPlay) => SlotCardRecorder.OnCardPlayed(cardPlay);
}

[HarmonyLib.HarmonyPatch(typeof(Hook), nameof(Hook.AfterCombatEnd))]
public static class SlotRecorderCombatEndPatch
{
    static void Postfix(IRunState runState, ICombatState combatState, CombatRoom room) => SlotCardRecorder.OnCombatEnd();
}