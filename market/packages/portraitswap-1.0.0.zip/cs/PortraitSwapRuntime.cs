// ============================================================================
//  插件 portraitswap（立绘切换）· 运行时
//
//  做什么：
//    本地玩家打出「立绘切换配置」页里配过的牌 → 在角色 Visuals 下盖一个 Sprite2D
//    （名字 __portraitswap_body），把本体那些子节点临时藏起来 → 战斗立绘换成另一张图。
//    什么时候换可配：立即 / 打出后 N 秒 / chargb 的 GIF 播完后 / GIF 播完再加 N 秒。
//    换完可保持到战斗结束，或延迟若干秒自动切回。
//
//  与 chargb（更多动画）的关系：零编译依赖 —— 只读它的 cards.json、只观察它的
//    __charbg_body 节点是否还在播。chargb 被禁用/删除时本插件照常编译、照常工作。
//
//  ⚠ 铁律（全部来自 chargb 已验证的踩坑注释，违反任何一条都会炸）：
//    1) 本文件**不是** Godot 节点子类：只 new 普通 Sprite2D，逻辑在静态类里；
//       写成 partial : Node2D 会被 Godot 源生成器 + ModEntry 双重登记 → 模组初始化失败。
//    2) 不补 NCardPlayQueue.OnLocalCardPlayed；挂 CardModel.OnPlayWrapper 的 Prefix，只读不写。
//    3) 出牌流程里不同步干活：Callable.From(...).CallDeferred()，方法体全 try/catch。
//    4) 不把 Visuals 整个设成不可见（出牌演出会等角色节点 → 牌挂在屏幕中间），只藏子节点。
//    5) 不在信号回调里直接 QueueFree 正在发信号的节点：先置空引用，再 CallDeferred。
//    6) 新节点挂 Visuals 下，不挂 NCreature 直接子节点。
//    7) 底边对齐脚底（否则立绘沉进地里或悬空）。
//    8) [HarmonyPatch] 写在类上。
//    9) Prefix 恒返回 true（观察型补丁，不拦本体）。
//
//  ⚠ 打包规则实测（编辑器 V0.3.74）：assetFiles 里**逐条列出**的文件才会被拷进
//    plugin_assets/<插件 id>/，并且会**拍平到根目录**（assets/portraits/x.png →
//    plugin_assets/portraitswap/x.png）。列目录 / 写通配符都不会复制任何文件。
//    所以下面的 LoadTexture 会按「拍平后的路径 → 原层级路径」依次试。
// ============================================================================
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using Godot;
using HarmonyLib;
using MegaCrit.Sts2.Core.Context;
using MegaCrit.Sts2.Core.Hooks;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Nodes.Combat;

namespace Plugins.PortraitSwap;

/// <summary>一条映射：哪张牌 → 换哪张图、什么时候换、怎么对齐。</summary>
public readonly struct SwapRow
{
    public const string ModeImmediate = "立即";
    public const string ModeDelay = "延迟N秒";
    public const string ModeAfterGif = "GIF播完后";
    public const string ModeAfterGifPlus = "GIF播完后加N秒";

    public readonly string Card;
    public readonly string Portrait;
    public readonly string Mode;
    public readonly float Delay;
    public readonly float X;
    public readonly float Y;
    public readonly float Scale;

    public SwapRow(string card, string portrait, string mode, float delay, float x, float y, float scale)
    {
        Card = card ?? "";
        Portrait = portrait ?? "";
        Mode = string.IsNullOrWhiteSpace(mode) ? ModeImmediate : mode.Trim();
        Delay = delay;
        X = x;
        Y = y;
        Scale = scale <= 0.001f ? 1f : scale;
    }

    public bool IsValid => Card.Length > 0 && Portrait.Length > 0;
}

public static class PortraitSwapRuntime
{
    private const string Tag = "[portraitswap] ";
    private const string OverlayName = "__portraitswap_body";
    private const string ResRoot = "res://plugin_assets/portraitswap/";
    private const string ChargbRoot = "res://plugin_assets/chargb/";
    private const string ChargbNodeName = "__charbg_body";

    /// <summary>轮询间隔：GIF 状态、防漏出守卫都用它。0.1~0.2 秒（chargb 同款）。</summary>
    private const float PollInterval = 0.15f;

    // ---------------------------------------------------------------- 配置

    private static bool _cfgTried;
    private static bool _cfgFound;
    private static bool _enabled = true;
    private static bool _debug;
    private static float _gifWindow = 0.8f;
    private static float _gifTimeout = 10f;
    private static string _revertMode = "保持到战斗结束";
    private static float _revertDelay = 3f;
    private static readonly List<SwapRow> Rows = new();
    private static readonly Dictionary<string, SwapRow> RowByCard = new(StringComparer.OrdinalIgnoreCase);

    // ---------------------------------------------------------------- 状态

    private static NCreature _playerNode;
    private static NCreatureVisuals _visuals;
    private static Sprite2D _overlay;
    private static readonly List<CanvasItem> HiddenByUs = new();
    private static bool _applied;
    private static string _currentPortrait = "";
    /// <summary>请求代号：新请求 / 战斗结束 / 新角色节点都会 ++，旧计时器看到代号变了就自己退出。</summary>
    private static int _gen;

    private static readonly Dictionary<string, Texture2D> TextureCache = new(StringComparer.Ordinal);

    // ---------------------------------------------------------------- chargb 观察状态

    private static bool _chargbTried;
    private static bool _chargbOk;
    private static bool _chargbEnabled = true;
    private static string _chargbDefault = "";
    private static readonly Dictionary<string, string> ChargbCards = new(StringComparer.OrdinalIgnoreCase);
    private static readonly HashSet<string> ChargbDisabledAnims = new(StringComparer.OrdinalIgnoreCase);
    private static readonly Dictionary<string, bool> ChargbAnimUsable = new(StringComparer.OrdinalIgnoreCase);

    // ================================================================ 日志

    private static void Log(string msg)
    {
        if (!_debug) return;
        GD.Print(Tag + msg);
    }

    private static void Warn(string msg) => GD.PushWarning(Tag + msg);

    private static bool IsValid(GodotObject o) => o is not null && GodotObject.IsInstanceValid(o);

    // ================================================================ 配置读取
    //
    // 页面生成的 PortraitSwapConfig 到底是全局命名空间还是 Sts2CharForge.Generated.Plugin_portraitswap，
    // 不同编辑器版本都出现过 —— 所以这里按名字反射找类型（记录面板插件同款做法），
    // 不写编译期引用，就不会因为命名空间挪了位置而 CS0246。

    private static void EnsureConfig()
    {
        if (_cfgTried) return;
        _cfgTried = true;
        try
        {
            Type t = FindType("PortraitSwapConfig");
            if (t is null)
            {
                _cfgFound = false;
                _enabled = false;
                Warn("没找到配置类 PortraitSwapConfig —— 请先在「立绘切换配置」页填好并「生成工程」。本插件本次不生效。");
                return;
            }
            _cfgFound = true;

            _enabled = ReadBool(t, "Enabled", true);
            _debug = ReadBool(t, "DebugLog", false);
            _gifWindow = Mathf.Max(0f, ReadFloat(t, "GifStartWindow", 0.8f));
            _gifTimeout = Mathf.Max(0.2f, ReadFloat(t, "GifTimeout", 10f));
            _revertMode = ReadString(t, "RevertMode", "保持到战斗结束");
            _revertDelay = Mathf.Max(0f, ReadFloat(t, "RevertDelay", 3f));

            Rows.Clear();
            RowByCard.Clear();
            if (ReadField(t, "Rows") is string[][] rows)
            {
                for (int i = 0; i < rows.Length; i++)
                {
                    string[] r = rows[i];
                    if (r is null || r.Length < 7) continue;
                    var row = new SwapRow(r[0], r[1], r[2],
                        ParseFloat(r[3], 0.5f), ParseFloat(r[4], 0f), ParseFloat(r[5], 0f), ParseFloat(r[6], 1f));
                    if (!row.IsValid)
                    {
                        Log($"第 {i + 1} 行没填完（卡牌「{row.Card}」/图「{row.Portrait}」），跳过");
                        continue;
                    }
                    Rows.Add(row);
                    if (!RowByCard.ContainsKey(row.Card)) RowByCard[row.Card] = row;
                }
            }

            Log($"配置：启用={_enabled}，映射 {Rows.Count} 行，GIF 起播窗={_gifWindow:0.##}s，"
                + $"GIF 超时={_gifTimeout:0.##}s，切回={_revertMode}（{_revertDelay:0.##}s），调试日志={_debug}");
        }
        catch (Exception e)
        {
            _cfgFound = false;
            _enabled = false;
            Warn("读配置出错（本插件本次不生效）：" + e.Message);
        }
    }

    private static Type FindType(string shortName)
    {
        try
        {
            Type t = typeof(PortraitSwapRuntime).Assembly.GetType(shortName, throwOnError: false);
            if (t is not null) return t;
            t = typeof(PortraitSwapRuntime).Assembly.GetType(
                "Sts2CharForge.Generated.Plugin_portraitswap." + shortName, throwOnError: false);
            if (t is not null) return t;
            foreach (Assembly asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                t = asm.GetType(shortName, throwOnError: false)
                    ?? asm.GetType("Sts2CharForge.Generated.Plugin_portraitswap." + shortName, throwOnError: false);
                if (t is not null) return t;
            }
        }
        catch { }
        return null;
    }

    private static object ReadField(Type t, string name)
        => t.GetField(name, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static)?.GetValue(null);

    private static bool ReadBool(Type t, string name, bool fallback)
    {
        try
        {
            object v = ReadField(t, name);
            if (v is bool b) return b;
            if (v is int i) return i != 0;
            return fallback;
        }
        catch { return fallback; }
    }

    private static float ReadFloat(Type t, string name, float fallback)
    {
        try
        {
            object v = ReadField(t, name);
            if (v is float f) return f;
            if (v is double d) return (float)d;
            if (v is int i) return i;
            if (v is decimal m) return (float)m;
            if (v is string s) return ParseFloat(s, fallback);
            return fallback;
        }
        catch { return fallback; }
    }

    private static string ReadString(Type t, string name, string fallback)
    {
        try
        {
            string s = ReadField(t, name) as string;
            return s ?? fallback;
        }
        catch { return fallback; }
    }

    private static float ParseFloat(string s, float fallback)
    {
        if (string.IsNullOrWhiteSpace(s)) return fallback;
        return float.TryParse(s.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out float v) ? v : fallback;
    }

    // ================================================================ 挂载 / 清理

    /// <summary>NCreature._Ready 的 Postfix：只认本地玩家的角色节点，并清掉上一场的残留。</summary>
    public static void TryAttach(NCreature node)
    {
        try
        {
            if (node is null || !IsValid(node)) return;
            if (node.Entity is null || !node.Entity.IsPlayer) return;
            if (LocalContext.NetId.HasValue && !LocalContext.IsMe(node.Entity)) return;

            EnsureConfig();

            // 新一场战斗 / 换了角色节点：旧引用、旧计时器全部作废
            ResetAll("新的玩家角色节点就绪");

            _playerNode = node;
            try { _visuals = node.Visuals; } catch { _visuals = null; }

            Log($"玩家角色就绪：{node.Name}，Visuals={(_visuals is null ? "null" : _visuals.GetType().Name)}"
                + $"，可见={_visuals?.Visible}");
            if (!_enabled) Log("总开关是关的：打牌时不做任何替换");
        }
        catch (Exception e)
        {
            Warn("记录玩家角色失败：" + e.Message);
        }
    }

    /// <summary>清掉一切运行时状态：待执行的计时器作废、覆盖节点销毁、本体恢复可见。</summary>
    public static void ResetAll(string reason)
    {
        _gen++;
        try
        {
            if (IsValid(_overlay))
            {
                var dead = _overlay;
                _overlay = null;
                try { dead.Visible = false; } catch { }
                // 先置空引用再延迟销毁（不在信号回调里释放正在发信号的节点）
                try { dead.CallDeferred(Node.MethodName.QueueFree); } catch { }
            }
            _overlay = null;
        }
        catch { }
        RestoreHidden();
        _applied = false;
        _currentPortrait = "";
        Log($"清理：{reason}");
    }

    private static void RestoreHidden()
    {
        foreach (CanvasItem ci in HiddenByUs)
        {
            try
            {
                if (IsValid(ci)) ci.Visible = true;
            }
            catch { }
        }
        HiddenByUs.Clear();
    }

    // ================================================================ 出牌入口

    /// <summary>CardModel.OnPlayWrapper 的 Prefix 调它（已经在 CallDeferred 里了）。</summary>
    public static void OnCardPlayed(CardModel card)
    {
        try
        {
            OnCardPlayedCore(card);
        }
        catch (Exception e)
        {
            Warn("处理出牌时出错（已忽略，不影响出牌）：" + e.Message);
        }
    }

    private static void OnCardPlayedCore(CardModel card)
    {
        if (card is null) return;
        EnsureConfig();
        if (!_cfgFound || !_enabled) return;
        if (Rows.Count == 0) return;

        // OnPlayWrapper 对敌我双方的牌都会触发：只认本地玩家自己的
        try
        {
            if (card.Owner?.Creature is null || !card.Owner.Creature.IsPlayer) return;
            if (LocalContext.NetId.HasValue && !LocalContext.IsMe(card.Owner)) return;
        }
        catch { return; }

        if (!IsValid(_playerNode) || !IsValid(_visuals)) return;

        SwapRow? found = ResolveRow(card);
        if (found is null)
        {
            Log($"打出 {card.GetType().Name}：不在映射表里，零影响");
            return;
        }

        SwapRow r = found.Value;
        Log($"打出 {card.GetType().Name} → 目标立绘「{r.Portrait}」，等待模式「{r.Mode}」（N={r.Delay:0.##}s）");
        Request(r, card);
    }

    /// <summary>效果种类（PortraitSwapNow / PortraitSwapDelayed）的入口：立刻返回，全部工作推迟一帧。</summary>
    public static void TriggerFromEffect(object card, float delaySeconds)
    {
        try
        {
            var model = card as CardModel;
            if (model is null) return;
            Callable.From(() =>
            {
                try
                {
                    EnsureConfig();
                    if (!_enabled) return;
                    SwapRow? found = ResolveRow(model);
                    if (found is null)
                    {
                        Log($"效果触发 {model.GetType().Name}：映射表里没有这张牌，什么都不做");
                        return;
                    }
                    SwapRow r = found.Value;
                    Log($"效果触发 {model.GetType().Name} → 「{r.Portrait}」，延迟 {delaySeconds:0.##}s");
                    // 效果链只控制时机：0 = 立即，>0 = 延迟 N 秒
                    Request(new SwapRow(r.Card, r.Portrait,
                        delaySeconds > 0.001f ? SwapRow.ModeDelay : SwapRow.ModeImmediate,
                        delaySeconds, r.X, r.Y, r.Scale), model);
                }
                catch (Exception e) { Warn("效果触发失败（已忽略）：" + e.Message); }
            }).CallDeferred();
        }
        catch (Exception e)
        {
            Warn("效果触发调度失败（已忽略）：" + e.Message);
        }
    }

    private static SwapRow? ResolveRow(CardModel card)
    {
        // 卡牌常被生成 XxxCopy2 之类的子类 —— 按继承链逐级上溯匹配
        for (Type t = card.GetType(); t is not null && t != typeof(object); t = t.BaseType)
        {
            if (RowByCard.TryGetValue(t.Name, out SwapRow row)) return row;
        }
        return null;
    }

    // ================================================================ 等待模式

    private static void Request(SwapRow row, CardModel card)
    {
        // 后到覆盖先到：作废一切未完成的等待/回切
        _gen++;
        int gen = _gen;

        switch (row.Mode)
        {
            case SwapRow.ModeImmediate:
                Apply(row, gen, "立即");
                return;
            case SwapRow.ModeDelay:
                if (row.Delay <= 0.001f) { Apply(row, gen, "延迟 0 秒 = 立即"); return; }
                Log($"等 {row.Delay:0.##}s 再切");
                After(row.Delay, () => Apply(row, gen, "延迟到点"));
                return;
            case SwapRow.ModeAfterGif:
                PollGifStart(row, card, gen, 0f, 0f);
                return;
            case SwapRow.ModeAfterGifPlus:
                PollGifStart(row, card, gen, Mathf.Max(0f, row.Delay), 0f);
                return;
            default:
                Log($"不认识的等待模式「{row.Mode}」，按立即处理");
                Apply(row, gen, "未知模式");
                return;
        }
    }

    /// <summary>起播窗：先等 chargb 把 __charbg_body 亮出来；没有 GIF 就直接切，不傻等。</summary>
    private static void PollGifStart(SwapRow row, CardModel card, int gen, float extra, float elapsed)
    {
        if (gen != _gen) return;
        if (!IsValid(_visuals)) { ResetAll("等待期间角色节点没了"); return; }

        if (ChargbPlaying())
        {
            Log("看到 chargb 的动图在播，等它播完");
            WaitGifEnd(row, gen, extra, elapsed);
            return;
        }

        if (elapsed >= _gifTimeout)
        {
            Log($"等 GIF 超时（{_gifTimeout:0.##}s），强制切换");
            Apply(row, gen, "GIF 超时");
            return;
        }

        if (elapsed >= _gifWindow)
        {
            if (!ChargbWillPlay(card))
            {
                if (extra > 0.001f)
                {
                    Log($"这张牌没有 GIF（或 chargb 没启用）：起播窗到点，再等 {extra:0.##}s 后切换");
                    After(extra, () => Apply(row, gen, "无 GIF：窗口+延迟"));
                }
                else
                {
                    Log("这张牌没有 GIF（或 chargb 没启用）：起播窗到点直接切换");
                    Apply(row, gen, "无 GIF：窗口到点");
                }
                return;
            }
            // 配置说有动画，只是还没开始播 —— 继续等到超时
        }

        After(PollInterval, () => PollGifStart(row, card, gen, extra, elapsed + PollInterval));
    }

    /// <summary>等动图播完：节点不可见 / 已释放 / 不存在 = 播完。</summary>
    private static void WaitGifEnd(SwapRow row, int gen, float extra, float elapsed)
    {
        if (gen != _gen) return;
        if (!IsValid(_visuals)) { ResetAll("等待期间角色节点没了"); return; }

        if (elapsed >= _gifTimeout)
        {
            Log($"等 GIF 超时（{_gifTimeout:0.##}s），强制切换");
            Apply(row, gen, "GIF 超时");
            return;
        }

        if (!ChargbPlaying())
        {
            if (extra > 0.001f)
            {
                Log($"动图播完，再等 {extra:0.##}s");
                After(extra, () => Apply(row, gen, "GIF 播完 + 延迟"));
            }
            else
            {
                Apply(row, gen, "GIF 播完");
            }
            return;
        }

        After(PollInterval, () => WaitGifEnd(row, gen, extra, elapsed + PollInterval));
    }

    private static void After(float seconds, Action action)
    {
        try
        {
            Node host = IsValid(_visuals) ? (Node)_visuals : (IsValid(_playerNode) ? _playerNode : null);
            SceneTree tree = host?.GetTree();
            if (tree is null) return;
            if (seconds <= 0.001f) { action(); return; }
            // SceneTree.CreateTimer 受游戏暂停 / 时间缩放正确影响；不用 Task.Delay / Thread.Sleep
            SceneTreeTimer timer = tree.CreateTimer(seconds);
            timer.Timeout += () =>
            {
                try { action(); }
                catch (Exception e) { Warn("计时器回调出错（已忽略）：" + e.Message); }
            };
        }
        catch (Exception e)
        {
            Warn("排计时器失败（已忽略）：" + e.Message);
        }
    }

    // ================================================================ 切换 / 切回

    private static void Apply(SwapRow row, int gen, string why)
    {
        if (gen != _gen) { Log($"[{why}] 已被更新的请求取代，放弃"); return; }
        if (!_enabled) return;
        if (!IsValid(_playerNode) || !IsValid(_visuals)) { Log($"[{why}] 角色节点已失效，放弃"); return; }
        if (_applied && string.Equals(_currentPortrait, row.Portrait, StringComparison.Ordinal))
        {
            Log($"[{why}] 当前已经显示「{row.Portrait}」，跳过重复切换");
            return;
        }

        Texture2D tex = LoadTexture(row.Portrait);
        if (tex is null)
        {
            // 失败兜底：记一条日志，什么都不动（原立绘保持），绝不让异常窜进出牌流程
            Warn($"[{why}] 立绘图加载失败：{row.Portrait}（试过：{string.Join(" | ", CandidatePaths(row.Portrait))}）"
                + "　检查：文件在 plugins\\portraitswap\\assets\\portraits\\ 吗？文件名列进 plugin.json 的 assetFiles 了吗？"
                + "生成工程 + 构建过了吗？");
            return;
        }

        Sprite2D sprite = EnsureOverlay();
        if (sprite is null) { Warn($"[{why}] 覆盖节点没建起来，保持原立绘"); return; }

        AlignOverlay(sprite, tex, row);
        sprite.Visible = true;
        sprite.Modulate = Colors.White;
        HideOthers(sprite);

        _overlay = sprite;
        _applied = true;
        _currentPortrait = row.Portrait;

        Log($"[{why}] 已切换立绘 →「{row.Portrait}」：位置={sprite.Position}，缩放={sprite.Scale}，"
            + $"藏起本体子节点 {HiddenByUs.Count} 个");

        ArmGuard(gen);
        ScheduleRevert(gen);
    }

    private static Sprite2D EnsureOverlay()
    {
        try
        {
            if (!IsValid(_visuals)) return null;

            if (IsValid(_overlay) && _overlay.GetParent() == (Node)_visuals) return _overlay;

            // 换了角色节点 / 重建：旧覆盖节点挂在旧父节点上 → 丢弃重建（防幽灵立绘）
            if (IsValid(_overlay) && _overlay.GetParent() != (Node)_visuals)
            {
                var stale = _overlay;
                _overlay = null;
                try { stale.Visible = false; } catch { }
                try { stale.CallDeferred(Node.MethodName.QueueFree); } catch { }
            }

            var sprite = new Sprite2D
            {
                Name = OverlayName,
                Centered = true,
                Visible = false,
                // 和立绘同级：别用 chargb 的 300，否则会盖住血条 / 意图层
                ZIndex = 0,
                TextureFilter = CanvasItem.TextureFilterEnum.Linear,
            };
            // 挂 Visuals（Node2D）下，而不是 NCreature 直接子节点：出牌演出会遍历 NCreature 的子节点
            _visuals.AddChild(sprite);
            _overlay = sprite;
            Log($"建好覆盖节点：父={sprite.GetParent()?.Name}");
            return sprite;
        }
        catch (Exception e)
        {
            Warn("创建覆盖节点失败：" + e.Message);
            return null;
        }
    }

    /// <summary>
    /// 对齐：显示高度与原立绘一致、底边同线（脚底），再叠加行内的 X/Y 偏移与缩放。
    /// 之前放 (0,0) 居中 → 下半截沉到地里（chargb 踩过同一个坑）。
    /// </summary>
    private static void AlignOverlay(Sprite2D sprite, Texture2D tex, SwapRow row)
    {
        Vector2 newSize = tex.GetSize();
        if (newSize.Y < 1f) newSize.Y = 1f;
        if (newSize.X < 1f) newSize.X = 1f;

        Sprite2D baseSprite = FindBaseSprite();
        float baseH;
        float centerX;
        float bottomY;
        float xSign = 1f;

        if (baseSprite is not null && IsValid(baseSprite.Texture))
        {
            Vector2 bSize = baseSprite.Texture.GetSize();
            baseH = Mathf.Max(1f, bSize.Y * Mathf.Abs(baseSprite.Scale.Y));
            centerX = baseSprite.Position.X + baseSprite.Offset.X;
            bottomY = baseSprite.Position.Y + baseSprite.Offset.Y + (baseSprite.Centered ? baseH * 0.5f : 0f);
            xSign = baseSprite.Scale.X < 0f ? -1f : 1f;
            Log($"对齐基准：原立绘 {bSize}，显示高 {baseH:0.#}，中心X {centerX:0.#}，底边Y {bottomY:0.#}");
        }
        else
        {
            // 兜底：用 Bounds 的高度当基准，脚底取 0（Visuals 原点 = 脚底）
            baseH = 340f;
            try
            {
                Control bounds = _visuals?.GetNodeOrNull<Control>("%Bounds");
                if (bounds is not null && bounds.Size.Y > 1f) baseH = bounds.Size.Y;
            }
            catch { }
            centerX = 0f;
            bottomY = 0f;
            Log($"找不到原立绘 Sprite2D，用兜底对齐：基准高 {baseH:0.#}，脚底 0");
        }

        float factor = baseH / newSize.Y * Mathf.Max(0.01f, row.Scale);
        float dispH = newSize.Y * factor;

        sprite.Texture = tex;
        sprite.Centered = true;
        sprite.Scale = new Vector2(factor * xSign, factor);
        sprite.Position = new Vector2(centerX + row.X, bottomY - dispH * 0.5f + row.Y);
        sprite.Rotation = 0f;
        sprite.ZIndex = 0;
    }

    private static Sprite2D FindBaseSprite()
    {
        if (!IsValid(_visuals)) return null;
        Sprite2D named = null;
        foreach (Node child in _visuals.GetChildren())
        {
            var s = child as Sprite2D;
            if (s is null) continue;
            if (s.Name == OverlayName) continue;
            if (!IsValid(s.Texture)) continue;
            if (s.Name == "Visuals") return s;   // 场景里那个原始立绘（unique_name_in_owner）
            if (named is null) named = s;
        }
        return named;
    }

    /// <summary>只藏 Visuals 的**子节点**（Visuals 一隐身，出牌演出就等不到角色动画，牌会挂在屏幕中间）。</summary>
    private static void HideOthers(Sprite2D overlay)
    {
        if (!IsValid(_visuals)) return;
        HiddenByUs.Clear();
        foreach (Node child in _visuals.GetChildren())
        {
            if (ReferenceEquals(child, overlay)) continue;
            var ci = child as CanvasItem;
            if (ci is not null && ci.Visible)
            {
                ci.Visible = false;
                HiddenByUs.Add(ci);
            }
        }
    }

    /// <summary>
    /// 守卫：切换生效期间每 0.15s 重新藏一次本体子节点。
    /// 为什么需要：chargb 播完会把「它自己藏过的东西」重新显示出来、形态 VFX / 恐惧模式也会新挂节点，
    /// 不盯着就会出现「新立绘上又叠回原立绘」。
    /// </summary>
    private static void ArmGuard(int gen)
    {
        if (!_applied) return;
        After(PollInterval, () =>
        {
            if (gen != _gen || !_applied) return;
            if (!IsValid(_visuals) || !IsValid(_overlay)) return;
            try
            {
                HideOthers(_overlay);
                if (!_overlay.Visible) _overlay.Visible = true;
            }
            catch { }
            ArmGuard(gen);
        });
    }

    private static void ScheduleRevert(int gen)
    {
        if (_revertMode != "切换后延迟回切") return;
        float d = Mathf.Max(0.05f, _revertDelay);
        Log($"切回模式「{_revertMode}」：{d:0.##}s 后切回原立绘");
        After(d, () => Revert(gen, "延迟回切到点"));
    }

    private static void Revert(int gen, string why)
    {
        if (gen != _gen) return;
        if (!_applied) return;
        try
        {
            if (IsValid(_overlay)) _overlay.Visible = false;
            RestoreHidden();
            _applied = false;
            _currentPortrait = "";
            Log($"已切回原立绘（{why}）");
        }
        catch (Exception e)
        {
            Warn("切回原立绘失败：" + e.Message);
        }
    }

    // ================================================================ 资源
    //
    // 编辑器实测规则：assetFiles 里的文件会被**拍平**进 plugin_assets/<id>/ 根目录。
    // 所以候选路径按「拍平路径优先 → 原层级路径兜底」排列，用户填哪种写法都能命中。

    private static List<string> CandidatePaths(string rel)
    {
        var list = new List<string>();
        if (string.IsNullOrWhiteSpace(rel)) return list;

        string p = rel.Trim().Replace('\\', '/');
        if (p.StartsWith("res://", StringComparison.OrdinalIgnoreCase))
        {
            list.Add(p);
            return list;
        }
        if (p.StartsWith("assets/", StringComparison.OrdinalIgnoreCase)) p = p.Substring("assets/".Length);
        p = p.TrimStart('/');

        list.Add(ResRoot + p);                                     // 原层级（assets/portraits/x.png）
        int slash = p.LastIndexOf('/');
        if (slash >= 0)
        {
            string flat = p.Substring(slash + 1);
            if (flat.Length > 0 && !list.Contains(ResRoot + flat))
                list.Add(ResRoot + flat);                          // 拍平后（plugin_assets/<id>/x.png）
        }
        return list;
    }

    private static Texture2D LoadTexture(string rel)
    {
        foreach (string path in CandidatePaths(rel))
        {
            Texture2D cached;
            if (TextureCache.TryGetValue(path, out cached) && IsValid(cached)) return cached;
            try
            {
                Texture2D res = ResourceLoader.Load<Texture2D>(path);
                if (res is not null) { TextureCache[path] = res; return res; }
                // 兜底：图没进 pck / 导入器没跑过时直接读字节
                byte[] bytes = FileAccess.GetFileAsBytes(path);
                if (bytes is null || bytes.Length == 0) continue;
                var img = new Image();
                if (img.LoadPngFromBuffer(bytes) != Error.Ok) continue;
                ImageTexture tex = ImageTexture.CreateFromImage(img);
                TextureCache[path] = tex;
                return tex;
            }
            catch (Exception e)
            {
                Log($"载入 {path} 失败：{e.Message}");
            }
        }
        return null;
    }

    // ================================================================ chargb（零编译依赖）

    private static bool ChargbPlaying()
    {
        if (!IsValid(_visuals)) return false;
        try
        {
            Node n = _visuals.GetNodeOrNull<Node>(ChargbNodeName);
            if (n is null || !GodotObject.IsInstanceValid(n)) return false;
            var ci = n as CanvasItem;
            return ci is not null && ci.Visible;
        }
        catch { return false; }
    }

    /// <summary>
    /// 这张牌 chargb 会不会播动图：读它的 cards.json（它自己也这么读），
    /// 再对齐它的四条跳过条件（enabled / disabledAnims / 等于 default / 帧数 ≤ 1）。
    /// </summary>
    private static bool ChargbWillPlay(CardModel card)
    {
        EnsureChargb();
        if (!_chargbOk || !_chargbEnabled) return false;

        string key = null;
        for (Type t = card.GetType(); t is not null && t != typeof(object); t = t.BaseType)
        {
            if (ChargbCards.ContainsKey(t.Name)) { key = t.Name; break; }
        }
        if (key is null) return false;

        string anim = ChargbCards[key];
        if (string.IsNullOrWhiteSpace(anim)) return false;
        if (ChargbDisabledAnims.Contains(anim)) return false;
        if (string.Equals(anim, _chargbDefault, StringComparison.OrdinalIgnoreCase)) return false;
        return AnimUsable(anim);
    }

    private static void EnsureChargb()
    {
        if (_chargbTried) return;
        _chargbTried = true;
        try
        {
            string path = ChargbRoot + "cards.json";
            if (!FileAccess.FileExists(path)) { Log("没装 chargb（或缺 cards.json）：GIF 模式退化为起播窗到点即切"); return; }
            Variant parsed = Json.ParseString(FileAccess.GetFileAsString(path));
            if (parsed.VariantType != Variant.Type.Dictionary) return;
            Godot.Collections.Dictionary dict = parsed.AsGodotDictionary();
            _chargbOk = true;

            if (dict.ContainsKey("default")) _chargbDefault = dict["default"].AsString().Trim();

            if (dict.ContainsKey("enabled") && dict["enabled"].VariantType == Variant.Type.Bool)
                _chargbEnabled = dict["enabled"].AsBool();

            if (dict.ContainsKey("cards") && dict["cards"].VariantType == Variant.Type.Dictionary)
            {
                foreach (KeyValuePair<Variant, Variant> kv in dict["cards"].AsGodotDictionary())
                {
                    string k = kv.Key.AsString().Trim();
                    string v = kv.Value.AsString().Trim();
                    if (k.Length > 0 && v.Length > 0) ChargbCards[k] = v;
                }
            }

            if (dict.ContainsKey("disabledAnims") && dict["disabledAnims"].VariantType == Variant.Type.Array)
            {
                foreach (Variant v in dict["disabledAnims"].AsGodotArray())
                {
                    string s = v.AsString().Trim();
                    if (s.Length > 0) ChargbDisabledAnims.Add(s);
                }
            }

            Log($"读到 chargb 配置：启用={_chargbEnabled}，映射 {ChargbCards.Count} 条，"
                + $"默认动画「{_chargbDefault}」，单独关闭 {ChargbDisabledAnims.Count} 段");
        }
        catch (Exception e)
        {
            _chargbOk = false;
            Warn("读 chargb 的 cards.json 失败（当作没装）：" + e.Message);
        }
    }

    private static bool AnimUsable(string anim)
    {
        bool cached;
        if (ChargbAnimUsable.TryGetValue(anim, out cached)) return cached;
        bool ok = false;
        try
        {
            string json = ChargbRoot + anim + ".json";
            string png = ChargbRoot + anim + ".png";
            if (!FileAccess.FileExists(json))
            {
                Log($"chargb 缺 {json}：这张牌的 GIF 不会播");
            }
            else if (!FileAccess.FileExists(png))
            {
                Log($"chargb 缺 {png}：这张牌的 GIF 不会播");
            }
            else
            {
                Variant parsed = Json.ParseString(FileAccess.GetFileAsString(json));
                Godot.Collections.Dictionary cfg = parsed.AsGodotDictionary();
                int count = cfg["count"].AsInt32();
                // chargb 只播帧数 > 1 的动画
                ok = count > 1;
                if (!ok) Log($"chargb 的「{anim}」只有 {count} 帧，不会播");
            }
        }
        catch (Exception e)
        {
            Log($"检查 chargb 动画「{anim}」失败：{e.Message}");
            ok = false;
        }
        ChargbAnimUsable[anim] = ok;
        return ok;
    }
}

// ================================================================= Harmony
// [HarmonyPatch] 写在类上（写在方法上 PatchAll 会静默跳过整个类）。
// 两个补丁都是观察型：Prefix 恒返回 true，不拦本体流程。

[HarmonyPatch(typeof(NCreature), "_Ready")]
internal static class PortraitSwapCreaturePatch
{
    private static void Postfix(NCreature __instance) => PortraitSwapRuntime.TryAttach(__instance);
}

[HarmonyPatch(typeof(CardModel), nameof(CardModel.OnPlayWrapper))]
internal static class PortraitSwapCardPlayPatch
{
    private static bool Prefix(CardModel __instance)
    {
        // 出牌流程里连「读配置、建节点」都不做：全部推迟一帧。
        // 这里同步抛异常会让异步的出牌演出永远等不到结果（症状：那张牌挂在屏幕中间）。
        try
        {
            CardModel card = __instance;
            if (card is not null) Callable.From(() => PortraitSwapRuntime.OnCardPlayed(card)).CallDeferred();
        }
        catch (Exception e)
        {
            GD.PushWarning("[portraitswap] 卡牌补丁出错：" + e.Message);
        }
        return true;
    }
}

[HarmonyPatch(typeof(Hook), nameof(Hook.AfterCombatEnd))]
internal static class PortraitSwapCombatEndPatch
{
    private static void Postfix() => PortraitSwapRuntime.ResetAll("战斗结束");
}
